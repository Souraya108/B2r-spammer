// tokens.js - Single Token Configuration
module.exports = {
    tokens: [
        {
            token: 'MTUxNjU5NDg0MDk5NTg5MzI1MA.GnsJBR.oIfxcU2MMGqMAfViNOVN80BBdcSF555qjanjJI',
            channelIds: ['1557737012616757278'],
            serverId: '1464267978437693682'
        }
    ]
};
