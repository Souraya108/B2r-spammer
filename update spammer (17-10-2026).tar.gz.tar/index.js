let version = "1.2.6";

process.on('unhandledRejection', (reason) => {
    console.log(chalk.yellow(`[Unhandled Rejection]: ${reason}`));
});
process.on('uncaughtException', (err) => {
    console.log(chalk.red(`[Uncaught Exception]: ${err.message}`));
});

const fs = require("fs");
const readline = require("readline");
const chalk = require("chalk");
const axios = require("axios");
const WebSocket = require("ws");
const http = require("http");

// Health-check server for panel hosting
http.createServer((req, res) => {
    res.write("I'm alive!");
    res.end();
}).on("error", (err) => {
    if (err.code === "EADDRINUSE") {
        console.log(chalk.yellow("Warning: Health-check port 3000 is already in use. Skipping server start."));
    } else {
        console.log(chalk.red(`Health-check server error: ${err.message}`));
    }
}).listen(3000);

// Load tokens from tokens.js or environment
let tokens = [];
try {
    const tokenModule = require("./tokens.js");
    tokens = tokenModule.tokens || [];
} catch (e) {
    console.log(chalk.yellow("No tokens.js found, using environment variables"));
}

const defaultArtistTemplates = [
    "{name} op 🔥",
    "{name} on top 👑",
    "{name} OP bhai OP 💥",
    "{name} killing it today 🎶",
    "What a performance {name} ✨",
    "{name} voice is pure magic 🪄",
    "Superstar {name} 🌟",
    "Only {name} forever 💜",
    "{name} next level 🚀",
    "{name} is the GOAT 🐐",
    "Dil jeet liya {name} ne ❤️",
    "Full fire {name} 🔥🔥"
];

const defaultHostTemplates = [
    "{name} op host 🔥",
    "{name} on top 👑",
    "Best host {name} 🎤",
    "{name} host OP bhai OP 💥",
    "{name} energetic hosting 💯",
    "Vibe bana di {name} host ne ✨",
    "Great hosting by {name} 👏",
    "{name} host next level 🚀",
    "{name} hosting on point 🎯"
];

const config = {
    serverId: "",
    Logging: {
        LoggableHook: ""
    }
};

let log;

function getTimestamp() {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    return `${hh}:${mm}:${ss}`;
}

function loadConfig(isReload = false) {
    let loadedConfig = {};
    try {
        if (process.env.CONFIG) {
            loadedConfig = JSON.parse(process.env.CONFIG);
        } else if (fs.existsSync("./config.json")) {
            const raw = fs.readFileSync("./config.json", "utf8");
            loadedConfig = JSON.parse(raw);
        }
    } catch (e) {
        console.log(chalk.red(`[Config] Error reading config.json: ${e.message}`));
        return;
    }

    Object.assign(config, loadedConfig);

    // Support key aliases for artist templates (artistTemplates, artisttemp, artistTemp, artist_templates, etc.)
    const artistList = config.artistTemplates || config.artisttemp || config.artistTemp || config.artist_templates || config.artisttemplates;
    if (Array.isArray(artistList) && artistList.length > 0) {
        config.artistTemplates = artistList;
    }

    // Support key aliases for host templates (hostTemplates, hosttemp, hostTemp, hosttep, host_templates, etc.)
    const hostList = config.hostTemplates || config.hosttemp || config.hostTemp || config.host_templates || config.hosttemplates || config.hosttep || config['host tep'];
    if (Array.isArray(hostList) && hostList.length > 0) {
        config.hostTemplates = hostList;
    }

    if (config.Logging?.LoggableHook?.length > 25) {
        log = config.Logging.LoggableHook;
    }

    const artistCount = (config.artistTemplates && config.artistTemplates.length) || defaultArtistTemplates.length;
    const hostCount = (config.hostTemplates && config.hostTemplates.length) || defaultHostTemplates.length;

    const antiRepeatInfo = isAntiRepeatEnabled()
        ? `Anti-repeat: ON (${getRepeatWindow()} msgs window, cross-account no-duplicate)`
        : `Anti-repeat: OFF`;

    if (isReload) {
        console.log(chalk.greenBright(`[Config] 🔄 config.json reloaded! Active artist templates: ${artistCount}, host templates: ${hostCount}, ${antiRepeatInfo}`));
    } else {
        console.log(chalk.cyan(`[Config] Loaded ${artistCount} artist templates and ${hostCount} host templates. ${antiRepeatInfo}`));
    }
}

// Initial config load
loadConfig();

// Live watch config.json for real-time automatic hot reload
if (fs.existsSync("./config.json")) {
    fs.watchFile("./config.json", { interval: 1000 }, (curr, prev) => {
        if (curr.mtime !== prev.mtime) {
            loadConfig(true);
        }
    });
}

if (tokens && Array.isArray(tokens)) {
    config.tokens = tokens.map((item) => ({
        token: item.token.trim(),
        channelIds: item.channelIds ? item.channelIds.map((channelId) => channelId.trim()) : [],
        serverId: item.serverId?.trim() || config.serverId || ""
    }));
} else {
    throw new Error("Unable to find valid tokens.");
}

// Load messages from msg.txt or messages.txt (one message per line)
let spamMessages = [];
function loadMessages(isReload = false) {
    try {
        let filePath = null;
        if (fs.existsSync('./msg.txt')) {
            filePath = './msg.txt';
        } else if (fs.existsSync('./messages.txt')) {
            filePath = './messages.txt';
        }

        if (filePath) {
            const messagesFile = fs.readFileSync(filePath, 'utf8');
            spamMessages = messagesFile
                .split('\n')
                .map(line => line.trim())
                .filter(line => line.length > 0 && !line.startsWith('#')); // ignore empty lines and comments
            if (isReload) {
                clearRecentHistory();
                console.log(chalk.greenBright(`[Messages] 🔄 Reloaded ${spamMessages.length} messages from ${filePath} (Recent history reset)`));
            } else {
                console.log(chalk.cyan(`Loaded ${spamMessages.length} messages from ${filePath}`));
            }
        } else {
            throw new Error('No message file found');
        }
    } catch (e) {
        if (!isReload) {
            console.log(chalk.yellow('No msg.txt or messages.txt found, using config.json messages'));
        }
        spamMessages = config.messages || ['Hello!', 'Testing', 'Spam message'];
    }
}

loadMessages();

// Live watch message files for real-time updates
['./msg.txt', './messages.txt'].forEach(filePath => {
    if (fs.existsSync(filePath)) {
        fs.watchFile(filePath, { interval: 1000 }, (curr, prev) => {
            if (curr.mtime !== prev.mtime) {
                loadMessages(true);
            }
        });
    }
});

console.log(chalk.cyan(`Message mode: ${config.randomizeMsg !== false ? 'Random' : 'Sequential (loop in order)'}`));
console.log(chalk.cyan(`Anti-repeat mode: ${isAntiRepeatEnabled() ? `ON (prevents duplicate sends within ${getRepeatWindow()} messages across all accounts)` : 'OFF'}`));

let currentArtist = null;
let currentHost = null;
let messageIndex = 0;
let sessions = [];
let isSpammingActive = true;
let lastGlobalPing = null;
const processedMessageIds = new Set();
const botSentMessageIds = new Set();
const recentNonces = new Set();

// Anti-repeat tracking buffers across all accounts and channels
let globalRecentMessages = [];
const channelRecentMessages = new Map();
let recentArtistTemplates = [];
let recentHostTemplates = [];

function isAntiRepeatEnabled() {
    if (config.preventRecentRepeat !== undefined) return Boolean(config.preventRecentRepeat);
    if (config.preventRepeatMsg !== undefined) return Boolean(config.preventRepeatMsg);
    if (config.preventDuplicateMsg !== undefined) return Boolean(config.preventDuplicateMsg);
    if (config.noRepeatMsg !== undefined) return Boolean(config.noRepeatMsg);
    return true; // Enabled by default
}

function getRepeatWindow() {
    const win = parseInt(config.repeatWindow || config.recentRepeatLimit || config.preventRepeatWindow);
    return (Number.isInteger(win) && win > 0) ? win : 3;
}

function clearRecentHistory() {
    globalRecentMessages = [];
    channelRecentMessages.clear();
    recentArtistTemplates = [];
    recentHostTemplates = [];
    for (const session of sessions) {
        if (session && session.recentSent) {
            session.recentSent = [];
        }
    }
}

function getNonRepeatingRandom(pool, recentOrder = []) {
    if (!pool || pool.length === 0) return null;
    if (pool.length === 1) return pool[0];

    // Exclude the most recent items up to pool.length - 1 (guarantees at least 1 candidate remains)
    const maxExclusions = Math.max(0, Math.min(recentOrder.length, pool.length - 1));
    const excludedSet = new Set(recentOrder.slice(0, maxExclusions));

    // Fast O(1) path for medium/large pools
    for (let attempt = 0; attempt < 25; attempt++) {
        const candidate = pool[Math.floor(Math.random() * pool.length)];
        if (!excludedSet.has(candidate)) {
            return candidate;
        }
    }

    // Strict filter for smaller pools or high collision rate
    const available = pool.filter(item => !excludedSet.has(item));
    if (available.length > 0) {
        return available[Math.floor(Math.random() * available.length)];
    }

    return pool[Math.floor(Math.random() * pool.length)];
}

function getArtistTemplates() {
    const list = config.artistTemplates || config.artisttemp || config.artistTemp || config.artist_templates || config.artisttemplates;
    return (Array.isArray(list) && list.length > 0) ? list : defaultArtistTemplates;
}

function getHostTemplates() {
    const list = config.hostTemplates || config.hosttemp || config.hostTemp || config.host_templates || config.hosttemplates || config.hosttep || config['host tep'];
    return (Array.isArray(list) && list.length > 0) ? list : defaultHostTemplates;
}

function getNextMessage(session = null, channelId = null) {
    const antiRepeat = isAntiRepeatEnabled();
    const windowSize = getRepeatWindow();

    const activeModes = [];
    if (currentArtist) activeModes.push('artist');
    if (currentHost) activeModes.push('host');

    if (activeModes.length > 0) {
        const mode = activeModes[Math.floor(Math.random() * activeModes.length)];
        if (mode === 'artist') {
            const templates = getArtistTemplates();
            let template;
            if (antiRepeat) {
                const recentOrder = [];
                for (let i = recentArtistTemplates.length - 1; i >= 0 && recentOrder.length < windowSize; i--) {
                    if (!recentOrder.includes(recentArtistTemplates[i])) {
                        recentOrder.push(recentArtistTemplates[i]);
                    }
                }
                template = getNonRepeatingRandom(templates, recentOrder);
                recentArtistTemplates.push(template);
                if (recentArtistTemplates.length > windowSize * 4) {
                    recentArtistTemplates.shift();
                }
            } else {
                template = templates[Math.floor(Math.random() * templates.length)];
            }
            return template.replace(/{name}/g, currentArtist);
        } else if (mode === 'host') {
            const templates = getHostTemplates();
            let template;
            if (antiRepeat) {
                const recentOrder = [];
                for (let i = recentHostTemplates.length - 1; i >= 0 && recentOrder.length < windowSize; i--) {
                    if (!recentOrder.includes(recentHostTemplates[i])) {
                        recentOrder.push(recentHostTemplates[i]);
                    }
                }
                template = getNonRepeatingRandom(templates, recentOrder);
                recentHostTemplates.push(template);
                if (recentHostTemplates.length > windowSize * 4) {
                    recentHostTemplates.shift();
                }
            } else {
                template = templates[Math.floor(Math.random() * templates.length)];
            }
            return template.replace(/{name}/g, currentHost);
        }
    }

    if (spamMessages.length > 0) {
        if (config.randomizeMsg !== false) {
            if (!antiRepeat) {
                return spamMessages[Math.floor(Math.random() * spamMessages.length)];
            }

            // Cross-account coordination:
            // Build recentOrder with newest messages first:
            // 1. Global (all accounts combined - ensures Account 2 won't repeat Account 1's msg)
            // 2. Channel (in this specific channel)
            // 3. Session (this specific account's recent messages)
            const recentOrder = [];

            // Add global recent messages (newest first)
            for (let i = globalRecentMessages.length - 1; i >= 0 && recentOrder.length < windowSize; i--) {
                const m = globalRecentMessages[i];
                if (!recentOrder.includes(m)) {
                    recentOrder.push(m);
                }
            }

            // Add channel recent messages (newest first)
            if (channelId && channelRecentMessages.has(channelId)) {
                const chList = channelRecentMessages.get(channelId);
                for (let i = chList.length - 1; i >= 0 && recentOrder.length < windowSize * 2; i--) {
                    const m = chList[i];
                    if (!recentOrder.includes(m)) {
                        recentOrder.push(m);
                    }
                }
            }

            // Add session recent messages (newest first)
            if (session?.recentSent) {
                for (let i = session.recentSent.length - 1; i >= 0 && recentOrder.length < windowSize * 3; i--) {
                    const m = session.recentSent[i];
                    if (!recentOrder.includes(m)) {
                        recentOrder.push(m);
                    }
                }
            }

            const chosenMsg = getNonRepeatingRandom(spamMessages, recentOrder);

            // Record chosen message into global, channel, and session history
            globalRecentMessages.push(chosenMsg);
            if (globalRecentMessages.length > windowSize * 4) {
                globalRecentMessages.shift();
            }

            if (channelId) {
                if (!channelRecentMessages.has(channelId)) {
                    channelRecentMessages.set(channelId, []);
                }
                const chList = channelRecentMessages.get(channelId);
                chList.push(chosenMsg);
                if (chList.length > windowSize * 4) {
                    chList.shift();
                }
            }

            if (session) {
                if (!session.recentSent) session.recentSent = [];
                session.recentSent.push(chosenMsg);
                if (session.recentSent.length > windowSize * 4) {
                    session.recentSent.shift();
                }
            }

            return chosenMsg;
        } else {
            const msg = spamMessages[messageIndex % spamMessages.length];
            messageIndex = (messageIndex + 1) % spamMessages.length;
            return msg;
        }
    }
    return "Hello!";
}

function printHelpBanner() {
    console.log(chalk.magenta(`\n============================================================`));
    console.log(chalk.magenta.bold(`💬 CONSOLE CONTROLS & COMMANDS READY:`));
    console.log(chalk.greenBright.bold(`- [DIRECT TYPE]   ➜ Type ANY text directly & press Enter to send live!`));
    console.log(chalk.cyan.bold(`- !r <msg>        ➜ In-line REPLY with ping to last user who pinged you`));
    console.log(chalk.cyan(`- !s <id>         ➜ Send sticker from Account 1 (e.g. !s 123456...)`));
    console.log(chalk.yellow(`- !pause / !stop  ➜ Pause automatic background spamming`));
    console.log(chalk.yellow(`- !start / !resume➜ Resume automatic background spamming`));
    console.log(chalk.yellow(`- !status         ➜ Check bot state, active accounts & last ping`));
    console.log(chalk.yellow(`- !art <name>     ➜ Start Artist hype mode (e.g. !art Arijit)`));
    console.log(chalk.yellow(`- !art remove     ➜ Stop Artist hype mode (resumes message file)`));
    console.log(chalk.yellow(`- !host <name>    ➜ Start Host hype mode (e.g. !host Rohit)`));
    console.log(chalk.yellow(`- !host remove    ➜ Stop Host hype mode (resumes message file)`));
    console.log(chalk.yellow(`- !repeat on/off  ➜ Toggle anti-repeat duplicate prevention`));
    console.log(chalk.yellow(`- !reload         ➜ Reload config.json & messages live without restart`));
    console.log(chalk.yellow(`- !help           ➜ Show this command list`));
    if (sessions.length > 1) {
        console.log(chalk.magenta(`Multi-account shortcuts:`));
        console.log(chalk.gray(`- !<num> <msg>    ➜ Send 1-time from Account <num>`));
        console.log(chalk.gray(`- !r<num> <msg>   ➜ Reply from Account <num>`));
        console.log(chalk.gray(`- !s<num> <id>    ➜ Send sticker from Account <num>`));
        console.log(chalk.gray(`- !all <msg>      ➜ Send 1-time from ALL accounts`));
        console.log(chalk.gray(`- !rall <msg>     ➜ In-line reply from ALL accounts`));
        console.log(chalk.gray(`- !sall <id>      ➜ Send sticker from ALL accounts`));
    }
    console.log(chalk.green(`🚨 Note: When someone pings your account, an alert pops up with quick reply!`));
    console.log(chalk.magenta(`============================================================\n`));
}

function executeCommand(text, source = 'Console') {
    const trimmed = text.trim();
    if (!trimmed) return false;

    // Direct console chat (type any text without '!' to send immediately live)
    if (!trimmed.startsWith('!')) {
        if (source === 'Console') {
            if (sessions.length === 0) {
                console.log(chalk.red(`[Direct Chat] No active accounts connected yet.`));
                return true;
            }
            const session = sessions[0];
            const targetChannelId = session.channelIds[0];
            console.log(chalk.cyan.bold(`[${getTimestamp()}][${session.user?.username || 'Account 1'}][Direct Send] 💬 ➜ #${targetChannelId}: "${trimmed}"`));
            session.queuePriority({
                content: trimmed,
                channelId: targetChannelId
            });
            return true;
        }
        return false;
    }

    // Check for !pause or !stop (pause automatic background spamming)
    if (trimmed.match(/^!(?:pause|stop)$/i)) {
        isSpammingActive = false;
        console.log(chalk.yellow.bold(`\n[Control (${source})] ⏸️ Auto spamming PAUSED!`));
        console.log(chalk.cyan(`Direct typing in console & !r replies will still send immediately.`));
        console.log(chalk.cyan(`Type "!start" or "!resume" to start auto spamming again.\n`));
        return true;
    }

    // Check for !start, !resume, !play (resume automatic background spamming)
    if (trimmed.match(/^!(?:start|resume|play)$/i)) {
        isSpammingActive = true;
        console.log(chalk.greenBright.bold(`\n[Control (${source})] ▶️ Auto spamming RESUMED!\n`));
        sessions.forEach(session => {
            if (session && session.triggerSend) {
                session.triggerSend();
            }
        });
        return true;
    }

    // Check for !status or !info
    if (trimmed.match(/^!(?:status|info)$/i)) {
        console.log(chalk.magenta.bold(`\n================== 📊 BOT STATUS ==================`));
        console.log(chalk.cyan(`Auto Spamming : ${isSpammingActive ? chalk.greenBright.bold('ACTIVE ▶️') : chalk.yellow.bold('PAUSED ⏸️')}`));
        console.log(chalk.cyan(`Anti-Repeat   : ${isAntiRepeatEnabled() ? chalk.green('ON') : chalk.yellow('OFF')} (window: ${getRepeatWindow()})`));
        console.log(chalk.cyan(`Artist Mode   : ${currentArtist ? chalk.magenta(currentArtist) : chalk.gray('None')}`));
        console.log(chalk.cyan(`Host Mode     : ${currentHost ? chalk.magenta(currentHost) : chalk.gray('None')}`));
        console.log(chalk.cyan(`Active Sessions (${sessions.length}):`));
        sessions.forEach((s, idx) => {
            console.log(chalk.white(`  Account ${idx + 1}: @${s.user?.username || 'Unknown'} | Channels: [${s.channelIds.join(', ')}]`));
        });
        if (lastGlobalPing) {
            console.log(chalk.yellow(`Last Ping     : From @${lastGlobalPing.authorUsername} in #${lastGlobalPing.channelId}: "${lastGlobalPing.content}"`));
        } else {
            console.log(chalk.gray(`Last Ping     : None recorded yet`));
        }
        console.log(chalk.magenta(`===================================================\n`));
        return true;
    }

    // Check for !help or !cmd
    if (trimmed.match(/^!(?:help|cmd|commands)$/i)) {
        printHelpBanner();
        return true;
    }

    // Check for !art <artist_name> or !art remove
    const artMatch = trimmed.match(/^!art\s+(.*)$/i);
    if (artMatch) {
        const arg = artMatch[1].trim();
        if (arg.toLowerCase() === 'remove' || arg.toLowerCase() === 'off') {
            currentArtist = null;
            console.log(chalk.yellow(`[Mode (${source})] 🎨 Artist hype mode turned OFF. Resuming message file!`));
        } else {
            currentArtist = arg;
            console.log(chalk.magenta.bold(`[Mode (${source})] 🎨 Artist hype mode turned ON for "${currentArtist}"!`));
            console.log(chalk.cyan(`All accounts will now send different hype lines for "${currentArtist}". Type "!art remove" to stop.`));
        }
        return true;
    }

    // Check for !host <host_name> or !host remove
    const hostMatch = trimmed.match(/^!host\s+(.*)$/i);
    if (hostMatch) {
        const arg = hostMatch[1].trim();
        if (arg.toLowerCase() === 'remove' || arg.toLowerCase() === 'off') {
            currentHost = null;
            console.log(chalk.yellow(`[Mode (${source})] 🎤 Host hype mode turned OFF. Resuming message file!`));
        } else {
            currentHost = arg;
            console.log(chalk.magenta.bold(`[Mode (${source})] 🎤 Host hype mode turned ON for "${currentHost}"!`));
            console.log(chalk.cyan(`All accounts will now send different hype lines for "${currentHost}". Type "!host remove" to stop.`));
        }
        return true;
    }

    // Check for !reload (hot reload config.json and messages without restart)
    if (trimmed.match(/^!(?:reload|load)$/i)) {
        loadConfig(true);
        loadMessages(true);
        console.log(chalk.greenBright(`[Command (${source})] 🔄 Config and message templates reloaded successfully!`));
        return true;
    }

    // Check for !repeat on/off/status
    const repeatMatch = trimmed.match(/^!(?:repeat|antirepeat|norepeat)(?:\s+(on|off|true|false))?$/i);
    if (repeatMatch) {
        const arg = repeatMatch[1] ? repeatMatch[1].toLowerCase() : null;
        if (arg === 'off' || arg === 'false') {
            config.preventRecentRepeat = false;
            console.log(chalk.yellow(`[Command (${source})] 🔄 Anti-repeat mode turned OFF. Messages may now repeat randomly.`));
        } else if (arg === 'on' || arg === 'true') {
            config.preventRecentRepeat = true;
            console.log(chalk.greenBright(`[Command (${source})] 🔄 Anti-repeat mode turned ON (window: ${getRepeatWindow()} messages). No duplicates across accounts or recent sends!`));
        } else {
            config.preventRecentRepeat = !isAntiRepeatEnabled();
            const state = isAntiRepeatEnabled() ? 'ON' : 'OFF';
            console.log(chalk.cyan(`[Command (${source})] 🔄 Anti-repeat mode toggled ${state} (window: ${getRepeatWindow()} messages)!`));
        }
        return true;
    }

    // Check for !rall <message_id?> <msg> (in-line reply from all accounts on targeted channel)
    const rallMatch = trimmed.match(/^!(?:rall|replyall)\s+(?:(\d{17,20})\s+)?(.*)$/is);
    if (rallMatch) {
        const explicitMsgId = rallMatch[1];
        const msg = rallMatch[2].trim();
        if (!msg) {
            console.log(chalk.yellow(`[Command (${source})] Please provide a reply message. Example: !rall nah bro`));
            return true;
        }

        let targetMessageId = explicitMsgId;
        let targetChannelId = null;

        if (!targetMessageId) {
            if (lastGlobalPing) {
                targetMessageId = lastGlobalPing.messageId;
                targetChannelId = lastGlobalPing.channelId;
            } else {
                console.log(chalk.yellow(`[Command (${source})] No recent pings recorded on targeted channels yet. To reply to a specific message, use: !rall <message_id> <msg>`));
                return true;
            }
        }

        console.log(chalk.magenta(`[Command (${source})] 💬 Sending IN-LINE REPLY from accounts targeting #${targetChannelId || 'channel'} to message ${targetMessageId}: "${msg}"`));
        sessions.forEach(session => {
            if (targetChannelId && (!session.channelIds || !session.channelIds.includes(targetChannelId))) {
                return;
            }
            session.queuePriority({
                content: msg,
                replyToMessageId: targetMessageId,
                channelId: targetChannelId || session.channelIds[0]
            });
        });
        return true;
    }

    // Check for !r / !reply / !r<num> / !reply<num> <message_id?> <msg>
    // Examples: !r hello | !r 1503482294000681031 hello | !r1 hello | !r2 hello
    const rMatch = trimmed.match(/^!(?:r|reply)(\d*)\s+(?:(\d{17,20})\s+)?(.*)$/is);
    if (rMatch) {
        const accountNumStr = rMatch[1];
        const explicitMsgId = rMatch[2];
        const msg = rMatch[3].trim();
        if (!msg) {
            console.log(chalk.yellow(`[Command (${source})] Please provide a reply message. Example: !r hello bro`));
            return true;
        }

        const accountNum = accountNumStr ? parseInt(accountNumStr) : 1;
        const sessionIndex = accountNum - 1;
        if (sessionIndex < 0 || sessionIndex >= sessions.length) {
            console.log(chalk.yellow(`[Command (${source})] Account ${accountNum} is not active. Available: 1 to ${sessions.length}`));
            return true;
        }

        const session = sessions[sessionIndex];
        let targetMessageId = explicitMsgId;
        let targetChannelId = null;

        if (!targetMessageId) {
            if (session.lastPing) {
                targetMessageId = session.lastPing.messageId;
                targetChannelId = session.lastPing.channelId;
            } else if (lastGlobalPing && session.channelIds && session.channelIds.includes(lastGlobalPing.channelId)) {
                targetMessageId = lastGlobalPing.messageId;
                targetChannelId = lastGlobalPing.channelId;
            } else if (lastGlobalPing) {
                targetMessageId = lastGlobalPing.messageId;
                targetChannelId = lastGlobalPing.channelId;
            } else {
                console.log(chalk.yellow(`[Command (${source})] Account ${accountNum} has no recent pings recorded. To reply to a specific message ID, use: !r <message_id> <msg>`));
                return true;
            }
        } else {
            targetChannelId = (session.lastPing && session.lastPing.channelId) || session.channelIds[0];
        }

        console.log(chalk.cyan.bold(`[Command (${source})] 💬 Sending IN-LINE REPLY from Account ${accountNum} (@${session.user?.username || 'User'}) to message ${targetMessageId} in target channel #${targetChannelId}: "${msg}"`));
        session.queuePriority({
            content: msg,
            replyToMessageId: targetMessageId,
            channelId: targetChannelId
        });
        return true;
    }

    // Check for !all <msg>
    const allMatch = trimmed.match(/^!all\s+(.*)$/is);
    if (allMatch) {
        const msg = allMatch[1].trim();
        if (!msg) {
            console.log(chalk.yellow(`[Command (${source})] Please provide a message. Example: !all hello`));
            return true;
        }
        console.log(chalk.magenta(`[Command (${source})] 🚀 Sending to ALL accounts in full speed: "${msg}"`));
        sessions.forEach(session => session.queuePriority(msg));
        return true;
    }

    // Check for !<num> <msg> (e.g. !1 <msg>, !2 <msg>)
    const numMatch = trimmed.match(/^!(\d+)\s+(.*)$/is);
    if (numMatch) {
        const accountNum = parseInt(numMatch[1]);
        const msg = numMatch[2].trim();
        if (!msg) {
            console.log(chalk.yellow(`[Command (${source})] Please provide a message. Example: !${accountNum} hello`));
            return true;
        }
        const sessionIndex = accountNum - 1;
        if (sessionIndex >= 0 && sessionIndex < sessions.length) {
            console.log(chalk.cyan(`[Command (${source})] 🚀 Sending from Account ${accountNum} in full speed: "${msg}"`));
            sessions[sessionIndex].queuePriority(msg);
        } else {
            console.log(chalk.yellow(`[Command (${source})] Account ${accountNum} is not active. Available: 1 to ${sessions.length}`));
        }
        return true;
    }

    // Check for !sall <sticker_id>
    const sAllMatch = trimmed.match(/^!sall\s+(\d{17,20})$/i);
    if (sAllMatch) {
        const stickerId = sAllMatch[1];
        console.log(chalk.magenta(`[Command (${source})] 🖼️ Sending STICKER (${stickerId}) to ALL accounts in full speed!`));
        sessions.forEach(session => session.queuePriority({ sticker_ids: [stickerId] }));
        return true;
    }

    // Check for !s or !s<num> <sticker_id> (e.g. !s <sticker_id> or !s1 <sticker_id>)
    const sMatch = trimmed.match(/^!s(\d*)\s+(\d{17,20})$/i);
    if (sMatch) {
        const accountNumStr = sMatch[1];
        const stickerId = sMatch[2];
        const accountNum = accountNumStr ? parseInt(accountNumStr) : 1;
        const sessionIndex = accountNum - 1;
        if (sessionIndex >= 0 && sessionIndex < sessions.length) {
            console.log(chalk.cyan.bold(`[Command (${source})] 🖼️ Sending STICKER (${stickerId}) from Account ${accountNum} in full speed!`));
            sessions[sessionIndex].queuePriority({ sticker_ids: [stickerId] });
        } else {
            console.log(chalk.yellow(`[Command (${source})] Account ${accountNum} is not active. Available: 1 to ${sessions.length}`));
        }
        return true;
    }

    if (source === 'Console') {
        console.log(chalk.gray(`Unknown command "${trimmed}". Type !help to see available commands or just type any text directly to chat!`));
    }
    return false;
}

function isAuthorizedOwner(authorId) {
    if (!authorId) return false;
    const authorStr = String(authorId).trim();

    // 1. All selfbot token accounts pretend as owner IDs
    const isTokenAccount = sessions.some(s => s.user && String(s.user.id).trim() === authorStr);
    if (isTokenAccount) return true;

    // 2. Multiple owner IDs configured in config.ownerIds
    if (Array.isArray(config.ownerIds)) {
        if (config.ownerIds.some(id => String(id).trim() === authorStr && String(id).trim().length > 0)) {
            return true;
        }
    }

    // 3. Single ownerId / controllerId (backwards compatibility)
    if (config.ownerId && String(config.ownerId).trim() === authorStr && String(config.ownerId).trim().length > 0) {
        return true;
    }
    if (config.controllerId && String(config.controllerId).trim() === authorStr && String(config.controllerId).trim().length > 0) {
        return true;
    }

    return false;
}

class DiscordSession {
    constructor(token, channelIds, serverId) {
        this.token = token;
        this.channelIds = channelIds;
        this.serverId = serverId;
        this.user = null;
        try {
            this.userId = Buffer.from(token.split('.')[0], 'base64').toString('ascii');
        } catch (e) {
            this.userId = null;
        }
        this.ws = null;
        this.messageQueue = new Map();
        this.heartbeatInterval = null;
        this.sequence = null;
        this.sessionId = null;
        this.priorityQueue = [];
        this.triggerSend = null;
        this.inCooldown = false;
        this.channelSlowmodes = new Map();
        this.lastPing = null;
        this.recentSent = [];
    }

    getLogPrefix() {
        const time = getTimestamp();
        const username = this.user?.username || 'User';
        return `[${time}][${username}]`;
    }

    queuePriority(message) {
        this.priorityQueue.push(message);
        if (this.triggerSend) {
            this.triggerSend();
        }
    }

    async initialize() {
        try {
            const userInfo = await this.makeRequest('get', 'users/@me');
            this.user = userInfo.data;
            console.log(chalk.green(`Logged in as ${this.user.username}#${this.user.discriminator} via Raw API`));
            await this.connectToSocket();
            for (const channelId of this.channelIds) {
                try {
                    const chInfo = await this.makeRequest('get', `channels/${channelId}`);
                    if (chInfo?.data?.rate_limit_per_user !== undefined) {
                        const sm = chInfo.data.rate_limit_per_user;
                        this.channelSlowmodes.set(channelId, sm);
                        if (sm > 0) {
                            console.log(chalk.cyan(`${this.getLogPrefix()} ⏱️ Channel ${channelId} slowmode detected: ${sm}s`));
                        }
                    }
                } catch (e) { }
                this.spamChannel(channelId);
            }
            return true;
        } catch (error) {
            console.log(chalk.red(`Failed to initialize session for token: ${error.message}`));
            return false;
        }
    }

    async makeRequest(method, endpoint, data = null, retryCount = 0) {
        const url = `https://discord.com/api/v10/${endpoint}`;

        // Base64 encoded properties for stealth
        const properties = Buffer.from(JSON.stringify({
            os: 'Windows',
            browser: 'Chrome',
            device: '',
            system_locale: 'en-US',
            browser_user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            browser_version: '120.0.0.0',
            os_version: '10',
            referrer: '',
            referring_domain: '',
            referrer_current: '',
            referring_domain_current: '',
            release_channel: 'stable',
            client_build_number: 355000,
            client_event_source: null
        })).toString('base64');

        const headers = {
            Authorization: this.token,
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'X-Super-Properties': properties,
            'Sec-Ch-Ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Origin': 'https://discord.com',
            'Referer': 'https://discord.com/channels/@me',
            'Accept-Language': 'en-US,en;q=0.9'
        };

        try {
            const response = await axios({
                method: method,
                url: url,
                data: data || undefined,
                headers: headers
            });
            return response;
        } catch (error) {
            if (error.response) {
                if (error.response.status === 401) {
                    this.diagnoseToken(error);
                } else if (error.response.status === 403) {
                    // 403 is channel/guild permission denied, NOT token expiration
                } else if (error.response.status === 429) {
                    const retryAfter = error.response.data.retry_after || 5;
                    const global = error.response.data.global;
                    if (global) {
                        console.log(chalk.red(`[GLOBAL] RATE LIMIT - Retrying after ${retryAfter}s`));
                    }
                    // Local rate limit works silently in background without console clutter

                    if (retryCount < 3) {
                        await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
                        return this.makeRequest(method, endpoint, data, retryCount + 1);
                    }
                }
            }
            throw error;
        }
    }

    diagnoseToken(error) {
        console.log(chalk.red.bold(`\n╔════════════════════════════════════════════════════════════════════════╗`));
        console.log(chalk.red.bold(`║                    🔍 TOKEN DIAGNOSTIC REPORT                          ║`));
        console.log(chalk.red.bold(`╚════════════════════════════════════════════════════════════════════════╝`));

        const token = this.token || '';
        const parts = token.split('.');

        // 1. Structure Analysis
        console.log(chalk.cyan.bold(`[1] TOKEN FORMAT & SYNTAX:`));
        console.log(chalk.gray(`   • Preview        : ${token.substring(0, 16)}...${token.length > 20 ? token.substring(token.length - 8) : ''}`));
        console.log(chalk.gray(`   • Length         : ${token.length} chars (Standard Discord tokens are 59-72 chars)`));
        console.log(chalk.gray(`   • Segments       : ${parts.length} / 3 segments`));

        let decodedUserId = null;
        let accountCreatedAt = null;
        if (parts.length >= 1 && parts[0]) {
            try {
                decodedUserId = Buffer.from(parts[0], 'base64').toString('ascii');
                if (/^\d{17,20}$/.test(decodedUserId)) {
                    const snowflake = BigInt(decodedUserId);
                    const timestampMs = Number((snowflake >> 22n) + 1420070400000n);
                    accountCreatedAt = new Date(timestampMs).toISOString().split('T')[0];
                    console.log(chalk.green(`   • Decoded User ID: ${decodedUserId} (Account created: ${accountCreatedAt})`));
                } else {
                    console.log(chalk.yellow(`   • Decoded User ID: "${decodedUserId}" (WARNING: Invalid user ID format! Check if token was copied correctly)`));
                }
            } catch (e) {
                console.log(chalk.yellow(`   • Decoded User ID: Base64 decode failed (${e.message})`));
            }
        }

        // 2. HTTP & Cloudflare Layer Analysis
        console.log(chalk.cyan.bold(`\n[2] NETWORK & CLOUDFLARE RESPONSE:`));
        if (error && error.response) {
            const status = error.response.status;
            const statusText = error.response.statusText;
            const headers = error.response.headers || {};
            const cfRay = headers['cf-ray'] || 'None';
            const contentType = headers['content-type'] || 'unknown';
            const server = headers['server'] || 'cloudflare';

            console.log(chalk.gray(`   • HTTP Status    : ${status} ${statusText}`));
            console.log(chalk.gray(`   • Cloudflare Ray : ${cfRay}`));
            console.log(chalk.gray(`   • Server / Type  : ${server} | ${contentType}`));

            const data = error.response.data;
            const rawBody = typeof data === 'object' ? JSON.stringify(data) : String(data);
            console.log(chalk.gray(`   • Response Body  : ${rawBody.substring(0, 200)}`));

            // 3. Exact Cause Determination
            console.log(chalk.cyan.bold(`\n[3] ROOT CAUSE DETERMINATION:`));

            if (typeof data === 'string' && (data.includes('<!DOCTYPE') || data.includes('Just a moment...') || data.includes('challenge-running'))) {
                console.log(chalk.red.bold(`   🛑 CLOUDFLARE IP BLOCK / CHALLENGE INTERCEPTED:`));
                console.log(chalk.white(`      The hosting server's IP address was flagged by Cloudflare DDoS / Bot protection.`));
                console.log(chalk.white(`      The request never reached Discord's API.`));
                console.log(chalk.yellow(`      ➜ Solution: This hosting provider/datacenter IP is blocked by Cloudflare.`));
            } else if (data && (data.captcha_key || data.captcha_sitekey || data.code === 40002)) {
                console.log(chalk.yellow.bold(`   ⚠️ CAPTCHA / VERIFICATION CHECKPOINT TRIGGERED:`));
                console.log(chalk.white(`      Discord detected an unusual login from this datacenter and locked the token behind a CAPTCHA.`));
                console.log(chalk.yellow(`      ➜ Solution: Log into the account in a normal browser and solve the verification prompt.`));
            } else if (data && data.code === 20011) {
                console.log(chalk.yellow.bold(`   📱 PHONE VERIFICATION REQUIRED:`));
                console.log(chalk.white(`      Discord flagged the account and requires an SMS phone verification code.`));
                console.log(chalk.yellow(`      ➜ Solution: Link a phone number to this account in Discord settings to unlock it.`));
            } else if (data && data.code === 20002) {
                console.log(chalk.red.bold(`   ❌ ACCOUNT DISABLED / BANNED:`));
                console.log(chalk.white(`      Discord has permanently disabled this account for Terms of Service violations.`));
            } else if (status === 401) {
                console.log(chalk.yellow.bold(`   🔒 TOKEN REVOKED / INVALIDATED (LOCATION / DATACENTER ANOMALY):`));
                console.log(chalk.white(`      1. The token was working locally, but connecting from this hosting server's remote`));
                console.log(chalk.white(`         datacenter IP triggered Discord's automated fraud & security quarantine.`));
                console.log(chalk.white(`      2. Discord immediately invalidates the token to protect the account from suspected takeover.`));
                console.log(chalk.cyan(`      3. What to do now:`));
                console.log(chalk.cyan(`         • Open Discord in a browser or phone and log into this account (@${decodedUserId || 'account'}).`));
                console.log(chalk.cyan(`         • You will see an alert: "We detected suspicious activity" or an email confirmation.`));
                console.log(chalk.cyan(`         • Once confirmed, obtain the fresh token and test locally first.`));
            } else if (status === 403) {
                console.log(chalk.yellow.bold(`   🚫 403 FORBIDDEN / ACCESS DENIED:`));
                console.log(chalk.white(`      Discord API denied access. Server response: ${rawBody}`));
            } else {
                console.log(chalk.yellow(`   Error Status ${status}: ${data?.message || error.message}`));
            }
        } else {
            console.log(chalk.red(`   ${error?.message || 'Connection closed by server'}`));
            console.log(chalk.yellow(`   Gateway or network disconnected. Check if hosting server has unrestricted outbound HTTPS.`));
        }

        console.log(chalk.red.bold(`╚════════════════════════════════════════════════════════════════════════╝\n`));
    }

    async connectToSocket() {
        return new Promise((resolve, reject) => {
            const gatewayUrl = 'wss://gateway.discord.gg/?v=10&encoding=json';
            this.ws = new WebSocket(gatewayUrl);
            this._onReadyResolve = () => {
                if (!resolved) {
                    resolved = true;
                    resolve();
                }
            };
            let resolved = false;

            this.ws.on('open', () => {
                console.log(chalk.green(`WebSocket TCP connected for ${this.user?.username || 'Session'}. Waiting for Hello & Ready...`));
            });

            this.ws.on('message', (data) => {
                try {
                    const packet = JSON.parse(data);
                    this.handleWebSocketMessage(packet);
                } catch (e) {
                    // Ignore non-JSON binary frames
                }
            });

            this.ws.on('error', (error) => {
                console.log(chalk.red(`WebSocket error: ${error.message}`));
                if (!resolved) {
                    resolved = true;
                    reject(error);
                }
            });

            this.ws.on('close', (code, reason) => {
                const reasonStr = reason ? reason.toString() : 'None';
                if (code === 4004) {
                    console.log(chalk.red.bold(`\n[!] GATEWAY AUTHENTICATION FAILED (Close Code 4004): Token has expired, been reset, or account is locked.`));
                    this.diagnoseToken({ message: `WebSocket Gateway closed with code 4004 (Authentication Failed - token expired or revoked)` });
                    return;
                }
                console.log(chalk.yellow(`WebSocket closed for ${this.user?.username || 'Session'} (code: ${code}, reason: ${reasonStr}), reconnecting...`));
                // Clear old heartbeat
                if (this.heartbeatInterval) {
                    clearInterval(this.heartbeatInterval);
                    this.heartbeatInterval = null;
                }
                setTimeout(() => this.connectToSocket(), 5000);
            });
        });
    }

    identify() {
        const identifyPayload = {
            op: 2,
            d: {
                token: this.token,
                properties: {
                    os: 'Windows',
                    browser: 'Chrome',
                    device: '',
                    system_locale: 'en-US',
                    browser_user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                    browser_version: '120.0.0.0',
                    os_version: '10',
                    referrer: '',
                    referring_domain: '',
                    referrer_current: '',
                    referring_domain_current: '',
                    release_channel: 'stable',
                    client_build_number: 355000,
                    client_event_source: null
                },
                presence: {
                    status: 'dnd',
                    since: 0,
                    activities: [],
                    afk: false
                },
                compress: false,
                capabilities: 16381
            }
        };
        this.ws.send(JSON.stringify(identifyPayload));
    }

    handleWebSocketMessage(packet) {
        switch (packet.op) {
            case 10: // Hello - start heartbeat and send Identify
                this.startHeartbeat(packet.d.heartbeat_interval);
                this.identify();
                break;
            case 11: // Heartbeat ACK
                // Silent - no need to log every beat
                break;
            case 0: // Dispatch
                if (packet.s) this.sequence = packet.s;
                if (packet.t === 'READY') {
                    console.log(chalk.cyan(`${this.getLogPrefix()} READY - Gateway session authenticated! Starting spam on ${this.channelIds.length} channel(s)`));
                    if (this._onReadyResolve) {
                        this._onReadyResolve();
                        this._onReadyResolve = null;
                    }
                } else if (packet.t === 'CHANNEL_UPDATE') {
                    this.handleChannelUpdate(packet.d);
                } else if (packet.t === 'MESSAGE_CREATE') {
                    this.handleMessageCreate(packet.d);
                }
                break;
            case 9: // Invalid session
                console.log(chalk.red(`${this.getLogPrefix()} Invalid session, re-identifying...`));
                setTimeout(() => this.identify(), 3000);
                break;
        }
    }

    handleMessageCreate(msg) {
        if (!msg || !msg.author) return;
        const text = (msg.content || '').trim();

        // Deduplicate message across multiple running tokens
        if (processedMessageIds.has(msg.id)) return;
        processedMessageIds.add(msg.id);
        if (processedMessageIds.size > 500) {
            const firstKey = processedMessageIds.values().next().value;
            processedMessageIds.delete(firstKey);
        }

        // Ignore messages sent by our bot's own automated spam to prevent feedback loops
        if (msg.nonce && recentNonces.has(msg.nonce)) return;
        if (botSentMessageIds.has(msg.id)) return;

        // Auto Sticker Mirror: Each account is its own owner!
        // When you log into any selfbot account and send a sticker anywhere, that specific account mirrors it to its target channels!
        if (msg.sticker_items && msg.sticker_items.length > 0) {
            const sticker = msg.sticker_items[0];
            const isDM = !msg.guild_id;
            const location = isDM ? 'Private DM' : `Channel #${msg.channel_id}`;
            const authorName = msg.author.username || msg.author.id;

            // 1. Check if the sticker was sent by one of our selfbot accounts
            const senderSession = sessions.find(s => (s.user && String(s.user.id) === String(msg.author.id)) || (s.userId && String(s.userId) === String(msg.author.id)));

            if (senderSession) {
                console.log(chalk.magenta.bold(`\n🎯 [STICKER MIRROR] Account @${senderSession.user?.username || authorName} sent sticker "${sticker.name}" (ID: ${sticker.id}) in ${location}!`));
                console.log(chalk.cyan(`🚀 Mirroring sticker from Account @${senderSession.user?.username || authorName} to its target channel(s) at full speed...`));
                senderSession.queuePriority({
                    sticker_ids: [sticker.id]
                });
                return;
            }

            // 2. If sent by an external owner ID (from config.ownerIds)
            if (isAuthorizedOwner(msg.author.id)) {
                console.log(chalk.magenta.bold(`\n🎯 [STICKER MIRROR] Owner @${authorName} sent sticker "${sticker.name}" (ID: ${sticker.id}) in ${location}!`));
                console.log(chalk.cyan(`🚀 Mirroring sticker to ALL accounts in target channels at full speed...`));
                sessions.forEach(session => {
                    session.queuePriority({
                        sticker_ids: [sticker.id]
                    });
                });
                return;
            }
        }

        // 1. Check if this is an authorized bot command
        if (text.startsWith('!') && isAuthorizedOwner(msg.author.id)) {
            const isDM = !msg.guild_id;
            const location = isDM ? 'Private DM' : `Channel #${msg.channel_id}`;
            const sourceLabel = `Discord ${location} from Owner (${msg.author.username || msg.author.id})`;
            executeCommand(text, sourceLabel);
            return;
        }

        // 2. Check if any of our selfbot accounts were pinged or replied to ONLY IN THEIR TARGETED MESSAGE CHANNEL
        const isFromOurAccount = sessions.some(s => s.user && s.user.id === msg.author.id);
        if (!isFromOurAccount) {
            for (let i = 0; i < sessions.length; i++) {
                const session = sessions[i];
                if (!session.user) continue;

                // CRITICAL FIX: Only alert and track pings if the message occurred in this account's targeted channel!
                if (!session.channelIds || !session.channelIds.includes(msg.channel_id)) {
                    continue;
                }

                const isMentioned = Array.isArray(msg.mentions) && msg.mentions.some(m => m.id === session.user.id);
                const isReplied = msg.referenced_message?.author?.id === session.user.id;

                if (isMentioned || isReplied) {
                    session.lastPing = {
                        messageId: msg.id,
                        channelId: msg.channel_id,
                        authorId: msg.author.id,
                        authorUsername: msg.author.username,
                        content: msg.content,
                        isDM: false,
                        timestamp: Date.now()
                    };
                    lastGlobalPing = {
                        accountIndex: i,
                        ...session.lastPing
                    };

                    const channelLabel = `Target Channel #${msg.channel_id}`;
                    const eventType = isReplied ? 'REPLY' : 'PING';

                    console.log(chalk.bgRed.white.bold(`\n🚨 [${eventType} ALERT] Account ${i + 1} (@${session.user.username}) received ${eventType} in ${channelLabel}!`));
                    console.log(chalk.red.bold(`From: @${msg.author.username || 'Unknown'} (${msg.author.id})`));
                    console.log(chalk.yellow(`Message: "${msg.content}"`));
                    const replyCmd = (sessions.length === 1 || i === 0) ? `!r <your_reply>` : `!r${i + 1} <your_reply>`;
                    console.log(chalk.cyan.bold(`➜ Quick Reply: Type "${replyCmd}" to reply with in-line ping in target channel #${msg.channel_id}!\n`));
                }
            }
        }
    }

    handleChannelUpdate(channelData) {
        if (!channelData || !channelData.id) return;
        const channelId = channelData.id;
        if (!this.channelIds.includes(channelId)) return;

        if (channelData.rate_limit_per_user !== undefined) {
            const oldSlowmode = this.channelSlowmodes.get(channelId) || 0;
            const newSlowmode = channelData.rate_limit_per_user;
            this.channelSlowmodes.set(channelId, newSlowmode);

            if (oldSlowmode !== newSlowmode) {
                const configDelaySec = ((config.delay || 4000) / 1000).toFixed(1);
                if (newSlowmode > (config.delay || 4000) / 1000) {
                    console.log(chalk.yellow(`${this.getLogPrefix()} ⏱️ Slowmode changed in ${channelId}: ${oldSlowmode}s ➜ ${newSlowmode}s (Spam speed auto-adjusted to full speed: ${newSlowmode}s)`));
                } else {
                    console.log(chalk.green(`${this.getLogPrefix()} ⏱️ Slowmode changed in ${channelId}: ${oldSlowmode}s ➜ ${newSlowmode}s (Spam speed locked to config.json minimum: ${configDelaySec}s)`));
                }
            }
        }
    }

    startHeartbeat(interval) {
        if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
        this.heartbeatInterval = setInterval(() => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({ op: 1, d: this.sequence }));
            }
        }, interval);
    }

    async spamChannel(channelId) {
        let isSending = false;
        let spamTimeout = null;
        let pendingMessage = null;
        let isPendingPriority = false;
        let inCooldown = false;
        let cooldownEndTime = 0;

        const sendNext = async () => {
            // Strict Mutex Lock: Prevent any concurrent execution
            if (isSending) return;

            // Always clear pending timer to prevent ghost loops
            if (spamTimeout) {
                clearTimeout(spamTimeout);
                spamTimeout = null;
            }

            // If channel is in slowmode/cooldown, schedule and wait
            const now = Date.now();
            if (now < cooldownEndTime) {
                const waitTime = Math.max(200, cooldownEndTime - now);
                spamTimeout = setTimeout(sendNext, waitTime);
                return;
            }
            inCooldown = false;

            let currentMessage;
            let currentlyPriority = false;

            // 1. Priority queue ALWAYS takes top priority!
            if (this.priorityQueue.length > 0) {
                currentMessage = this.priorityQueue.shift();
                currentlyPriority = true;
                // Discard any stale pending random message so it doesn't interrupt manual conversation
                if (!isPendingPriority) {
                    pendingMessage = null;
                }
            } else if (pendingMessage) {
                currentMessage = pendingMessage;
                currentlyPriority = isPendingPriority;
            } else {
                if (!isSpammingActive) {
                    return;
                }
                currentMessage = getNextMessage(this, channelId);
                currentlyPriority = false;
            }

            const targetChannelId = (typeof currentMessage === 'object' && currentMessage.channelId) ? currentMessage.channelId : channelId;
            const messageContent = typeof currentMessage === 'object' ? currentMessage.content : currentMessage;

            isSending = true;
            try {
                await this.sendMessage(targetChannelId, currentMessage);
                if (currentlyPriority) {
                    if (typeof currentMessage === 'object' && currentMessage.sticker_ids) {
                        console.log(chalk.greenBright(`${this.getLogPrefix()}[PRIORITY STICKER] ➜ ${targetChannelId}: 🖼️ Sticker ID ${currentMessage.sticker_ids[0]}`));
                    } else if (typeof currentMessage === 'object' && currentMessage.replyToMessageId) {
                        console.log(chalk.greenBright(`${this.getLogPrefix()}[IN-LINE REPLY] ➜ Replied to message ${currentMessage.replyToMessageId} in ${targetChannelId}: "${messageContent}"`));
                    } else {
                        console.log(chalk.greenBright(`${this.getLogPrefix()}[PRIORITY 1-TIME] ➜ ${targetChannelId}: ${messageContent}`));
                    }
                } else {
                    console.log(chalk.green(`${this.getLogPrefix()} ➜ ${channelId}: ${currentMessage}`));
                }

                pendingMessage = null;
                isPendingPriority = false;
                inCooldown = false;
            } catch (error) {
                if (error.response?.status === 429) {
                    const retryAfterSec = error.response.data?.retry_after || 5;
                    const retryAfterMs = Math.ceil(retryAfterSec * 1000) + 150;
                    cooldownEndTime = Date.now() + retryAfterMs;
                    inCooldown = true;

                    const knownSlowmode = this.channelSlowmodes.get(channelId) || 0;
                    if (Math.round(retryAfterSec) > knownSlowmode) {
                        this.channelSlowmodes.set(channelId, Math.round(retryAfterSec));
                    }

                    if (currentlyPriority) {
                        pendingMessage = currentMessage;
                        isPendingPriority = true;
                        console.log(chalk.yellow(`${this.getLogPrefix()} Slowmode active! Retrying priority message in ${retryAfterSec}s when slowmode ends...`));
                    } else {
                        // Discard failed random message; next loop will pick fresh
                        pendingMessage = null;
                        isPendingPriority = false;
                    }

                    isSending = false;
                    if (spamTimeout) clearTimeout(spamTimeout);
                    spamTimeout = setTimeout(sendNext, retryAfterMs);
                    return;
                } else if (error.response?.status === 401) {
                    console.log(chalk.red.bold(`\n[!] SESSION STOPPED: Token revoked or expired while sending message!`));
                    this.diagnoseToken(error);
                    pendingMessage = null;
                    isPendingPriority = false;
                    if (spamTimeout) clearTimeout(spamTimeout);
                    return;
                } else if (error.response?.status === 403) {
                    const errData = error.response.data || {};
                    if (errData.code === 50013) {
                        console.log(chalk.red.bold(`${this.getLogPrefix()} 🚫 MISSING PERMISSIONS (Code 50013) in channel #${channelId}!`));
                        console.log(chalk.yellow(`Account does not have "Send Messages" permission in this channel (locked/read-only). Retrying in 10s...`));
                    } else {
                        console.log(chalk.red(`${this.getLogPrefix()} 🚫 403 Forbidden in channel #${channelId}: ${errData.message || 'Access Denied'}`));
                    }
                    pendingMessage = null;
                    isPendingPriority = false;
                    isSending = false;
                    if (spamTimeout) clearTimeout(spamTimeout);
                    spamTimeout = setTimeout(sendNext, 10000);
                    return;
                } else {
                    console.log(chalk.red(`${this.getLogPrefix()} ✖ Error: ${error.message}`));
                    pendingMessage = null;
                    isPendingPriority = false;
                }
            } finally {
                isSending = false;
            }

            // If more priority messages are queued, fire the next one immediately without delay!
            if (this.priorityQueue.length > 0) {
                setImmediate(sendNext);
                return;
            }

            // If automatic spam is paused, stop here without scheduling next timer
            if (!isSpammingActive) {
                return;
            }

            // Calculate next delay based on config.delay and dynamic channel slowmode
            const configuredDelay = config.delay || 4000;
            const currentSlowmodeSec = this.channelSlowmodes.get(channelId) || 0;
            const slowmodeMs = currentSlowmodeSec > 0 ? (currentSlowmodeSec * 1000 + 150) : 0;

            // Speed is the maximum between config.delay and the channel slowmode duration
            let baseDelay = Math.max(configuredDelay, slowmodeMs);

            let nextDelay = baseDelay;
            if (config.randomizeDelay !== false) {
                const jitter = (Math.random() * 0.4 - 0.2) * baseDelay;
                nextDelay = Math.max(1000, baseDelay + jitter);
            }

            if (spamTimeout) {
                clearTimeout(spamTimeout);
                spamTimeout = null;
            }
            spamTimeout = setTimeout(sendNext, nextDelay);
        };

        this.triggerSend = () => {
            // If already sending right now, the message is already in this.priorityQueue.
            // When the in-flight send finishes, sendNext will immediately process it via setImmediate(sendNext)!
            if (isSending) {
                return;
            }

            const now = Date.now();
            if (now < cooldownEndTime) {
                console.log(chalk.yellow(`${this.getLogPrefix()} Channel in slowmode. Will fire priority message in full speed the moment cooldown ends!`));
                if (spamTimeout) clearTimeout(spamTimeout);
                spamTimeout = setTimeout(sendNext, cooldownEndTime - now);
                return;
            }

            // Cancel any pending background spam timer and fire immediately!
            if (spamTimeout) {
                clearTimeout(spamTimeout);
                spamTimeout = null;
            }
            sendNext();
        };

        if (!this.channelTimers) this.channelTimers = new Map();
        this.channelTimers.set(channelId, () => {
            if (spamTimeout) {
                clearTimeout(spamTimeout);
                spamTimeout = null;
            }
        });

        sendNext();
    }

    async sendMessage(channelId, payload) {
        // Non-blocking typing indicator with ZERO added jitter delay
        if (config.simulateTyping !== false) {
            this.makeRequest('post', `channels/${channelId}/typing`, {}).catch(() => {});
        }

        let body;
        if (typeof payload === 'string') {
            body = { content: payload };
        } else if (payload && typeof payload === 'object') {
            body = {
                content: payload.content || '',
                ...(payload.sticker_ids ? { sticker_ids: payload.sticker_ids } : {}),
                ...(payload.replyToMessageId ? {
                    message_reference: {
                        message_id: payload.replyToMessageId
                    },
                    allowed_mentions: {
                        replied_user: true
                    }
                } : {})
            };
        } else {
            body = { content: String(payload) };
        }

        const nonce = Date.now().toString() + Math.random().toString().slice(2, 8);
        body.nonce = nonce;
        recentNonces.add(nonce);
        if (recentNonces.size > 500) {
            const firstKey = recentNonces.values().next().value;
            recentNonces.delete(firstKey);
        }

        const res = await this.makeRequest('post', `channels/${channelId}/messages`, body);
        if (res?.data?.id) {
            botSentMessageIds.add(res.data.id);
            if (botSentMessageIds.size > 500) {
                const firstKey = botSentMessageIds.values().next().value;
                botSentMessageIds.delete(firstKey);
            }
        }
        return res;
    }

    async stop() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
        if (this.channelTimers) {
            for (const cancel of this.channelTimers.values()) {
                cancel();
            }
            this.channelTimers.clear();
        }
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
    }
}

// Main execution
async function main() {
    const brandBanner = [
        "█████╗ ██╗  ██╗██╗  ██╗██╗  ██╗",
        "██╔══██╗██║  ██║██║ ██╔╝██║  ██║",
        "███████║███████║█████═╝ ██║  ██║",
        "██╔══██║╚════██║██  ██╗ ██║  ██║",
        "██║  ██║     ██║██║  ██╗╚██████╔╝",
        "╚═╝  ╚═╝     ╚═╝╚═╝  ╚═╝ ╚═════╝"
    ].join('\n');

    console.log(chalk.redBright.bold('\n' + brandBanner));
    console.log(chalk.magenta.bold(`          ★ A 4 K U   S P A M M E R ★`));
    console.log(chalk.cyan(`            Starting Bot v${version}\n`));

    sessions = [];

    for (const tokenConfig of config.tokens) {
        if (!tokenConfig.token || tokenConfig.channelIds.length === 0) {
            console.log(chalk.yellow(`Skipping invalid token config`));
            continue;
        }

        const session = new DiscordSession(
            tokenConfig.token,
            tokenConfig.channelIds,
            tokenConfig.serverId
        );

        const success = await session.initialize();
        if (success) {
            sessions.push(session);
        }

        // Small delay between token initializations
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    console.log(chalk.green(`Successfully initialized ${sessions.length} sessions`));

    // Terminal console interface for !1, !2, !3, !all, !art, !host
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    printHelpBanner();

    rl.on('line', (line) => {
        executeCommand(line, 'Console');
    });

    // Graceful shutdown
    process.on('SIGINT', async () => {
        console.log(chalk.yellow('\nShutting down...'));
        rl.close();
        for (const session of sessions) {
            await session.stop();
        }
        process.exit(0);
    });
}

// Run the bot
main().catch(error => {
    console.log(chalk.red(`Fatal error: ${error.message}`));
    process.exit(1);
});
