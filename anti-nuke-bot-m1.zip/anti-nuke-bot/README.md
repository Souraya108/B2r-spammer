# Anti-Nuke Bot (Milestone 1)

Bot bảo mật Discord chống nuke: TypeScript `strict`, discord.js v14, SQLite. **Không có website/dashboard, không mở cổng HTTP** — mọi cấu hình nằm trong Discord (`/antinuke settings`).

> Mới là Milestone 1: phát hiện + ghi log + cảnh báo. **Chưa cô lập / khôi phục / Panic / Lockdown.** Xem `docs/PROGRESS.md`.

## Cài đặt

```bash
npm install
cp .env.example .env      # điền DISCORD_TOKEN và DISCORD_CLIENT_ID
npm run build
npm run deploy-commands:prod   # hoặc: npm run deploy-commands (chạy trực tiếp bằng tsx)
npm start
```

Đặt `DEV_GUILD_ID` trong `.env` nếu muốn đăng ký lệnh chỉ cho một server (cập nhật ngay, tiện thử nghiệm).

## Discord Developer Portal

- **Không cần** bật Privileged Intent nào ở Milestone 1 (chỉ dùng `Guilds` + `GuildModeration`).
- Scope mời bot: `bot` và `applications.commands`.
- Quyền bot tối thiểu hiện tại: **View Audit Log**, View Channel, Send Messages, Embed Links (trong kênh cảnh báo). Các quyền khác (Manage Roles, Ban Members…) chỉ cần khi có Quarantine/Recovery ở các milestone sau.
- Đặt role của bot **cao hơn** các role nó cần quản lý (cần cho Quarantine sau này).

## Sử dụng

1. `/antinuke settings` → chọn kênh cảnh báo → **Bật toàn bộ**. Panel cho biết Detector nào thực sự chạy; không bao giờ hiện "BẬT" khi còn Detector bị chặn/suy giảm.
2. `/protection allowlist add` để miễn trừ người/role (có phạm vi, thời hạn, lý do).
3. `/protection security-owner add` (chỉ chủ server) để giao quyền cấu hình.

Quyền: Quản trị viên được xem, bật, bật/tắt Detector; **Security Owner** hoặc chủ server mới được tắt toàn bộ, đổi Profile/Strict Mode, quản lý allowlist.

## Phát triển

```bash
npm run typecheck && npm test
```
