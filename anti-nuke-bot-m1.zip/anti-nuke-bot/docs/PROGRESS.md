# Tiến độ dự án — Advanced Discord Anti-Nuke Security Bot

**Mốc hiện tại: Milestone 1 — "lát cắt dọc" chạy được.** Mã biên dịch sạch (`tsc --noEmit`), 104 test đạt (xem `docs/test-evidence/`).
**Chưa chạy thử trên Discord thật** — chỉ kiểm thử bằng test harness và đối tượng giả lập (xem "Giới hạn đã biết").

## Tiến độ theo Phase (Phần 27)

| Phase | Trạng thái | Ghi chú |
|---|---|---|
| 0 Repository Audit | Không áp dụng | Bắt đầu từ repo rỗng, không có code bot hiện có để kiểm toán |
| 1 Competitor Research | **CHƯA LÀM** | Chưa nghiên cứu Wick/Security/Modly; mọi ô trong Feature Matrix sẽ là `CHƯA XÁC MINH` |
| 2 Feature Matrix | **CHƯA LÀM** | |
| 3 Discord API Verification | Một phần | Chỉ 4 Detector hiện có, đối chiếu với `discord-api-types` (xem `docs/research/discord-api-verification.md`); chưa đối chiếu tài liệu chính thức |
| 4 Architecture Design | Một phần | Kiến trúc thể hiện trong code; chưa có báo cáo Architecture |
| 5 Core Infrastructure | **XONG (mức M1)** | Client, cấu hình, SQLite + migration, logger có che bí mật, vòng đời, Detector Registry |
| 6 Audit Log Monitoring | Một phần | Có `guildAuditLogEntryCreate`, chuẩn hóa, Attribution theo entry. **Chưa có** đối chiếu với sự kiện Gateway, lịch thử lại 0,5→4 s, catch-up sau restart |
| 7 Detector Modules | Một phần | 4 Detector (xem bảng dưới) |
| 8 Behavioral & Risk | Một phần | Risk Score đủ 7 thành phần, Heat theo Actor. **Chưa có** Sequence Rule, Multi-Actor (C luôn = 0), Guild Heat |
| 9 Trust & Anti-Tampering | Một phần | Allowlist (user/role/bot, phạm vi, hạn), Security Owner. **Chưa có** nhóm H, Protected Targets, blocklist, Trusted Bot/App |
| 10 Enforcement | Một phần | Chỉ `LOG_ONLY` và `ALERT` thực thi thật. Resolver đã đủ luật 13.2–13.6 + Phụ lục C |
| 11 Quarantine/Panic/Lockdown | **CHƯA LÀM** | |
| 12 Backup & Recovery | **CHƯA LÀM** | |
| 13 Centralized Settings | Một phần | P1 Tổng quan + trang Category. Bật/Tắt toàn bộ, Strict Mode, Profile, kênh cảnh báo, bật/tắt Category/Detector |
| 14 Commands & UI | Một phần | `/antinuke` (settings, enable, disable, status), `/protection` (allowlist, security-owner) |
| 15 Testing | Một phần | 104 test; xem bên dưới |
| 16 Final Security Audit | **CHƯA LÀM** | |

## Detector (mỗi dòng một Detector)

| ID | Tên | Trạng thái | Test | Giới hạn |
|---|---|---|---|---|
| A01-T | Chống xóa channel (văn bản) | `TESTED` (test harness) | detectors, pipeline | Chưa phân biệt channel Critical (A11); chưa Recovery |
| A01-V | Chống xóa channel (thoại) | `TESTED` (test harness) | detectors | Chưa Recovery |
| B05.1 | Cấp Administrator cho role | `TESTED` (test harness) | detectors, pipeline | Chưa đếm thành viên bị ảnh hưởng; chưa Rollback quyền role |
| C01 | Chống ban hàng loạt | `TESTED` (test harness) | detectors, pipeline, config | Chưa có Protected User (C07) |

"TESTED" nghĩa là có unit + integration test qua harness giả lập, **không** có nghĩa đã chạy trên Discord thật.
Phần 07 liệt kê **122 dòng** (A19 · B25 · C10 · D10 · E10 · F18 · G18 · H12; trong đó B08 chỉ là bí danh của C06 và G16 là khe mở rộng). Đã làm 4 dòng; các dòng còn lại là `NOT_STARTED`.

## Hạng mục đã có test

Limit Engine (biên N/N+1, sự kiện tại T−W, trùng lặp, đảo thứ tự, nhiều Rule, đơn vị >1) · Heat decay · Risk Scoring · Action Resolver (Owner, Attribution, Unknown, TIMEOUT, thứ tự, một hình phạt/Incident) · Pipeline (cooldown, leo thang, Episode lặp lại, self-action, allowlist/phạm vi/hết hạn, cách ly guild, rehydrate sau restart, executor lỗi, file DB thật) · Cấu hình (version, optimistic lock, giao dịch nguyên tử, bền sau restart, precedence) · Trạng thái vận hành (không bao giờ hiển thị ON khi có Detector chưa chạy) · Quyền (live authority, hạ quyền giữa phiên, phiên giả/hết hạn/của người khác, nhấn đúp, rate limit, xung đột cấu hình) · Giới hạn Components V2 (≤40 component, ≤4000 ký tự, `custom_id` ≤100 và không trùng) · Embed cảnh báo · che token.

## Lệch so với đặc tả (đã biết, có chủ ý)

Xem `docs/ASSUMPTIONS.md` (A-004, A-009, A-010, A-011, A-012). Các điểm chính: Attribution chưa đối chiếu Gateway; đổi Preset áp dụng ngay không qua Preview (chưa có override riêng để bảo vệ); trang Category lưu ngay mỗi lần bấm (chưa có nút Lưu); khi Anti-Nuke ở trạng thái TẮT thì sự kiện bị bỏ qua, không ghi.

## Giới hạn đã biết

- **Chưa kiểm chứng trên Discord thật:** panel Components V2 (`editReply` với cờ `IsComponentsV2` trên tin nhắn ephemeral), `guildAuditLogEntryCreate` thực tế, giới hạn 40 component theo tài liệu hiện hành.
- Hệ thống **phản ứng sau** khi Discord đã nhận hành động (00.8); phiên bản này mới chỉ ghi log + cảnh báo, **chưa cô lập/hoàn tác bất kỳ thứ gì**.
- Hàng đợi REST ưu tiên (P0–P3) chưa có; hiện dùng hàng đợi tuần tự theo guild có giới hạn.
- Báo cáo Detector (`docs/detectors/<ID>.md`) và 10 báo cáo Phần 30 chưa tạo.
- Chưa có Fast-Path đo độ trễ; **chưa có số đo hiệu năng**.

## Việc tiếp theo (Milestone 2, đề xuất)

1. Quarantine Engine (Phần 12) + Self-Action Ledger + hàng đợi REST ưu tiên → các Action mặc định (`QUARANTINE`, `REMOVE_MANAGEABLE_DANGEROUS_ROLES`) thực thi thật.
2. Đối chiếu Gateway ↔ Audit Log + lịch thử lại + catch-up sau restart (Phase 6).
3. Trang cấu hình Limit/Action riêng cho Detector, Pause/Resume, Reset (Phần 19.7–19.13).
4. Mở rộng Detector theo nhóm: A (còn lại), B05.2–B05.10, C02–C10.
5. Phase 1–3: nghiên cứu đối thủ và đối chiếu Discord API chính thức.
