# Giả định và quyết định (theo 00.2)

| ID | Bối cảnh | Lựa chọn | Lý do / tác động |
|---|---|---|---|
| A-001 | Chọn phiên bản | Node 22, discord.js 14.28.1, better-sqlite3 13.x, TypeScript 7.0.2, vitest 5.x | Là bản cài được tại thời điểm làm; discord.js 14.28.1 có `ContainerBuilder`, `SectionBuilder`, `MessageFlags.IsComponentsV2` (đã kiểm tra bằng code) |
| A-002 | Database | SQLite (WAL) | Phần 22: mặc định cho một máy. Truy cập qua Repository nên đổi sang PostgreSQL không sửa nghiệp vụ |
| A-003 | Intent | Chỉ `Guilds` + `GuildModeration`; **không** xin `GuildMembers` | Quyền tối thiểu (05.3). Tra cứu thành viên đơn lẻ qua REST không cần intent đặc quyền. Sẽ cần khi làm Role Membership Map / Anti-Raid |
| A-004 | Attribution | Dùng chính entry Audit Log làm nguồn Attribution; chưa đối chiếu sự kiện Gateway | Entry có `executorId` đáng tin; CONFIRMED khi có Executor + Target. Chưa có lịch thử lại 0,5→4 s. **Chưa an toàn để bật hình phạt không hoàn tác** cho tới khi làm đối chiếu Gateway |
| A-005 | Action Policy | Mọi mức leo thang luôn gồm `LOG_ONLY` + `ALERT` | Phụ lục A.3 không liệt kê ALERT ở mọi mức, nhưng 13.5 cấm "bỏ qua im lặng" |
| A-006 | Heat lớp CFG | 3 mỗi sự kiện (như MOD) | 10.2 không nêu lớp CFG |
| A-007 | Đóng Episode | Episode đóng khi khoảng cách từ Violation cuối ≥ max(cooldown, cửa sổ của Rule kích hoạt) | Với cửa sổ trượt, lúc đó mọi sự kiện cũ đã rời cửa sổ nên `count ≤ N` (xấp xỉ chính xác điều kiện 09.5) |
| A-008 | Enable All | Đặt Global bật, **và** bật lại Category/Detector mà quản trị viên đã tắt; không đụng Limit/Action riêng | 19.4: "kích hoạt đồng thời tất cả Module và Detector tương thích". Hiện chưa có override Limit/Action nên chưa có gì để giữ |
| A-009 | Đổi Preset | Áp dụng ngay, chưa có bước Preview | 19.11 yêu cầu Preview; hiện chưa có Individual Override nào để bị ghi đè nên không có gì bị mất. **Phải thêm Preview khi làm override riêng** |
| A-010 | Nút "Lưu" | Mỗi lần bấm Bật/Tắt được lưu ngay | Hiện chỉ có công tắc, không có trường nhập nháp |
| A-011 | Anti-Nuke ở trạng thái TẮT | Bỏ qua sự kiện, không ghi | Tránh dữ liệu vô hạn khi tắt; Pause (ghi tiếp, 19.12) chưa làm |
| A-012 | Hết hạn allowlist | So với giờ thực lúc xử lý, không phải giờ của sự kiện | Đúng với sự kiện trực tiếp; sai lệch nhẹ với catch-up (chưa có). Cần chỉnh khi làm catch-up |
| A-013 | Quyền Strict Mode | Cần Security Owner (cả bật lẫn tắt) | 11.4 không nêu; chọn phương án chặt hơn |
| A-014 | `/antinuke disable` | Mở panel ở bước xác nhận | Disable All cần xác nhận (19.5); dùng chung backend với nút |
| A-015 | Xóa channel không rõ loại | Tính vào A01-T, gắn nhãn `CHANNEL_TYPE_UNKNOWN` | Không bỏ sót; nhãn để hiệu chỉnh sau |
| A-016 | Xóa category (type 4) | Chưa tính vào Detector nào | Thuộc A04 (chưa làm) |
| A-017 | `AuditLogEvent.RoleCreate` cho B05.1 | Có tính (role tạo sẵn Administrator) | Hành vi leo thang đặc quyền; 07 chỉ nói "được thêm quyền" |
