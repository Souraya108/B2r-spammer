# Xác minh Discord API — Milestone 1

**Nguồn dùng:** định nghĩa kiểu `discord-api-types` (v10) và `discord.js@14.28.1` trong `node_modules`, kiểm tra bằng code.
**Chưa đối chiếu tài liệu chính thức của Discord** (Phase 3 còn dở).

| Detector | Sự kiện nguồn | Audit Log action (giá trị đã kiểm tra) | Khóa `changes` dùng | Permission | Intent | Attribution | Kết luận |
|---|---|---|---|---|---|---|---|
| A01-T / A01-V | `guildAuditLogEntryCreate` | `ChannelDelete` = 12 | `type` (number\|string), `name` | View Audit Log | Guilds, GuildModeration | FULL | SUPPORTED |
| B05.1 | `guildAuditLogEntryCreate` | `RoleCreate` = 30, `RoleUpdate` = 31 | `permissions` (**string**, bitfield) | View Audit Log | Guilds, GuildModeration | FULL | SUPPORTED |
| C01 | `guildAuditLogEntryCreate` | `MemberBanAdd` = 22 | — (dùng `targetId`) | View Audit Log | Guilds, GuildModeration | FULL | SUPPORTED |

Ghi chú:
- `ChannelType`: Category = 4, Voice = 2, Stage = 13 (đã kiểm tra). Phân loại A01-T/A01-V dựa vào khóa `type` của entry xóa.
- Thời điểm sự kiện lấy từ `entry.createdTimestamp` (snowflake), không phải lúc bot nhận.
- `entry.executor` có thể rỗng trên đường Gateway; code dự phòng bằng `users.fetch`, và đặt loại actor = `UNKNOWN` nếu không xác định được.
- Chưa kiểm chứng trên Discord thật: độ trễ thực tế của entry, và việc `changes.permissions` luôn có đủ `old`/`new` cho `RoleUpdate`.
