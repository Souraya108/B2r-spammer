import type { Client, Guild } from 'discord.js';
import { readCapabilities } from '../diagnostics/botCapabilities.js';
import { computeDetectorStatus, type DetectorStatus } from '../diagnostics/operationalStatus.js';
import { probeDatabase, type Db } from '../db/database.js';
import { DETECTORS } from '../detectors/registry.js';
import type { ConfigChange, GuildConfigService } from '../config/guildConfig.js';
import type { CategoryId } from '../types.js';

export interface EnableAllReport {
  ok: boolean;
  error?: string;
  total: number;
  active: number;
  notActive: Array<DetectorStatus & { name: string }>;
  warnings: string[];
  newVersion: number;
}

export interface EnableAllDeps {
  client: Client;
  db: Db;
  config: GuildConfigService;
}

const locks = new Map<string, Promise<unknown>>();

/** One mutex per guild: concurrent Enable All requests run one after another (spec 19.4). */
function withGuildLock<T>(guildId: string, fn: () => Promise<T>): Promise<T> {
  const prev = locks.get(guildId) ?? Promise.resolve();
  const next = prev.then(fn, fn);
  locks.set(guildId, next.catch(() => undefined));
  return next;
}

/**
 * Enable All Protections (spec 19.4). Pre-checks (database, permissions, intents, alert channel) feed the per-detector
 * status; the configuration is committed in one transaction. Individual Limit/Action overrides are never touched.
 * Detectors that cannot run are reported with a reason code instead of being shown as ON.
 * Authorization is the caller's job (backend check happens before this is invoked).
 */
export function enableAllProtections(
  deps: EnableAllDeps,
  guild: Guild,
  userId: string,
  expectedVersion: number,
  source: string,
): Promise<EnableAllReport> {
  return withGuildLock(guild.id, async () => {
    const probe = probeDatabase(deps.db);
    if (!probe.ok) {
      return { ok: false, error: `Database lỗi: ${probe.error ?? 'không rõ'}`, total: DETECTORS.length, active: 0, notActive: [], warnings: [], newVersion: expectedVersion };
    }

    const current = deps.config.reload(guild.id);
    const changes: ConfigChange[] = [{ type: 'GLOBAL_ENABLED', value: true }];
    for (const [category, on] of Object.entries(current.categoryEnabled)) {
      if (on === false) changes.push({ type: 'CATEGORY_ENABLED', category: category as CategoryId, value: true });
    }
    for (const [detectorId, on] of Object.entries(current.detectorEnabled)) {
      if (on === false) changes.push({ type: 'DETECTOR_ENABLED', detectorId, value: true });
    }

    const next = deps.config.commit(guild.id, expectedVersion, changes, { changedBy: userId, source });

    const caps = readCapabilities(deps.client, guild, next.alertChannelId);
    const statuses = DETECTORS.map((d) => ({ name: d.descriptor.name, ...computeDetectorStatus(d.descriptor, true, caps) }));
    const notActive = statuses.filter((s) => s.status !== 'ACTIVE');
    return {
      ok: true,
      total: statuses.length,
      active: statuses.length - notActive.length,
      notActive,
      warnings: ['Initial Snapshot: chưa hỗ trợ trong phiên bản này (Backup thuộc Phase 12).'],
      newVersion: next.configVersion,
    };
  });
}

/** Disable All (spec 19.5): turns enforcement off; configuration, incidents and history are kept. */
export function disableAllProtections(deps: Pick<EnableAllDeps, 'config'>, guildId: string, userId: string, expectedVersion: number, source: string): number {
  return deps.config.commit(guildId, expectedVersion, [{ type: 'GLOBAL_ENABLED', value: false }], { changedBy: userId, source }).configVersion;
}
