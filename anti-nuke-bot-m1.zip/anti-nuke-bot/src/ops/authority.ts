import type { Guild } from 'discord.js';
import type { SecurityOwnerRepo } from '../db/repositories/securityOwnerRepo.js';
import type { CategoryId } from '../types.js';

export type AuthorityLevel = 'NONE' | 'ADMIN' | 'SECURITY_OWNER' | 'SERVER_OWNER';
const RANK: Record<AuthorityLevel, number> = { NONE: 0, ADMIN: 1, SECURITY_OWNER: 2, SERVER_OWNER: 3 };

export type Operation =
  | 'VIEW'
  | 'ENABLE_ALL'
  | 'DISABLE_ALL'
  | 'CATEGORY_TOGGLE'
  | 'DETECTOR_TOGGLE'
  | 'PRESET'
  | 'STRICT_MODE'
  | 'ALERT_CHANNEL'
  | 'MANAGE_ALLOWLIST'
  | 'MANAGE_SECURITY_OWNERS';

/** Spec 11.4. Self-protection (category H) and trust management need Security Owner or above. */
export function requiredLevel(op: Operation, category?: CategoryId): AuthorityLevel {
  switch (op) {
    case 'VIEW':
    case 'ENABLE_ALL':
    case 'ALERT_CHANNEL':
      return 'ADMIN';
    case 'CATEGORY_TOGGLE':
    case 'DETECTOR_TOGGLE':
      return category === 'H' ? 'SECURITY_OWNER' : 'ADMIN';
    case 'DISABLE_ALL':
    case 'PRESET':
    case 'STRICT_MODE':
    case 'MANAGE_ALLOWLIST':
      return 'SECURITY_OWNER';
    case 'MANAGE_SECURITY_OWNERS':
      return 'SERVER_OWNER';
  }
}

export function can(level: AuthorityLevel, op: Operation, category?: CategoryId): boolean {
  return RANK[level] >= RANK[requiredLevel(op, category)];
}

export const LEVEL_LABEL_VI: Record<AuthorityLevel, string> = {
  NONE: 'thành viên thường',
  ADMIN: 'Quản trị viên',
  SECURITY_OWNER: 'Security Owner',
  SERVER_OWNER: 'Chủ server',
};

/**
 * Resolves the user's authority from LIVE data on every interaction (spec 19.21): the member is re-fetched over REST,
 * never trusted from a stale cache or from the message the button sits on.
 */
export async function resolveAuthority(guild: Guild, userId: string, owners: SecurityOwnerRepo): Promise<AuthorityLevel> {
  if (guild.ownerId === userId) return 'SERVER_OWNER';
  if (owners.has(guild.id, userId)) return 'SECURITY_OWNER';
  try {
    const member = await guild.members.fetch({ user: userId, force: true });
    return member.permissions.has('Administrator') ? 'ADMIN' : 'NONE';
  } catch {
    return 'NONE';
  }
}
