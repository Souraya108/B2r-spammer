import type { Client, Guild } from 'discord.js';
import type { GuildConfigService } from '../../config/guildConfig.js';
import { readCapabilities } from '../../diagnostics/botCapabilities.js';
import { collectHealth, type HealthItem } from '../../diagnostics/health.js';
import {
  computeDetectorStatus,
  computeOverallStatus,
  type DetectorStatus,
  type OverallStatus,
} from '../../diagnostics/operationalStatus.js';
import type { Db } from '../../db/database.js';
import { ACTION_LABELS_VI } from '../../actions/actionCatalog.js';
import { activeCategories, DETECTORS, detectorsInCategory } from '../../detectors/registry.js';
import type { CategoryId, ProfileId } from '../../types.js';

export interface OverviewModel {
  sessionId: string;
  overall: OverallStatus;
  profile: ProfileId;
  strictMode: boolean;
  alertChannelId: string | null;
  modules: { total: number; active: number; disabled: number };
  detectors: { total: number; active: number; restricted: number; unsupported: number; disabled: number };
  health: HealthItem[];
  warnings: string[];
  categories: CategoryId[];
}

export interface DetectorRow {
  id: string;
  name: string;
  status: DetectorStatus;
  enabled: boolean;
  limitText: string;
  firstActionText: string;
}

export interface CategoryModel {
  sessionId: string;
  category: CategoryId;
  categoryEnabled: boolean;
  page: number;
  pages: number;
  rows: DetectorRow[];
}

export const DETECTORS_PER_PAGE = 8;

export interface ModelDeps {
  client: Client;
  db: Db;
  config: GuildConfigService;
  mailboxStats: () => { queued: number; rejected: number };
}

function statusesFor(deps: ModelDeps, guild: Guild) {
  const cfg = deps.config.get(guild.id);
  const caps = readCapabilities(deps.client, guild, cfg.alertChannelId);
  const rows = DETECTORS.map((d) => {
    const settings = deps.config.resolveFrom(cfg, d.descriptor);
    return { d, settings, status: computeDetectorStatus(d.descriptor, settings.enabled, caps) };
  });
  return { cfg, caps, rows };
}

export function buildOverviewModel(deps: ModelDeps, guild: Guild, sessionId: string): OverviewModel {
  const { cfg, caps, rows } = statusesFor(deps, guild);
  const health = collectHealth({ client: deps.client, guild, db: deps.db, caps, mailbox: deps.mailboxStats() });
  const coreFailed = health.some((h) => h.name === 'Database' && h.status === 'FAILED');
  const statuses = rows.map((r) => r.status);
  const categories = activeCategories();

  let activeModules = 0;
  let disabledModules = 0;
  for (const category of categories) {
    const inCategory = rows.filter((r) => r.d.descriptor.category === category);
    if (inCategory.some((r) => r.status.status === 'ACTIVE')) activeModules++;
    if (!cfg.enabled || cfg.categoryEnabled[category] === false) disabledModules++;
  }

  const warnings: string[] = [];
  if (!caps.alertChannelUsable) warnings.push('Chưa có kênh cảnh báo dùng được — cảnh báo sẽ chỉ gửi qua DM chủ server.');
  const missingPerms = health.find((h) => h.name === 'Quyền của bot' && h.status !== 'HEALTHY');
  if (missingPerms) warnings.push(`${missingPerms.detail}. Hãy đặt role của bot cao hơn các role cần quản lý.`);

  return {
    sessionId,
    overall: computeOverallStatus(cfg.enabled, statuses, coreFailed),
    profile: cfg.profile,
    strictMode: cfg.strictMode,
    alertChannelId: cfg.alertChannelId,
    modules: { total: categories.length, active: activeModules, disabled: disabledModules },
    detectors: {
      total: statuses.length,
      active: statuses.filter((s) => s.status === 'ACTIVE').length,
      restricted: statuses.filter((s) => s.status === 'DEGRADED' || s.status === 'PERMISSION_BLOCKED').length,
      unsupported: statuses.filter((s) => s.status === 'UNSUPPORTED').length,
      disabled: statuses.filter((s) => s.status === 'DISABLED').length,
    },
    health,
    warnings,
    categories,
  };
}

function limitText(rules: Array<{ maxActions: number; windowSeconds: number }>, instant: boolean): string {
  if (instant) return 'tức thì';
  return rules.map((r) => `${r.maxActions}/${r.windowSeconds}s`).join(' + ');
}

export function buildCategoryModel(deps: ModelDeps, guild: Guild, sessionId: string, category: CategoryId, page: number): CategoryModel {
  const { cfg, caps } = statusesFor(deps, guild);
  const all = detectorsInCategory(category);
  const pages = Math.max(1, Math.ceil(all.length / DETECTORS_PER_PAGE));
  const safePage = Math.min(Math.max(0, page), pages - 1);
  const rows: DetectorRow[] = all.slice(safePage * DETECTORS_PER_PAGE, (safePage + 1) * DETECTORS_PER_PAGE).map((module) => {
    const d = module.descriptor;
    const settings = deps.config.resolveFrom(cfg, d);
    return {
      id: d.id,
      name: d.name,
      status: computeDetectorStatus(d, settings.enabled, caps),
      enabled: cfg.detectorEnabled[d.id] ?? true,
      limitText: limitText(settings.rules, settings.instant),
      firstActionText: settings.policy.FIRST.map((a) => ACTION_LABELS_VI[a]).join(', '),
    };
  });
  return { sessionId, category, categoryEnabled: cfg.categoryEnabled[category] ?? true, page: safePage, pages, rows };
}
