import {
  MessageFlags,
  type ChatInputCommandInteraction,
  type Client,
  type ContainerBuilder,
  type Guild,
  type MessageComponentInteraction,
} from 'discord.js';
import { TIMING } from '../../config/defaults.js';
import { ConfigConflictError, type ConfigChange, type GuildConfigService } from '../../config/guildConfig.js';
import { errorMessage, type Logger } from '../../core/logger.js';
import type { Db } from '../../db/database.js';
import type { SecurityOwnerRepo } from '../../db/repositories/securityOwnerRepo.js';
import { UiSessionRepo, type PanelView, type UiSession } from '../../db/repositories/uiSessionRepo.js';
import { activeCategories, getDetector } from '../../detectors/registry.js';
import { isAlertChannelUsable } from '../../diagnostics/botCapabilities.js';
import { can, LEVEL_LABEL_VI, requiredLevel, resolveAuthority, type AuthorityLevel, type Operation } from '../../ops/authority.js';
import { disableAllProtections, enableAllProtections, type EnableAllReport } from '../../ops/enableAll.js';
import type { CategoryId, ProfileId } from '../../types.js';
import { parseCustomId } from './customId.js';
import { buildCategoryModel, buildOverviewModel, type ModelDeps } from './viewModel.js';
import { buildCategoryContainer, buildConfirmDisableContainer, buildOverviewContainer, STATUS_LABEL_VI } from './views.js';

export interface PanelDeps extends ModelDeps {
  client: Client;
  db: Db;
  config: GuildConfigService;
  owners: SecurityOwnerRepo;
  log: Logger;
}

type Request = { op: Operation; category?: CategoryId };

const isCategory = (v: string | undefined): v is CategoryId => !!v && (activeCategories() as string[]).includes(v);

/**
 * `/antinuke settings`: ephemeral Components V2 panel. Each component interaction goes through the exact sequence of
 * spec 19.21: dedupe → guild → session (owner, expiry) → rate limit → LIVE authority → operation check → optimistic
 * config version → transactional write → response. Hiding a button is never the access control; this code is.
 */
export class SettingsPanel {
  private readonly sessions: UiSessionRepo;
  private readonly seen = new Map<string, number>();
  private readonly userHits = new Map<string, number[]>();

  constructor(private readonly deps: PanelDeps) {
    this.sessions = new UiSessionRepo(deps.db);
  }

  // ---------- slash command entry ----------
  async open(interaction: ChatInputCommandInteraction, startOnConfirmDisable = false): Promise<void> {
    const guild = interaction.guild;
    if (!guild) {
      await interaction.reply({ content: 'Lệnh này chỉ dùng được trong máy chủ.', flags: MessageFlags.Ephemeral });
      return;
    }
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const level = await resolveAuthority(guild, interaction.user.id, this.deps.owners);
    if (!can(level, 'VIEW')) {
      await interaction.editReply({ content: this.denied('VIEW', level) });
      return;
    }
    if (startOnConfirmDisable && !can(level, 'DISABLE_ALL')) {
      await interaction.editReply({ content: this.denied('DISABLE_ALL', level) });
      return;
    }
    const cfg = this.deps.config.reload(guild.id);
    const view: PanelView = startOnConfirmDisable
      ? { view: 'CONFIRM_DISABLE', until: Date.now() + TIMING.confirmSeconds * 1000 }
      : { view: 'OVERVIEW' };
    const session = this.sessions.create(guild.id, interaction.user.id, view, cfg.configVersion, this.expiry());
    await interaction.editReply({ components: [this.render(guild, session)], flags: MessageFlags.IsComponentsV2 });
  }

  // ---------- component entry ----------
  async handle(interaction: MessageComponentInteraction): Promise<void> {
    const parsed = parseCustomId(interaction.customId);
    if (!parsed) return;
    // (1) duplicate delivery of the same interaction
    if (this.isDuplicate(interaction.id)) return;
    await interaction.deferUpdate();
    const fail = (message: string): Promise<unknown> => interaction.followUp({ content: message, flags: MessageFlags.Ephemeral });

    try {
      // (2) guild context
      const guild = interaction.guild;
      if (!interaction.inGuild() || !guild) return void (await fail('Bảng điều khiển chỉ hoạt động trong máy chủ.'));

      // (3) session exists, belongs to this user and guild, not expired
      const session = this.sessions.get(parsed.sessionId);
      if (!session || session.guildId !== guild.id) return void (await fail('Phiên không hợp lệ. Hãy chạy lại `/antinuke settings`.'));
      if (session.ownerId !== interaction.user.id) return void (await fail('Bảng điều khiển này thuộc về người đã mở nó.'));
      if (session.expiresAt < Date.now()) return void (await fail('Phiên đã hết hạn, hãy chạy lại `/antinuke settings`.'));

      // rate limit per user (spec 19.21)
      if (this.rateLimited(interaction.user.id)) return void (await fail('Bạn thao tác quá nhanh, hãy đợi vài giây.'));

      // (4) LIVE authority
      const level = await resolveAuthority(guild, interaction.user.id, this.deps.owners);
      const request = this.requestFor(parsed.action, parsed.args);
      if (!request) return void (await fail('Thao tác không hợp lệ.'));
      if (!can(level, request.op, request.category)) {
        this.deps.log.warn('panel_unauthorized', { guildId: guild.id, userId: interaction.user.id, op: request.op });
        return void (await fail(this.denied(request.op, level, request.category)));
      }

      // (6)-(8) validate input, check version, execute
      const notice = await this.execute(interaction, guild, session, parsed.action, parsed.args);
      const fresh = this.sessions.get(session.id) ?? session;
      await interaction.editReply({ components: [this.render(guild, fresh)], flags: MessageFlags.IsComponentsV2 });
      if (notice) await interaction.followUp({ content: notice, flags: MessageFlags.Ephemeral });
    } catch (err) {
      if (err instanceof ConfigConflictError) {
        await fail('Cấu hình vừa được người khác thay đổi. Bấm **Làm mới** rồi thử lại.');
        return;
      }
      this.deps.log.error('panel_error', { error: errorMessage(err) });
      await fail('Đã xảy ra lỗi khi xử lý thao tác. Cấu hình chưa bị thay đổi.');
    }
  }

  // ---------- internals ----------
  private requestFor(action: string, args: string[]): Request | null {
    switch (action) {
      case 'ov':
      case 'ref':
      case 'cat':
      case 'catp':
      case 'disx':
        return { op: 'VIEW' };
      case 'ena':
        return { op: 'ENABLE_ALL' };
      case 'dis':
      case 'disc':
        return { op: 'DISABLE_ALL' };
      case 'str':
        return { op: 'STRICT_MODE' };
      case 'pre':
        return { op: 'PRESET' };
      case 'ch':
        return { op: 'ALERT_CHANNEL' };
      case 'cattog':
        return isCategory(args[0]) ? { op: 'CATEGORY_TOGGLE', category: args[0] } : null;
      case 'dt': {
        const detector = args[0] ? getDetector(args[0]) : undefined;
        return detector ? { op: 'DETECTOR_TOGGLE', category: detector.descriptor.category } : null;
      }
      default:
        return null;
    }
  }

  /** Performs the action. Returns an optional ephemeral notice for the user. */
  private async execute(
    interaction: MessageComponentInteraction,
    guild: Guild,
    session: UiSession,
    action: string,
    args: string[],
  ): Promise<string | null> {
    const { config } = this.deps;
    const userId = interaction.user.id;
    const meta = { changedBy: userId, source: 'settings-panel' };
    const commit = (changes: ConfigChange[]): void => {
      const next = config.commit(guild.id, session.configVersion, changes, meta);
      this.sessions.update(session.id, session.state, next.configVersion, this.expiry());
      session.configVersion = next.configVersion;
    };
    const setView = (view: PanelView, version = session.configVersion): void => {
      this.sessions.update(session.id, view, version, this.expiry());
      session.state = view;
    };

    switch (action) {
      case 'ov':
        setView({ view: 'OVERVIEW' });
        return null;
      case 'disx':
        setView({ view: 'OVERVIEW' });
        return null;
      case 'ref': {
        const fresh = config.reload(guild.id);
        setView(session.state.view === 'CONFIRM_DISABLE' ? { view: 'OVERVIEW' } : session.state, fresh.configVersion);
        return null;
      }
      case 'cat':
      case 'catp': {
        const category = action === 'cat' ? this.selectedValue(interaction) : args[0];
        if (!isCategory(category ?? undefined)) return 'Nhóm bảo vệ không hợp lệ.';
        const page = action === 'catp' ? Number.parseInt(args[1] ?? '0', 10) : 0;
        setView({ view: 'CATEGORY', category: category!, page: Number.isFinite(page) ? page : 0 });
        return null;
      }
      case 'ena': {
        const report = await enableAllProtections(this.deps, guild, userId, session.configVersion, meta.source);
        if (!report.ok) return `❌ Không thể bật: ${report.error ?? 'lỗi không rõ'}`;
        this.sessions.update(session.id, { view: 'OVERVIEW' }, report.newVersion, this.expiry());
        session.configVersion = report.newVersion;
        return this.formatEnableReport(report);
      }
      case 'dis':
        setView({ view: 'CONFIRM_DISABLE', until: Date.now() + TIMING.confirmSeconds * 1000 });
        return null;
      case 'disc': {
        const state = session.state;
        if (state.view !== 'CONFIRM_DISABLE' || state.until < Date.now()) {
          setView({ view: 'OVERVIEW' });
          return 'Yêu cầu xác nhận đã hết hạn. Hãy bấm **Tắt toàn bộ** lại nếu vẫn muốn tắt.';
        }
        const version = disableAllProtections(this.deps, guild.id, userId, session.configVersion, meta.source);
        this.sessions.update(session.id, { view: 'OVERVIEW' }, version, this.expiry());
        session.configVersion = version;
        return '⚪ Đã tắt toàn bộ Anti-Nuke. Cấu hình, Incident và lịch sử vẫn được giữ.';
      }
      case 'str': {
        const current = config.reload(guild.id);
        commit([{ type: 'STRICT_MODE', value: !current.strictMode }]);
        return null;
      }
      case 'pre': {
        const value = this.selectedValue(interaction);
        if (value !== 'BALANCED' && value !== 'STRICT') return 'Profile không hợp lệ.';
        const changes: ConfigChange[] = [{ type: 'PROFILE', value: value as ProfileId }];
        if (value === 'STRICT') changes.push({ type: 'STRICT_MODE', value: true });
        commit(changes);
        return value === 'STRICT' ? 'Đã chuyển sang **STRICT** và bật Strict Mode.' : 'Đã chuyển sang **BALANCED**.';
      }
      case 'ch': {
        const channelId = this.selectedValue(interaction);
        if (!channelId) return 'Chưa chọn kênh.';
        const channel = guild.channels.cache.get(channelId);
        if (!channel || !isAlertChannelUsable(guild, channelId)) {
          return 'Bot không gửi được tin nhắn và Embed trong kênh đó. Hãy cấp quyền Xem kênh, Gửi tin nhắn và Nhúng liên kết cho bot.';
        }
        commit([{ type: 'ALERT_CHANNEL', value: channelId }]);
        return `Đã đặt kênh cảnh báo: <#${channelId}>.`;
      }
      case 'cattog': {
        const category = args[0] as CategoryId;
        const current = config.reload(guild.id);
        commit([{ type: 'CATEGORY_ENABLED', category, value: !(current.categoryEnabled[category] ?? true) }]);
        return null;
      }
      case 'dt': {
        const detectorId = args[0]!;
        const current = config.reload(guild.id);
        commit([{ type: 'DETECTOR_ENABLED', detectorId, value: !(current.detectorEnabled[detectorId] ?? true) }]);
        return null;
      }
      default:
        return 'Thao tác không hợp lệ.';
    }
  }

  private render(guild: Guild, session: UiSession): ContainerBuilder {
    const state = session.state;
    if (state.view === 'CONFIRM_DISABLE') {
      return buildConfirmDisableContainer(session.id, Math.max(0, Math.ceil((state.until - Date.now()) / 1000)));
    }
    if (state.view === 'CATEGORY' && isCategory(state.category)) {
      return buildCategoryContainer(buildCategoryModel(this.deps, guild, session.id, state.category, state.page));
    }
    return buildOverviewContainer(buildOverviewModel(this.deps, guild, session.id));
  }

  private formatEnableReport(r: EnableAllReport): string {
    const lines = [`✅ Đã bật Anti-Nuke: **${r.active}/${r.total}** Detector đang hoạt động.`];
    if (r.notActive.length > 0) {
      lines.push('Detector chưa hoạt động:');
      for (const s of r.notActive) lines.push(`• \`${s.id}\` ${s.name} — ${STATUS_LABEL_VI[s.status]} (${s.reasons.join(', ')}): ${s.detail}`);
    }
    lines.push(...r.warnings.map((w) => `ℹ️ ${w}`));
    return lines.join('\n').slice(0, 1900);
  }

  private denied(op: Operation, level: AuthorityLevel, category?: CategoryId): string {
    return `Bạn không có quyền thực hiện thao tác này. Cần tối thiểu: **${LEVEL_LABEL_VI[requiredLevel(op, category)]}** (bạn hiện là ${LEVEL_LABEL_VI[level]}).`;
  }

  private selectedValue(interaction: MessageComponentInteraction): string | null {
    if (interaction.isStringSelectMenu() || interaction.isChannelSelectMenu()) return interaction.values[0] ?? null;
    return null;
  }

  private expiry(): number {
    return Date.now() + TIMING.uiSessionMinutes * 60_000;
  }

  private isDuplicate(interactionId: string): boolean {
    const now = Date.now();
    for (const [id, ts] of this.seen) if (now - ts > 60_000) this.seen.delete(id);
    if (this.seen.has(interactionId)) return true;
    this.seen.set(interactionId, now);
    return false;
  }

  private rateLimited(userId: string): boolean {
    const { max, windowSeconds } = TIMING.interactionRateLimit;
    const now = Date.now();
    const recent = (this.userHits.get(userId) ?? []).filter((t) => now - t < windowSeconds * 1000);
    recent.push(now);
    this.userHits.set(userId, recent);
    return recent.length > max;
  }
}
