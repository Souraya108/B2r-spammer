import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  ContainerBuilder,
  SectionBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  StringSelectMenuBuilder,
  TextDisplayBuilder,
} from 'discord.js';
import { CATEGORY_LABELS } from '../../detectors/registry.js';
import type { HealthStatus, OperationalStatus } from '../../types.js';
import type { OverallStatus } from '../../diagnostics/operationalStatus.js';
import { buildCustomId } from './customId.js';
import type { CategoryModel, OverviewModel } from './viewModel.js';

const OVERALL: Record<OverallStatus, { label: string; color: number; icon: string }> = {
  ON: { label: 'BẬT', color: 0x2ecc71, icon: '🟢' },
  OFF: { label: 'TẮT', color: 0x95a5a6, icon: '⚪' },
  DEGRADED: { label: 'SUY GIẢM', color: 0xf1c40f, icon: '🟡' },
  FAILED: { label: 'LỖI', color: 0xe74c3c, icon: '🔴' },
};

const HEALTH_ICON: Record<HealthStatus, string> = {
  HEALTHY: '🟢',
  DEGRADED: '🟡',
  FAILED: '🔴',
  DISABLED: '⚪',
  UNSUPPORTED: '⚫',
  PERMISSION_BLOCKED: '🟠',
};

export const STATUS_LABEL_VI: Record<OperationalStatus, string> = {
  ACTIVE: '🟢 Hoạt động',
  PAUSED: '⏸️ Tạm dừng',
  DISABLED: '⚪ Đã tắt',
  DEGRADED: '🟡 Suy giảm',
  PERMISSION_BLOCKED: '🟠 Thiếu quyền',
  UNSUPPORTED: '⚫ Không hỗ trợ',
  FAILED: '🔴 Lỗi',
};

const text = (content: string): TextDisplayBuilder => new TextDisplayBuilder().setContent(content);
const separator = (): SeparatorBuilder => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
const button = (id: string, label: string, style: ButtonStyle, disabled = false): ButtonBuilder =>
  new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style).setDisabled(disabled);

/** Main control page (P1). Everything is inside one Container: a Components V2 message cannot carry `content`/embeds. */
export function buildOverviewContainer(m: OverviewModel): ContainerBuilder {
  const o = OVERALL[m.overall];
  const id = (action: string): string => buildCustomId(m.sessionId, action);

  const profileMenu = new StringSelectMenuBuilder()
    .setCustomId(id('pre'))
    .setPlaceholder('Chọn Protection Profile')
    .addOptions(
      { label: 'BALANCED — cân bằng', value: 'BALANCED', default: m.profile === 'BALANCED', description: 'Ngưỡng hợp lý, hạn chế báo nhầm' },
      { label: 'STRICT — nghiêm ngặt', value: 'STRICT', default: m.profile === 'STRICT', description: 'Ngưỡng chặt hơn, bật Strict Mode' },
    );
  const categoryMenu = new StringSelectMenuBuilder()
    .setCustomId(id('cat'))
    .setPlaceholder('Mở trang cấu hình nhóm bảo vệ')
    .addOptions(m.categories.map((c) => ({ label: `${c} — ${CATEGORY_LABELS[c]}`, value: c })));
  const channelMenu = new ChannelSelectMenuBuilder()
    .setCustomId(id('ch'))
    .setPlaceholder(m.alertChannelId ? 'Đổi kênh cảnh báo' : 'Chọn kênh cảnh báo')
    .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
    .setMinValues(1)
    .setMaxValues(1);

  const healthLines = m.health.map((h) => `${HEALTH_ICON[h.status]} **${h.name}** — ${h.detail}`).join('\n');
  const container = new ContainerBuilder()
    .setAccentColor(o.color)
    .addTextDisplayComponents(
      text(`# 🛡️ Anti-Nuke — ${o.icon} ${o.label}\nBảng điều khiển bảo vệ máy chủ. Hệ thống **phản ứng sau khi** Discord nhận hành động, không chặn trước được.`),
    )
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(
      text(
        `**Thông tin bảo vệ**\n` +
          `Nhóm: **${m.modules.active}**/${m.modules.total} đang hoạt động · ${m.modules.disabled} tắt\n` +
          `Detector: **${m.detectors.active}**/${m.detectors.total} hoạt động · ${m.detectors.restricted} bị hạn chế · ` +
          `${m.detectors.disabled} tắt · ${m.detectors.unsupported} không hỗ trợ`,
      ),
    )
    .addTextDisplayComponents(text(`**Sức khỏe hệ thống**\n${healthLines}`))
    .addTextDisplayComponents(
      text(
        `**Profile:** ${m.profile} · **Strict Mode:** ${m.strictMode ? 'bật' : 'tắt'} · ` +
          `**Kênh cảnh báo:** ${m.alertChannelId ? `<#${m.alertChannelId}>` : 'chưa chọn'}` +
          (m.warnings.length > 0 ? `\n\n⚠️ ${m.warnings.join('\n⚠️ ')}` : ''),
      ),
    )
    .addSeparatorComponents(separator())
    .addActionRowComponents(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        button(id('ena'), 'Bật toàn bộ', ButtonStyle.Success),
        button(id('dis'), 'Tắt toàn bộ', ButtonStyle.Danger),
        button(id('str'), m.strictMode ? 'Tắt Strict Mode' : 'Bật Strict Mode', ButtonStyle.Secondary),
        button(id('ref'), 'Làm mới', ButtonStyle.Secondary),
      ),
    )
    .addActionRowComponents(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(profileMenu))
    .addActionRowComponents(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(categoryMenu))
    .addActionRowComponents(new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(channelMenu));
  return container;
}

/** One category page: each detector is a Section with a toggle accessory; paginated (<= 8 per page). */
export function buildCategoryContainer(m: CategoryModel): ContainerBuilder {
  const container = new ContainerBuilder()
    .setAccentColor(m.categoryEnabled ? 0x3498db : 0x95a5a6)
    .addTextDisplayComponents(
      text(
        `# ${m.category} — ${CATEGORY_LABELS[m.category]}\nNhóm: **${m.categoryEnabled ? 'đang bật' : 'đang tắt'}** · Trang ${m.page + 1}/${m.pages}\n` +
          `Giới hạn và hành động hiển thị theo Profile hiện tại. Tùy chỉnh Limit/Action riêng sẽ có ở phiên bản sau.`,
      ),
    )
    .addSeparatorComponents(separator());

  for (const row of m.rows) {
    container.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          text(
            `**${row.id}** · ${row.name}\n${STATUS_LABEL_VI[row.status.status]} — ${row.status.detail}\n` +
              `Giới hạn: \`${row.limitText}\` · Lần đầu: ${row.firstActionText}`,
          ),
        )
        .setButtonAccessory(
          button(buildCustomId(m.sessionId, 'dt', row.id), row.enabled ? 'Tắt' : 'Bật', row.enabled ? ButtonStyle.Secondary : ButtonStyle.Success),
        ),
    );
  }

  container.addActionRowComponents(
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      button(buildCustomId(m.sessionId, 'catp', m.category, String(m.page - 1)), '◀', ButtonStyle.Secondary, m.page <= 0),
      button(buildCustomId(m.sessionId, 'catp', m.category, String(m.page + 1)), '▶', ButtonStyle.Secondary, m.page >= m.pages - 1),
      button(buildCustomId(m.sessionId, 'cattog', m.category), m.categoryEnabled ? 'Tắt cả nhóm' : 'Bật cả nhóm', ButtonStyle.Secondary),
      button(buildCustomId(m.sessionId, 'ov'), 'Tổng quan', ButtonStyle.Primary),
    ),
  );
  return container;
}

export function buildConfirmDisableContainer(sessionId: string, seconds: number): ContainerBuilder {
  return new ContainerBuilder()
    .setAccentColor(0xe74c3c)
    .addTextDisplayComponents(
      text(
        `# ⚠️ Xác nhận tắt toàn bộ Anti-Nuke\nHệ thống sẽ ngừng phát hiện và phản ứng tự động. Cấu hình, lịch sử Incident và dữ liệu vẫn được giữ.\n` +
          `Xác nhận trong **${seconds} giây**.`,
      ),
    )
    .addActionRowComponents(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        button(buildCustomId(sessionId, 'disc'), 'Xác nhận tắt', ButtonStyle.Danger),
        button(buildCustomId(sessionId, 'disx'), 'Hủy', ButtonStyle.Secondary),
      ),
    );
}
