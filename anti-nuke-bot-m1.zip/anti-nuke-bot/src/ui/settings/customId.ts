export const CUSTOM_ID_PREFIX = 'an';
export const CUSTOM_ID_VERSION = '1';

export interface ParsedCustomId {
  sessionId: string;
  action: string;
  args: string[];
}

/** Format `an:<version>:<sessionId>:<action>[:<arg>...]`, max 100 chars (spec 19.21). */
export function buildCustomId(sessionId: string, action: string, ...args: string[]): string {
  const id = [CUSTOM_ID_PREFIX, CUSTOM_ID_VERSION, sessionId, action, ...args].join(':');
  if (id.length > 100) throw new Error(`custom_id quá dài (${id.length})`);
  return id;
}

/** Parsing only extracts claims; the session in the database is the source of truth, never the custom_id. */
export function parseCustomId(raw: string): ParsedCustomId | null {
  const parts = raw.split(':');
  if (parts.length < 4 || parts[0] !== CUSTOM_ID_PREFIX || parts[1] !== CUSTOM_ID_VERSION) return null;
  const [, , sessionId, action, ...args] = parts;
  if (!sessionId || !action) return null;
  return { sessionId, action, args };
}
