import { EmbedBuilder } from 'discord.js';
import { ACTION_LABELS_VI } from '../../actions/actionCatalog.js';
import type { ActionResult, ExecutionContext } from '../../actions/executor.js';
import type { SkipReason } from '../../engine/policy/actionResolver.js';
import type { RiskLevel } from '../../types.js';

const COLORS: Record<RiskLevel, number> = {
  INFORMATIONAL: 0x95a5a6,
  LOW: 0x3498db,
  MEDIUM: 0xf1c40f,
  HIGH: 0xe67e22,
  CRITICAL: 0xe74c3c,
};

export const SKIP_REASON_VI: Record<SkipReason, string> = {
  INCOMPATIBLE: 'không tương thích với Detector này',
  NOT_IMPLEMENTED: 'chưa được triển khai trong phiên bản này',
  ATTRIBUTION_INSUFFICIENT: 'chưa đủ độ tin cậy xác định người thực hiện',
  ACTOR_NOT_APPLICABLE: 'không áp dụng cho loại người thực hiện này',
  TARGET_PROTECTED: 'đối tượng được bảo vệ (chủ server)',
  RISK_TOO_LOW: 'mức rủi ro chưa đủ để thực hiện',
};

const clip = (text: string, max = 1000): string => (text.length > max ? `${text.slice(0, max - 1)}…` : text);

function actorText(ctx: ExecutionContext): string {
  const who = ctx.actor.id ? `<@${ctx.actor.id}> (\`${ctx.actor.id}\`)` : 'Không xác định';
  const kind = ctx.actor.kind === 'BOT' ? 'bot' : ctx.actor.kind === 'USER' ? 'thành viên' : 'không rõ';
  const owner = ctx.actor.isOwner ? ' · **chủ server, không thể xử lý**' : '';
  return `${who}\nLoại: ${kind} · Độ tin cậy: **${ctx.attribution}**${owner}`;
}

function limitText(ctx: ExecutionContext): string {
  if (ctx.limit.instant) return 'Quy tắc tức thì: vi phạm ngay ở lần đầu tiên.';
  const rule = ctx.limit.rule;
  return rule
    ? `${ctx.limit.count} lần > giới hạn ${rule.maxActions} lần / ${rule.windowSeconds} giây`
    : `${ctx.limit.count} lần`;
}

/** Security alert (EmbedBuilder, spec 21). Contains no tokens or secrets. */
export function buildAlertEmbed(ctx: ExecutionContext, results: readonly ActionResult[]): EmbedBuilder {
  const done = results
    .filter((r) => r.status !== 'SKIPPED')
    .map((r) => `${r.status === 'OK' ? '✅' : '❌'} ${ACTION_LABELS_VI[r.action]} — ${r.detail}`);
  const notRun = ctx.skipped.map((s) => `⏸️ ${ACTION_LABELS_VI[s.action]} — ${SKIP_REASON_VI[s.reason]}`);

  return new EmbedBuilder()
    .setColor(COLORS[ctx.risk.level])
    .setTitle(`🚨 Anti-Nuke: ${ctx.descriptor.name}`)
    .setDescription(ctx.signal.summary)
    .addFields(
      { name: 'Người thực hiện', value: clip(actorText(ctx)), inline: false },
      { name: 'Vi phạm', value: clip(limitText(ctx)), inline: true },
      { name: 'Risk', value: `**${ctx.risk.score}/100** · ${ctx.risk.level}`, inline: true },
      { name: 'Mức leo thang', value: `${ctx.tier}${ctx.repeated ? ' (lặp lại)' : ''}`, inline: true },
      { name: 'Giải thích Risk', value: clip(ctx.risk.explanation) },
      { name: 'Hành động đã thực hiện', value: clip(done.join('\n') || 'Không có') },
      ...(notRun.length > 0 ? [{ name: 'Hành động chưa chạy', value: clip(notRun.join('\n')) }] : []),
    )
    .setFooter({ text: `Incident ${ctx.incidentId} · Detector ${ctx.descriptor.id}` })
    .setTimestamp(ctx.event.ts);
}
