import type { Client } from 'discord.js';
import type { GuildConfigService } from '../config/guildConfig.js';
import type { Logger } from '../core/logger.js';
import type { Db } from '../db/database.js';
import type { AllowlistRepo } from '../db/repositories/allowlistRepo.js';
import type { HistoryRepo } from '../db/repositories/historyRepo.js';
import type { SecurityOwnerRepo } from '../db/repositories/securityOwnerRepo.js';

/** Everything the command handlers need, assembled once in index.ts (single composition root). */
export interface CommandContext {
  client: Client;
  db: Db;
  config: GuildConfigService;
  owners: SecurityOwnerRepo;
  allowlist: AllowlistRepo;
  history: HistoryRepo;
  log: Logger;
  mailboxStats: () => { queued: number; rejected: number };
}
