import { InteractionContextType, PermissionFlagsBits, SlashCommandBuilder } from 'discord.js';
import { activeCategories } from '../detectors/registry.js';

/**
 * Command definitions only (no handlers) so `scripts/deploy-commands.ts` can register them without starting the bot.
 * `default_member_permissions` is only a visibility hint: real authorization is checked in the backend (spec 20.1).
 */
export const antinukeDefinition = new SlashCommandBuilder()
  .setName('antinuke')
  .setDescription('Quản lý hệ thống Anti-Nuke')
  .setContexts(InteractionContextType.Guild)
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addSubcommand((s) => s.setName('settings').setDescription('Mở bảng điều khiển Anti-Nuke'))
  .addSubcommand((s) => s.setName('enable').setDescription('Bật toàn bộ bảo vệ Anti-Nuke'))
  .addSubcommand((s) => s.setName('disable').setDescription('Tắt toàn bộ bảo vệ Anti-Nuke (cần xác nhận)'))
  .addSubcommand((s) => s.setName('status').setDescription('Xem trạng thái và sức khỏe hệ thống'));

const scopeChoices = [
  { name: 'Toàn bộ Detector', value: 'all' },
  ...activeCategories().map((c) => ({ name: `Nhóm ${c}`, value: c })),
];

export const protectionDefinition = new SlashCommandBuilder()
  .setName('protection')
  .setDescription('Quản lý danh sách tin cậy và Security Owner')
  .setContexts(InteractionContextType.Guild)
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addSubcommandGroup((g) =>
    g
      .setName('allowlist')
      .setDescription('Danh sách được miễn trừ khỏi Anti-Nuke')
      .addSubcommand((s) =>
        s
          .setName('add')
          .setDescription('Thêm thành viên/bot hoặc role vào danh sách miễn trừ')
          .addStringOption((o) => o.setName('reason').setDescription('Lý do (bắt buộc)').setRequired(true).setMinLength(3).setMaxLength(200))
          .addUserOption((o) => o.setName('user').setDescription('Thành viên hoặc bot'))
          .addRoleOption((o) => o.setName('role').setDescription('Role'))
          .addStringOption((o) => o.setName('scope').setDescription('Phạm vi miễn trừ (mặc định: toàn bộ)').addChoices(...scopeChoices))
          .addIntegerOption((o) =>
            o.setName('duration_hours').setDescription('Thời hạn (giờ, tối đa 168). Bỏ trống = vĩnh viễn').setMinValue(1).setMaxValue(168),
          ),
      )
      .addSubcommand((s) =>
        s
          .setName('remove')
          .setDescription('Xóa một mục khỏi danh sách miễn trừ')
          .addIntegerOption((o) => o.setName('id').setDescription('ID mục (xem bằng /protection allowlist list)').setRequired(true).setMinValue(1)),
      )
      .addSubcommand((s) => s.setName('list').setDescription('Xem danh sách miễn trừ đang có hiệu lực')),
  )
  .addSubcommandGroup((g) =>
    g
      .setName('security-owner')
      .setDescription('Người có toàn quyền cấu hình Anti-Nuke (chỉ chủ server chỉnh sửa)')
      .addSubcommand((s) =>
        s.setName('add').setDescription('Thêm Security Owner').addUserOption((o) => o.setName('user').setDescription('Thành viên').setRequired(true)),
      )
      .addSubcommand((s) =>
        s.setName('remove').setDescription('Gỡ Security Owner').addUserOption((o) => o.setName('user').setDescription('Thành viên').setRequired(true)),
      )
      .addSubcommand((s) => s.setName('list').setDescription('Xem danh sách Security Owner')),
  );
