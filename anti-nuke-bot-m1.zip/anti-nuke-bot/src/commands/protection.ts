import { MessageFlags, type ChatInputCommandInteraction } from 'discord.js';
import { TIMING } from '../config/defaults.js';
import type { AllowlistScope, SubjectType } from '../db/repositories/allowlistRepo.js';
import { can, LEVEL_LABEL_VI, requiredLevel, resolveAuthority, type Operation } from '../ops/authority.js';
import type { CommandContext } from './context.js';

const scopeText = (scope: AllowlistScope): string =>
  scope.kind === 'ALL' ? 'toàn bộ' : scope.kind === 'CATEGORIES' ? `nhóm ${scope.ids.join(', ')}` : `Detector ${scope.ids.join(', ')}`;

export async function executeProtection(interaction: ChatInputCommandInteraction, ctx: CommandContext): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.reply({ content: 'Lệnh này chỉ dùng được trong máy chủ.', flags: MessageFlags.Ephemeral });
    return;
  }
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const group = interaction.options.getSubcommandGroup(true);
  const sub = interaction.options.getSubcommand(true);
  const level = await resolveAuthority(guild, interaction.user.id, ctx.owners);

  const op: Operation = group === 'security-owner' && sub !== 'list' ? 'MANAGE_SECURITY_OWNERS' : 'MANAGE_ALLOWLIST';
  if (!can(level, op)) {
    ctx.log.warn('protection_unauthorized', { guildId: guild.id, userId: interaction.user.id, op });
    await interaction.editReply(
      `Bạn không có quyền thực hiện thao tác này. Cần tối thiểu: **${LEVEL_LABEL_VI[requiredLevel(op)]}** (bạn hiện là ${LEVEL_LABEL_VI[level]}).`,
    );
    return;
  }
  const now = Date.now();
  const actor = interaction.user.id;

  if (group === 'security-owner') {
    if (sub === 'list') {
      const ids = ctx.owners.list(guild.id);
      await interaction.editReply(ids.length ? `Security Owner:\n${ids.map((i) => `• <@${i}>`).join('\n')}` : 'Chưa có Security Owner nào (chủ server luôn có toàn quyền).');
      return;
    }
    const user = interaction.options.getUser('user', true);
    if (user.bot || user.id === guild.ownerId) {
      await interaction.editReply('Không thể chọn bot hoặc chủ server làm Security Owner.');
      return;
    }
    if (sub === 'add') {
      const added = ctx.owners.add(guild.id, user.id, actor, now);
      if (added) ctx.history.log(guild.id, actor, 'slash:/protection', 'securityOwner.add', null, user.id);
      await interaction.editReply(added ? `✅ Đã thêm <@${user.id}> làm Security Owner.` : 'Người này đã là Security Owner.');
    } else {
      const removed = ctx.owners.remove(guild.id, user.id);
      if (removed) ctx.history.log(guild.id, actor, 'slash:/protection', 'securityOwner.remove', user.id, null);
      await interaction.editReply(removed ? `✅ Đã gỡ <@${user.id}> khỏi Security Owner.` : 'Người này không phải Security Owner.');
    }
    return;
  }

  // allowlist
  if (sub === 'list') {
    const entries = ctx.allowlist.listActive(guild.id, now);
    if (entries.length === 0) {
      await interaction.editReply('Danh sách miễn trừ đang trống.');
      return;
    }
    const lines = entries.map((e) => {
      const who = e.subjectType === 'ROLE' ? `<@&${e.subjectId}>` : `<@${e.subjectId}>`;
      const expiry = e.expiresAt ? `hết hạn <t:${Math.floor(e.expiresAt / 1000)}:R>` : 'vĩnh viễn';
      return `**#${e.id}** ${who} (${e.subjectType}) · ${scopeText(e.scope)} · ${expiry} · ${e.reason}`;
    });
    await interaction.editReply(lines.join('\n').slice(0, 1900));
    return;
  }

  if (sub === 'remove') {
    const id = interaction.options.getInteger('id', true);
    const removed = ctx.allowlist.remove(guild.id, id);
    if (removed) ctx.history.log(guild.id, actor, 'slash:/protection', 'allowlist.remove', String(id), null);
    await interaction.editReply(removed ? `✅ Đã xóa mục #${id}.` : `Không tìm thấy mục #${id}.`);
    return;
  }

  // allowlist add
  const user = interaction.options.getUser('user');
  const role = interaction.options.getRole('role');
  if ((user ? 1 : 0) + (role ? 1 : 0) !== 1) {
    await interaction.editReply('Hãy chọn **đúng một** trong hai: `user` hoặc `role`.');
    return;
  }
  const hours = interaction.options.getInteger('duration_hours');
  if (hours !== null && hours > TIMING.allowlistTempMaxDays * 24) {
    await interaction.editReply(`Thời hạn tối đa là ${TIMING.allowlistTempMaxDays * 24} giờ.`);
    return;
  }
  const scopeValue = interaction.options.getString('scope') ?? 'all';
  const scope: AllowlistScope = scopeValue === 'all' ? { kind: 'ALL' } : { kind: 'CATEGORIES', ids: [scopeValue] };
  const subjectType: SubjectType = role ? 'ROLE' : user!.bot ? 'BOT' : 'USER';
  const subjectId = role ? role.id : user!.id;
  const entry = ctx.allowlist.add({
    guildId: guild.id,
    subjectType,
    subjectId,
    scope,
    expiresAt: hours !== null ? now + hours * 3_600_000 : null,
    createdBy: actor,
    createdAt: now,
    reason: interaction.options.getString('reason', true),
  });
  ctx.history.log(guild.id, actor, 'slash:/protection', 'allowlist.add', null, JSON.stringify({ id: entry.id, subjectType, subjectId, scope, expiresAt: entry.expiresAt }));
  await interaction.editReply(
    `✅ Đã thêm mục miễn trừ **#${entry.id}** (${subjectType}, ${scopeText(scope)}, ${hours !== null ? `${hours} giờ` : 'vĩnh viễn'}). ` +
      'Sự kiện của đối tượng này vẫn được ghi lại làm bằng chứng nhưng không bị xử lý.',
  );
}
