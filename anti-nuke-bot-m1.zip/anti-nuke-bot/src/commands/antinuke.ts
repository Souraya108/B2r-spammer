import { EmbedBuilder, MessageFlags, type ChatInputCommandInteraction } from 'discord.js';
import { can } from '../ops/authority.js';
import { resolveAuthority } from '../ops/authority.js';
import { enableAllProtections } from '../ops/enableAll.js';
import type { SettingsPanel } from '../ui/settings/panel.js';
import { buildOverviewModel } from '../ui/settings/viewModel.js';
import type { CommandContext } from './context.js';

const STATUS_COLOR = { ON: 0x2ecc71, OFF: 0x95a5a6, DEGRADED: 0xf1c40f, FAILED: 0xe74c3c } as const;
const STATUS_VI = { ON: 'BẬT', OFF: 'TẮT', DEGRADED: 'SUY GIẢM', FAILED: 'LỖI' } as const;
const HEALTH_ICON = { HEALTHY: '🟢', DEGRADED: '🟡', FAILED: '🔴', DISABLED: '⚪', UNSUPPORTED: '⚫', PERMISSION_BLOCKED: '🟠' } as const;

export async function executeAntinuke(
  interaction: ChatInputCommandInteraction,
  ctx: CommandContext,
  panel: SettingsPanel,
): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.reply({ content: 'Lệnh này chỉ dùng được trong máy chủ.', flags: MessageFlags.Ephemeral });
    return;
  }
  const sub = interaction.options.getSubcommand();
  if (sub === 'settings') return panel.open(interaction);
  if (sub === 'disable') return panel.open(interaction, true);

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const level = await resolveAuthority(guild, interaction.user.id, ctx.owners);

  if (sub === 'enable') {
    if (!can(level, 'ENABLE_ALL')) {
      await interaction.editReply('Bạn cần quyền **Quản trị viên** để bật Anti-Nuke.');
      return;
    }
    const version = ctx.config.reload(guild.id).configVersion;
    const report = await enableAllProtections(ctx, guild, interaction.user.id, version, 'slash:/antinuke enable');
    if (!report.ok) {
      await interaction.editReply(`❌ Không thể bật: ${report.error ?? 'lỗi không rõ'}`);
      return;
    }
    const lines = [`✅ Đã bật Anti-Nuke: **${report.active}/${report.total}** Detector đang hoạt động.`];
    for (const s of report.notActive) lines.push(`• \`${s.id}\` ${s.name} — ${s.status} (${s.reasons.join(', ')}): ${s.detail}`);
    lines.push(...report.warnings.map((w) => `ℹ️ ${w}`));
    await interaction.editReply(lines.join('\n').slice(0, 1900));
    return;
  }

  // status
  if (!can(level, 'VIEW')) {
    await interaction.editReply('Bạn cần quyền **Quản trị viên** để xem trạng thái.');
    return;
  }
  const m = buildOverviewModel(ctx, guild, 'status');
  const embed = new EmbedBuilder()
    .setColor(STATUS_COLOR[m.overall])
    .setTitle(`🛡️ Anti-Nuke — ${STATUS_VI[m.overall]}`)
    .setDescription(
      `Detector: **${m.detectors.active}/${m.detectors.total}** hoạt động · ${m.detectors.restricted} bị hạn chế · ` +
        `${m.detectors.disabled} tắt · ${m.detectors.unsupported} không hỗ trợ\nProfile: **${m.profile}** · Strict Mode: ${m.strictMode ? 'bật' : 'tắt'}`,
    )
    .addFields({ name: 'Sức khỏe hệ thống', value: m.health.map((h) => `${HEALTH_ICON[h.status]} **${h.name}** — ${h.detail}`).join('\n').slice(0, 1000) });
  if (m.warnings.length > 0) embed.addFields({ name: 'Cảnh báo', value: m.warnings.join('\n').slice(0, 1000) });
  await interaction.editReply({ embeds: [embed] });
}
