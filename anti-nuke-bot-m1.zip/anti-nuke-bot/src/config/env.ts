export interface Env {
  token: string;
  clientId: string;
  devGuildId: string | null;
  databasePath: string;
  logLevel: 'debug' | 'info' | 'warn' | 'error';
}

export function loadEnv(source: NodeJS.ProcessEnv = process.env, opts: { requireToken?: boolean } = {}): Env {
  const requireToken = opts.requireToken ?? true;
  const token = source.DISCORD_TOKEN?.trim() ?? '';
  const clientId = source.DISCORD_CLIENT_ID?.trim() ?? '';
  if (requireToken && !token) throw new Error('Thiếu biến môi trường DISCORD_TOKEN (xem .env.example).');
  const level = source.LOG_LEVEL?.trim().toLowerCase();
  return {
    token,
    clientId,
    devGuildId: source.DEV_GUILD_ID?.trim() || null,
    databasePath: source.DATABASE_PATH?.trim() || './data/antinuke.sqlite',
    logLevel: level === 'debug' || level === 'warn' || level === 'error' ? level : 'info',
  };
}
