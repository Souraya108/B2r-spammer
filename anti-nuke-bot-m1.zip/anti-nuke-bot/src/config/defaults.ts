// The single source of default values (spec 00.1 / Appendix A). Nothing here is hardcoded elsewhere.
import type { DetectorClass, EscalationTier, LimitRule, ProfileId, RiskLevel } from '../types.js';
import type { ActionName } from '../actions/actionCatalog.js';

export type LimitDefault = { instant: true } | { instant: false; rules: LimitRule[] };

const r = (maxActions: number, windowSeconds: number): LimitRule => ({ maxActions, windowSeconds });
const rules = (...list: LimitRule[]): LimitDefault => ({ instant: false, rules: list });
const INSTANT: LimitDefault = { instant: true };

/** Appendix A.1 */
export const CLASS_LIMITS: Record<ProfileId, Record<DetectorClass, LimitDefault>> = {
  BALANCED: {
    DES: rules(r(3, 10)),
    MEM: rules(r(3, 10)),
    CRE: rules(r(5, 10)),
    MOD: rules(r(5, 30)),
    PRM: rules(r(1, 60)),
    CFG: rules(r(1, 3600)),
    EXT: rules(r(3, 30)),
    IMM: INSTANT,
  },
  STRICT: {
    DES: rules(r(2, 10)),
    MEM: rules(r(2, 10)),
    CRE: rules(r(3, 10)),
    MOD: rules(r(3, 30)),
    PRM: INSTANT,
    CFG: INSTANT,
    EXT: rules(r(2, 30)),
    IMM: INSTANT,
  },
};

/** Appendix A.2 (only detectors that differ from their class default). */
export const DETECTOR_LIMIT_OVERRIDES: Record<ProfileId, Record<string, LimitDefault>> = {
  BALANCED: {
    C01: rules(r(3, 10), r(10, 3600)),
  },
  STRICT: {
    C01: rules(r(2, 10), r(6, 3600)),
  },
};

/** Appendix A.3. ALERT is always present so a violation is never silent (assumption A-005). */
export function defaultActionPolicy(
  cls: DetectorClass,
  profile: ProfileId,
): Record<EscalationTier, ActionName[]> {
  const heavy = cls === 'DES' || cls === 'MEM' || cls === 'PRM' || cls === 'IMM';
  const critical: ActionName[] = ['LOG_ONLY', 'ALERT', 'QUARANTINE', 'PANIC_MODE', 'REQUEST_OWNER_CONFIRMATION'];
  const policy: Record<EscalationTier, ActionName[]> = heavy
    ? {
        FIRST: ['LOG_ONLY', 'ALERT', 'QUARANTINE'],
        REPEATED: ['LOG_ONLY', 'ALERT', 'QUARANTINE', 'REMOVE_MANAGEABLE_DANGEROUS_ROLES'],
        HIGH: ['LOG_ONLY', 'ALERT', 'QUARANTINE', 'ROLLBACK_CHANGE', 'RECOVERY'],
        CRITICAL: critical,
      }
    : {
        FIRST: ['LOG_ONLY', 'ALERT'],
        REPEATED: ['LOG_ONLY', 'ALERT', 'QUARANTINE'],
        HIGH: ['LOG_ONLY', 'ALERT', 'REMOVE_UNAUTHORIZED_BOT', 'REMOVE_UNAUTHORIZED_WEBHOOK', 'ROLLBACK_CHANGE'],
        CRITICAL: critical,
      };
  if (profile === 'STRICT' && !policy.FIRST.includes('QUARANTINE')) {
    policy.FIRST = [...policy.FIRST, 'QUARANTINE'];
  }
  return policy;
}

/** Appendix A.4 */
export const TIMING = {
  auditMatchToleranceSeconds: 10,
  cooldownSeconds: 30,
  escalationMemoryHours: 24,
  incidentGroupingMinutes: 15,
  uiSessionMinutes: 15,
  confirmSeconds: 60,
  interactionRateLimit: { max: 10, windowSeconds: 10 },
  allowlistTempMaxDays: 7,
} as const;

/** Spec 10.1 */
export const SEVERITY_POINTS: Record<RiskLevel, number> = {
  INFORMATIONAL: 5,
  LOW: 12,
  MEDIUM: 22,
  HIGH: 32,
  CRITICAL: 40,
};

/** Spec 10.2 — heat added per countable event (CFG is not specified in the spec: treated like MOD, assumption A-006). */
export const HEAT_PER_CLASS: Record<DetectorClass, number> = {
  DES: 10, MEM: 10, PRM: 8, EXT: 5, CRE: 4, MOD: 3, IMM: 15, CFG: 3,
};

export const HEAT_PROFILES = {
  actor: { halfLifeSeconds: 120, warn: 30, action: 60 },
  bot: { halfLifeSeconds: 120, warn: 20, action: 40 },
} as const;

/** Spec 10.1 — Trust Reduction */
export const TRUST_REDUCTION = { NORMAL: 0, TRUSTED: 5, SECURITY_OWNER: 15 } as const;

export const LIMIT_RANGES = {
  maxActions: [0, 1000],
  windowSeconds: [1, 86400],
  cooldownSeconds: [0, 86400],
  maxRulesPerDetector: 3,
} as const;

/** Bounded per-guild queue (spec 23). */
export const QUEUE = { maxPerGuild: 2000, shutdownDrainMs: 8000 } as const;

export const RETENTION = { securityEventsDays: 30, uiSessionsHours: 24 } as const;

/** Prefix written into every audit-log reason the bot sets itself (spec 06.5). */
export const SELF_ACTION_PREFIX = '[AN:';
