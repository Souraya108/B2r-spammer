import type { Db } from '../db/database.js';
import { CLASS_LIMITS, DETECTOR_LIMIT_OVERRIDES, TIMING, defaultActionPolicy, type LimitDefault } from './defaults.js';
import type { ActionName } from '../actions/actionCatalog.js';
import type { DetectorDescriptor } from '../detectors/types.js';
import type { CategoryId, EscalationTier, LimitRule, ProfileId } from '../types.js';

export interface GuildConfig {
  guildId: string;
  enabled: boolean;
  profile: ProfileId;
  strictMode: boolean;
  alertChannelId: string | null;
  /** 0 = never saved (defaults only). Incremented on every successful commit (spec 19.23). */
  configVersion: number;
  categoryEnabled: Partial<Record<CategoryId, boolean>>;
  detectorEnabled: Record<string, boolean>;
}

export type ConfigChange =
  | { type: 'GLOBAL_ENABLED'; value: boolean }
  | { type: 'CATEGORY_ENABLED'; category: CategoryId; value: boolean }
  | { type: 'DETECTOR_ENABLED'; detectorId: string; value: boolean }
  | { type: 'PROFILE'; value: ProfileId }
  | { type: 'STRICT_MODE'; value: boolean }
  | { type: 'ALERT_CHANNEL'; value: string | null };

export interface CommitMeta {
  changedBy: string;
  source: string;
}

export class ConfigConflictError extends Error {
  constructor(public readonly currentVersion: number) {
    super('Cấu hình đã được người khác thay đổi.');
    this.name = 'ConfigConflictError';
  }
}

export interface ResolvedDetectorSettings {
  /** guild enabled AND category enabled AND detector enabled. */
  enabled: boolean;
  profile: ProfileId;
  strictMode: boolean;
  instant: boolean;
  rules: LimitRule[];
  cooldownSeconds: number;
  policy: Record<EscalationTier, ActionName[]>;
}

const defaultConfig = (guildId: string): GuildConfig => ({
  guildId,
  enabled: false,
  profile: 'BALANCED',
  strictMode: false,
  alertChannelId: null,
  configVersion: 0,
  categoryEnabled: {},
  detectorEnabled: {},
});

/**
 * Persistent per-guild configuration. Precedence (spec 09.3): detector override → category → global → preset.
 * This milestone persists enable/disable at every level, preset, Strict Mode and the alert channel; custom limit and
 * action overrides arrive with the Limit/Action pages.
 */
export class GuildConfigService {
  private readonly cache = new Map<string, GuildConfig>();

  constructor(
    private readonly db: Db,
    private readonly now: () => number = Date.now,
  ) {}

  get(guildId: string): GuildConfig {
    const cached = this.cache.get(guildId);
    if (cached) return cached;
    const loaded = this.load(guildId);
    this.cache.set(guildId, loaded);
    return loaded;
  }

  /** Re-reads from the database, bypassing the cache (used before critical decisions and on Refresh). */
  reload(guildId: string): GuildConfig {
    const loaded = this.load(guildId);
    this.cache.set(guildId, loaded);
    return loaded;
  }

  guildsWithConfig(): string[] {
    return (this.db.prepare('SELECT guild_id FROM guild_config').all() as Array<{ guild_id: string }>).map((r) => r.guild_id);
  }

  resolve(guildId: string, descriptor: DetectorDescriptor): ResolvedDetectorSettings {
    return this.resolveFrom(this.get(guildId), descriptor);
  }

  resolveFrom(config: GuildConfig, descriptor: DetectorDescriptor): ResolvedDetectorSettings {
    const categoryOn = config.categoryEnabled[descriptor.category] ?? true;
    const detectorOn = config.detectorEnabled[descriptor.id] ?? true;
    const limit: LimitDefault =
      DETECTOR_LIMIT_OVERRIDES[config.profile][descriptor.id] ?? CLASS_LIMITS[config.profile][descriptor.class];
    let instant = descriptor.limitMode === 'INSTANT_ONLY' || descriptor.instantDefault || limit.instant;
    let rules: LimitRule[] = limit.instant ? [] : limit.rules.map((r) => ({ ...r }));
    if (config.strictMode && descriptor.strictAffected && !instant) {
      rules = rules.map((r) => ({ ...r, maxActions: Math.max(1, Math.ceil(r.maxActions * 0.5)) }));
    }
    if (rules.length === 0) instant = true;
    return {
      enabled: config.enabled && categoryOn && detectorOn,
      profile: config.profile,
      strictMode: config.strictMode,
      instant,
      rules,
      cooldownSeconds: TIMING.cooldownSeconds,
      policy: defaultActionPolicy(descriptor.class, config.profile),
    };
  }

  /**
   * Atomic update (spec 19.18): version check + all changes + history rows in ONE transaction. The cache is only
   * refreshed after the transaction succeeds, so a failure leaves memory and database untouched.
   */
  commit(guildId: string, expectedVersion: number, changes: ConfigChange[], meta: CommitMeta): GuildConfig {
    if (changes.length === 0) return this.reload(guildId);
    const ts = this.now();
    this.db.transaction(() => {
      const row = this.db.prepare('SELECT config_version FROM guild_config WHERE guild_id = ?').get(guildId) as
        | { config_version: number }
        | undefined;
      const current = row?.config_version ?? 0;
      if (current !== expectedVersion) throw new ConfigConflictError(current);
      if (!row) {
        this.db.prepare('INSERT INTO guild_config (guild_id, updated_at, config_version) VALUES (?, ?, 0)').run(guildId, ts);
      }
      const nextVersion = current + 1;
      const before = this.load(guildId);
      const history = this.db.prepare(
        `INSERT INTO configuration_history (guild_id, ts, changed_by, source, key, old_value, new_value, version)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      );
      for (const change of changes) {
        const { key, oldValue, newValue } = this.apply(guildId, before, change);
        history.run(guildId, ts, meta.changedBy, meta.source, key, oldValue, newValue, nextVersion);
      }
      this.db
        .prepare('UPDATE guild_config SET config_version = ?, updated_at = ?, updated_by = ? WHERE guild_id = ?')
        .run(nextVersion, ts, meta.changedBy, guildId);
    })();
    return this.reload(guildId);
  }

  private apply(guildId: string, before: GuildConfig, change: ConfigChange): { key: string; oldValue: string; newValue: string } {
    const bool = (v: boolean): number => (v ? 1 : 0);
    switch (change.type) {
      case 'GLOBAL_ENABLED':
        this.db.prepare('UPDATE guild_config SET enabled = ? WHERE guild_id = ?').run(bool(change.value), guildId);
        return { key: 'global.enabled', oldValue: String(before.enabled), newValue: String(change.value) };
      case 'PROFILE':
        this.db.prepare('UPDATE guild_config SET profile = ? WHERE guild_id = ?').run(change.value, guildId);
        return { key: 'global.profile', oldValue: before.profile, newValue: change.value };
      case 'STRICT_MODE':
        this.db.prepare('UPDATE guild_config SET strict_mode = ? WHERE guild_id = ?').run(bool(change.value), guildId);
        return { key: 'global.strictMode', oldValue: String(before.strictMode), newValue: String(change.value) };
      case 'ALERT_CHANNEL':
        this.db.prepare('UPDATE guild_config SET alert_channel_id = ? WHERE guild_id = ?').run(change.value, guildId);
        return { key: 'global.alertChannel', oldValue: String(before.alertChannelId), newValue: String(change.value) };
      case 'CATEGORY_ENABLED':
        this.db
          .prepare(
            `INSERT INTO category_state (guild_id, category, enabled) VALUES (?, ?, ?)
             ON CONFLICT (guild_id, category) DO UPDATE SET enabled = excluded.enabled`,
          )
          .run(guildId, change.category, bool(change.value));
        return {
          key: `category.${change.category}.enabled`,
          oldValue: String(before.categoryEnabled[change.category] ?? true),
          newValue: String(change.value),
        };
      case 'DETECTOR_ENABLED':
        this.db
          .prepare(
            `INSERT INTO detector_config (guild_id, detector_id, enabled) VALUES (?, ?, ?)
             ON CONFLICT (guild_id, detector_id) DO UPDATE SET enabled = excluded.enabled`,
          )
          .run(guildId, change.detectorId, bool(change.value));
        return {
          key: `detector.${change.detectorId}.enabled`,
          oldValue: String(before.detectorEnabled[change.detectorId] ?? true),
          newValue: String(change.value),
        };
    }
  }

  private load(guildId: string): GuildConfig {
    const row = this.db.prepare('SELECT * FROM guild_config WHERE guild_id = ?').get(guildId) as Record<string, unknown> | undefined;
    if (!row) return defaultConfig(guildId);
    const categoryEnabled: Partial<Record<CategoryId, boolean>> = {};
    for (const r of this.db.prepare('SELECT category, enabled FROM category_state WHERE guild_id = ?').all(guildId) as Array<{
      category: CategoryId;
      enabled: number;
    }>) {
      categoryEnabled[r.category] = r.enabled === 1;
    }
    const detectorEnabled: Record<string, boolean> = {};
    for (const r of this.db.prepare('SELECT detector_id, enabled FROM detector_config WHERE guild_id = ?').all(guildId) as Array<{
      detector_id: string;
      enabled: number;
    }>) {
      detectorEnabled[r.detector_id] = r.enabled === 1;
    }
    return {
      guildId,
      enabled: row.enabled === 1,
      profile: row.profile === 'STRICT' ? 'STRICT' : 'BALANCED',
      strictMode: row.strict_mode === 1,
      alertChannelId: (row.alert_channel_id as string | null) ?? null,
      configVersion: row.config_version as number,
      categoryEnabled,
      detectorEnabled,
    };
  }
}
