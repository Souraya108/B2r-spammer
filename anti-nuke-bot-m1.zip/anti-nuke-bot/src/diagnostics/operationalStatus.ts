import { PermissionFlagsBits } from 'discord.js';
import type { DetectorDescriptor, IntentName } from '../detectors/types.js';
import type { OperationalStatus } from '../types.js';

export type ReasonCode =
  | 'DISABLED_BY_CONFIG'
  | 'UNSUPPORTED'
  | 'INTENT_MISSING'
  | 'MISSING_PERMISSION'
  | 'ALERT_CHANNEL_UNAVAILABLE';

export interface BotCapabilities {
  /** Bot's guild-level permission bitfield (0n when the bot member is unavailable). */
  permissions: bigint;
  intents: ReadonlySet<IntentName>;
  alertChannelUsable: boolean;
}

export interface DetectorStatus {
  id: string;
  status: OperationalStatus;
  reasons: ReasonCode[];
  /** Human-readable details, e.g. the names of missing permissions. */
  detail: string;
}

const PERMISSION_NAMES = new Map<bigint, string>(
  Object.entries(PermissionFlagsBits).map(([name, flag]) => [flag as bigint, name]),
);

export function missingPermissionNames(caps: BotCapabilities, required: readonly bigint[]): string[] {
  if ((caps.permissions & PermissionFlagsBits.Administrator) === PermissionFlagsBits.Administrator) return [];
  return required.filter((flag) => (caps.permissions & flag) !== flag).map((flag) => PERMISSION_NAMES.get(flag) ?? String(flag));
}

/**
 * Real operational state of one detector (spec 19.19). A detector is only ACTIVE when it is enabled AND the bot can
 * actually receive its events and deliver alerts — the panel never shows ON for something that cannot run.
 */
export function computeDetectorStatus(
  descriptor: DetectorDescriptor,
  enabledByConfig: boolean,
  caps: BotCapabilities,
): DetectorStatus {
  const id = descriptor.id;
  if (descriptor.support === 'UNSUPPORTED') return { id, status: 'UNSUPPORTED', reasons: ['UNSUPPORTED'], detail: descriptor.limitations };
  if (!enabledByConfig) return { id, status: 'DISABLED', reasons: ['DISABLED_BY_CONFIG'], detail: 'Đã tắt trong cấu hình' };

  const missingIntents = descriptor.requiredIntents.filter((i) => !caps.intents.has(i));
  if (missingIntents.length > 0) {
    return { id, status: 'PERMISSION_BLOCKED', reasons: ['INTENT_MISSING'], detail: `Thiếu Intent: ${missingIntents.join(', ')}` };
  }
  const missing = missingPermissionNames(caps, descriptor.requiredPermissions);
  if (missing.length > 0) {
    return { id, status: 'PERMISSION_BLOCKED', reasons: ['MISSING_PERMISSION'], detail: `Bot thiếu quyền: ${missing.join(', ')}` };
  }
  if (!caps.alertChannelUsable) {
    return {
      id,
      status: 'DEGRADED',
      reasons: ['ALERT_CHANNEL_UNAVAILABLE'],
      detail: 'Phát hiện được nhưng kênh cảnh báo chưa dùng được (sẽ thử DM chủ server)',
    };
  }
  return { id, status: 'ACTIVE', reasons: [], detail: 'Hoạt động' };
}

export type OverallStatus = 'ON' | 'OFF' | 'DEGRADED' | 'FAILED';

/** Spec 19.19: ON only if at least one detector is ACTIVE and every enabled detector is ACTIVE. */
export function computeOverallStatus(
  globalEnabled: boolean,
  statuses: readonly DetectorStatus[],
  coreFailed: boolean,
): OverallStatus {
  if (coreFailed) return 'FAILED';
  if (!globalEnabled) return 'OFF';
  const enabled = statuses.filter((s) => s.status !== 'DISABLED' && s.status !== 'UNSUPPORTED');
  const active = enabled.filter((s) => s.status === 'ACTIVE');
  if (active.length === 0) return 'DEGRADED';
  return active.length === enabled.length ? 'ON' : 'DEGRADED';
}
