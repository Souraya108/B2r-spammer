import { GatewayIntentBits, type Client, type Guild } from 'discord.js';
import type { IntentName } from '../detectors/types.js';
import type { BotCapabilities } from './operationalStatus.js';

const ALL_INTENTS: IntentName[] = ['Guilds', 'GuildModeration', 'GuildMembers', 'GuildWebhooks', 'GuildInvites'];

export function isAlertChannelUsable(guild: Guild, channelId: string | null): boolean {
  if (!channelId) return false;
  const channel = guild.channels.cache.get(channelId);
  const me = guild.members.me;
  if (!channel || !me || !channel.isTextBased()) return false;
  return channel.permissionsFor(me)?.has(['ViewChannel', 'SendMessages', 'EmbedLinks']) ?? false;
}

/** Reads what the bot can really do right now in this guild (permissions, intents, alert channel). */
export function readCapabilities(client: Client, guild: Guild, alertChannelId: string | null): BotCapabilities {
  const intents = new Set<IntentName>(ALL_INTENTS.filter((name) => client.options.intents.has(GatewayIntentBits[name])));
  return {
    permissions: guild.members.me?.permissions.bitfield ?? 0n,
    intents,
    alertChannelUsable: isAlertChannelUsable(guild, alertChannelId),
  };
}
