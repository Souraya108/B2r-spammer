import { PermissionFlagsBits, type Client, type Guild } from 'discord.js';
import { probeDatabase, type Db } from '../db/database.js';
import { DETECTORS } from '../detectors/registry.js';
import type { HealthStatus } from '../types.js';
import { missingPermissionNames, type BotCapabilities } from './operationalStatus.js';

export interface HealthItem {
  name: string;
  status: HealthStatus;
  detail: string;
}

export interface HealthInput {
  client: Client;
  guild: Guild;
  db: Db;
  caps: BotCapabilities;
  mailbox: { queued: number; rejected: number };
}

/** Spec 23: every item is a real probe (DB read/write, gateway state, permission and intent checks), not a static flag. */
export function collectHealth(input: HealthInput): HealthItem[] {
  const { client, caps, mailbox } = input;
  const items: HealthItem[] = [];

  const canViewAudit = missingPermissionNames(caps, [PermissionFlagsBits.ViewAuditLog]).length === 0;
  const hasModIntent = caps.intents.has('GuildModeration');
  items.push({
    name: 'Giám sát Audit Log',
    status: canViewAudit && hasModIntent ? 'HEALTHY' : 'PERMISSION_BLOCKED',
    detail: canViewAudit && hasModIntent ? 'Có quyền View Audit Log và Intent GuildModeration' : 'Thiếu quyền View Audit Log hoặc Intent GuildModeration',
  });

  const wsReady = client.isReady();
  items.push({
    name: 'Gateway',
    status: wsReady ? (client.ws.ping >= 0 && client.ws.ping < 1000 ? 'HEALTHY' : 'DEGRADED') : 'FAILED',
    detail: wsReady ? `Ping ${client.ws.ping} ms` : 'Chưa kết nối',
  });

  const dbProbe = probeDatabase(input.db);
  items.push({
    name: 'Database',
    status: dbProbe.ok ? 'HEALTHY' : 'FAILED',
    detail: dbProbe.ok ? `Đọc/ghi thử OK (${dbProbe.latencyMs} ms)` : `Lỗi: ${dbProbe.error ?? 'không rõ'}`,
  });

  items.push({
    name: 'Detector Engine',
    status: mailbox.rejected > 0 ? 'DEGRADED' : 'HEALTHY',
    detail: mailbox.rejected > 0 ? `Đã từ chối ${mailbox.rejected} sự kiện do hàng đợi đầy` : `Hàng đợi: ${mailbox.queued} đang chờ`,
  });

  items.push({
    name: 'Enforcement Engine',
    status: 'DEGRADED',
    detail: 'Phiên bản này chỉ thực thi Ghi log và Cảnh báo; Cách ly/Panic/Lockdown chưa có',
  });
  items.push({ name: 'Backup', status: 'UNSUPPORTED', detail: 'Chưa triển khai (Phase 12)' });
  items.push({ name: 'Recovery', status: 'UNSUPPORTED', detail: 'Chưa triển khai (Phase 12)' });

  const allRequired = [...new Set(DETECTORS.flatMap((d) => d.descriptor.requiredPermissions))];
  const missing = missingPermissionNames(caps, allRequired);
  items.push({
    name: 'Quyền của bot',
    status: missing.length === 0 ? 'HEALTHY' : 'PERMISSION_BLOCKED',
    detail: missing.length === 0 ? 'Đủ quyền cho các Detector hiện có' : `Thiếu: ${missing.join(', ')}`,
  });

  items.push({
    name: 'Kênh cảnh báo',
    status: caps.alertChannelUsable ? 'HEALTHY' : 'DEGRADED',
    detail: caps.alertChannelUsable ? 'Bot gửi được tin nhắn và Embed' : 'Chưa chọn kênh hoặc bot không gửi được (sẽ DM chủ server)',
  });
  return items;
}
