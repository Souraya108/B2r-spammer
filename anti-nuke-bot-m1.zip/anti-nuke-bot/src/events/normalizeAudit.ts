import type { Guild, GuildAuditLogsEntry } from 'discord.js';
import type { ActorKind, SecurityEvent } from '../types.js';

/**
 * Turns a discord.js audit-log entry into the internal SecurityEvent (spec 03.1). The timestamp is the entry's snowflake
 * time, never the time the bot received it (spec 05.2). If the executor's bot flag cannot be determined, the kind is
 * UNKNOWN, which blocks every actor-targeted action (never punish on a guess).
 */
export async function normalizeAuditEntry(
  entry: GuildAuditLogsEntry,
  guild: Guild,
  source: SecurityEvent['source'] = 'AUDIT',
): Promise<SecurityEvent> {
  const executorId = entry.executorId ?? null;
  let executorKind: ActorKind = 'UNKNOWN';
  if (executorId) {
    const user = entry.executor ?? (await guild.client.users.fetch(executorId).catch(() => null));
    if (user) executorKind = user.bot ? 'BOT' : 'USER';
  }
  return {
    guildId: guild.id,
    entryId: entry.id,
    actionType: entry.action,
    ts: entry.createdTimestamp,
    executorId,
    executorKind,
    targetId: entry.targetId ?? null,
    changes: (entry.changes ?? []).map((c) => ({ key: String(c.key), old: c.old, new: c.new })),
    reason: entry.reason ?? null,
    source,
  };
}
