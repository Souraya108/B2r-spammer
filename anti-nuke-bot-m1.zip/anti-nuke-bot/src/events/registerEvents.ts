import { Events, MessageFlags, type Client } from 'discord.js';
import { executeAntinuke } from '../commands/antinuke.js';
import type { CommandContext } from '../commands/context.js';
import { executeProtection } from '../commands/protection.js';
import { errorMessage } from '../core/logger.js';
import type { GuildMailbox } from '../engine/pipeline/guildMailbox.js';
import type { SecurityPipeline } from '../engine/pipeline/securityPipeline.js';
import type { SettingsPanel } from '../ui/settings/panel.js';
import { CUSTOM_ID_PREFIX } from '../ui/settings/customId.js';
import { normalizeAuditEntry } from './normalizeAudit.js';

export interface EventDeps {
  client: Client;
  ctx: CommandContext;
  pipeline: SecurityPipeline;
  mailbox: GuildMailbox;
  panel: SettingsPanel;
}

/** Registers every Gateway listener exactly once (spec 23: no duplicate listeners). */
export function registerEvents({ client, ctx, pipeline, mailbox, panel }: EventDeps): void {
  client.on(Events.GuildAuditLogEntryCreate, (entry, guild) => {
    const accepted = mailbox.enqueue(guild.id, async () => {
      const event = await normalizeAuditEntry(entry, guild);
      await pipeline.process(event);
    });
    if (!accepted) ctx.log.warn('event_rejected_queue_full', { guildId: guild.id, entryId: entry.id });
  });

  client.on(Events.InteractionCreate, (interaction) => {
    void (async () => {
      try {
        if (interaction.isChatInputCommand()) {
          if (interaction.commandName === 'antinuke') await executeAntinuke(interaction, ctx, panel);
          else if (interaction.commandName === 'protection') await executeProtection(interaction, ctx);
        } else if (interaction.isMessageComponent() && interaction.customId.startsWith(`${CUSTOM_ID_PREFIX}:`)) {
          await panel.handle(interaction);
        }
      } catch (err) {
        ctx.log.error('interaction_failed', { error: errorMessage(err) });
        if (interaction.isRepliable()) {
          const payload = { content: 'Đã xảy ra lỗi khi xử lý yêu cầu. Vui lòng thử lại.', flags: MessageFlags.Ephemeral } as const;
          if (interaction.deferred || interaction.replied) await interaction.followUp(payload).catch(() => undefined);
          else await interaction.reply(payload).catch(() => undefined);
        }
      }
    })();
  });
}
