export interface CountedEvent {
  id: string;
  ts: number;
  units: number;
}

/**
 * Rolling-window counter. Semantics (spec 09.1): count(T) sums units with `T - W < ts <= T`
 * (half-open interval). Duplicates are rejected by event id; out-of-order events are inserted by ts.
 */
export class SlidingWindowCounter {
  private readonly buckets = new Map<string, CountedEvent[]>();

  constructor(private readonly retentionMs: number) {}

  /** Returns false if this event id was already recorded under the key. */
  add(key: string, ev: CountedEvent): boolean {
    let list = this.buckets.get(key);
    if (!list) {
      list = [];
      this.buckets.set(key, list);
    }
    if (list.some((e) => e.id === ev.id)) return false;
    let i = list.length;
    while (i > 0 && list[i - 1]!.ts > ev.ts) i--;
    list.splice(i, 0, ev);
    this.pruneList(list);
    return true;
  }

  count(key: string, atTs: number, windowSeconds: number): number {
    const list = this.buckets.get(key);
    if (!list) return 0;
    const lower = atTs - windowSeconds * 1000;
    let total = 0;
    for (const e of list) if (e.ts > lower && e.ts <= atTs) total += e.units;
    return total;
  }

  /** Drops keys whose newest event is older than the retention window. Call periodically. */
  sweep(nowTs: number): void {
    for (const [key, list] of this.buckets) {
      const newest = list[list.length - 1];
      if (!newest || newest.ts <= nowTs - this.retentionMs) this.buckets.delete(key);
    }
  }

  get size(): number {
    return this.buckets.size;
  }

  private pruneList(list: CountedEvent[]): void {
    const newest = list[list.length - 1]!.ts;
    const cutoff = newest - this.retentionMs;
    let drop = 0;
    while (drop < list.length && list[drop]!.ts <= cutoff) drop++;
    if (drop > 0) list.splice(0, drop);
  }
}
