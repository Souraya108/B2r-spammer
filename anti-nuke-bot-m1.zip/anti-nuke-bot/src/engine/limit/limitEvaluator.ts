import type { LimitRule } from '../../types.js';
import type { CountedEvent, SlidingWindowCounter } from './slidingWindow.js';

export interface LimitEvaluation {
  duplicate: boolean;
  violated: boolean;
  instant: boolean;
  /** Count under the rule that triggered (or the first rule when not violated). */
  count: number;
  /** The rule that triggered; `{0,0}` for instant violations; null when not violated. */
  rule: LimitRule | null;
  counts: number[];
}

/**
 * Records the event and evaluates up to 3 independent rules (spec 09). Violation = count > N for ANY rule.
 * `instant` (Critical Rule, 09.4): the first countable event is itself a violation (N = 0).
 */
export function evaluateLimit(
  counter: SlidingWindowCounter,
  key: string,
  ev: CountedEvent,
  rules: LimitRule[],
  instant: boolean,
): LimitEvaluation {
  if (!counter.add(key, ev)) {
    return { duplicate: true, violated: false, instant, count: 0, rule: null, counts: [] };
  }
  if (instant) {
    return {
      duplicate: false,
      violated: true,
      instant: true,
      count: ev.units,
      rule: { maxActions: 0, windowSeconds: 0 },
      counts: [],
    };
  }
  const counts = rules.map((rule) => counter.count(key, ev.ts, rule.windowSeconds));
  let worst = -1;
  let worstRatio = 0;
  rules.forEach((rule, i) => {
    const over = counts[i]! - rule.maxActions;
    if (over <= 0) return;
    const ratio = over / Math.max(rule.maxActions, 1);
    if (ratio > worstRatio) {
      worstRatio = ratio;
      worst = i;
    }
  });
  if (worst === -1) {
    return { duplicate: false, violated: false, instant: false, count: counts[0] ?? 0, rule: null, counts };
  }
  return { duplicate: false, violated: true, instant: false, count: counts[worst]!, rule: rules[worst]!, counts };
}
