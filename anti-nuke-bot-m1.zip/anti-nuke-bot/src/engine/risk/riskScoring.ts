import { SEVERITY_POINTS } from '../../config/defaults.js';
import { RISK_LEVELS, type RiskLevel } from '../../types.js';

export interface RiskInput {
  severity: RiskLevel;
  riskWeight: number;
  instant: boolean;
  count: number;
  maxActions: number;
  /** T component, 0-15 (decided by the detector, e.g. @everyone role = 10). */
  targetImportance: number;
  /** P component, 0-15 (permission context, spec 08). */
  permissionContext: number;
  actorHeat: number;
  heatActionThreshold: number;
  /** C component, 0-10 (sequence / multi-actor correlation). */
  correlation: number;
  /** R component, 0-20 (Trust Reduction only — never Attribution Confidence, spec 03.9). */
  trustReduction: number;
}

export interface RiskComponents {
  S: number;
  F: number;
  T: number;
  P: number;
  H: number;
  C: number;
  R: number;
}

export interface RiskResult {
  score: number;
  level: RiskLevel;
  components: RiskComponents;
  explanation: string;
}

const clamp = (min: number, max: number, v: number): number => Math.min(max, Math.max(min, v));

export function levelForScore(score: number): RiskLevel {
  if (score >= 80) return 'CRITICAL';
  if (score >= 60) return 'HIGH';
  if (score >= 40) return 'MEDIUM';
  if (score >= 20) return 'LOW';
  return 'INFORMATIONAL';
}

const BAND_MIN: Record<RiskLevel, number> = { INFORMATIONAL: 0, LOW: 20, MEDIUM: 40, HIGH: 60, CRITICAL: 80 };

export function scoreRisk(input: RiskInput): RiskResult {
  const S = Math.min(40, Math.round(SEVERITY_POINTS[input.severity] * input.riskWeight));
  const F = input.instant
    ? 15
    : clamp(0, 15, Math.round((15 * (input.count - input.maxActions)) / Math.max(input.maxActions, 1)));
  const T = clamp(0, 15, input.targetImportance);
  const P = clamp(0, 15, input.permissionContext);
  const H = clamp(0, 10, Math.round((10 * input.actorHeat) / Math.max(input.heatActionThreshold, 1)));
  const C = clamp(0, 10, input.correlation);
  const R = clamp(0, 20, input.trustReduction);
  const score = clamp(0, 100, S + F + T + P + H + C - R);
  const level = levelForScore(score);
  const explanation =
    `Risk ${score}/100 (${level}): độ nghiêm trọng gốc S=${S}, mức vượt giới hạn F=${F}, ` +
    `tầm quan trọng đối tượng T=${T}, ngữ cảnh quyền P=${P}, nhiệt độ hành vi H=${H}, ` +
    `tương quan C=${C}, giảm do mức tin cậy R=${R}.`;
  return { score, level, components: { S, F, T, P, H, C, R }, explanation };
}

/** Strict Mode raises the risk by one band (spec 09.2). */
export function bumpRisk(result: RiskResult): RiskResult {
  const idx = RISK_LEVELS.indexOf(result.level);
  if (idx >= RISK_LEVELS.length - 1) return result;
  const level = RISK_LEVELS[idx + 1]!;
  const score = Math.max(result.score, BAND_MIN[level]);
  return { ...result, score, level, explanation: `${result.explanation} Strict Mode nâng thêm một bậc → ${level}.` };
}
