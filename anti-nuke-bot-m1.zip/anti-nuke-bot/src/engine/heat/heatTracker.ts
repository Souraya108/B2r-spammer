/** Exponential-decay heat (spec 10.2): H(t) = H0 * 0.5^(dt / halfLife); entries older than 5 half-lives are dropped. */
export class HeatTracker {
  private readonly entries = new Map<string, Array<{ ts: number; amount: number }>>();

  add(key: string, ts: number, amount: number): void {
    const list = this.entries.get(key) ?? [];
    list.push({ ts, amount });
    this.entries.set(key, list);
  }

  value(key: string, nowTs: number, halfLifeSeconds: number): number {
    const list = this.entries.get(key);
    if (!list) return 0;
    const horizon = nowTs - 5 * halfLifeSeconds * 1000;
    let total = 0;
    const kept: Array<{ ts: number; amount: number }> = [];
    for (const e of list) {
      if (e.ts <= horizon) continue;
      kept.push(e);
      total += e.amount * Math.pow(0.5, Math.max(0, nowTs - e.ts) / (halfLifeSeconds * 1000));
    }
    if (kept.length === 0) this.entries.delete(key);
    else this.entries.set(key, kept);
    return total;
  }
}
