import type { DetectorDescriptor } from '../../detectors/types.js';
import type { AttributionConfidence, SecurityEvent } from '../../types.js';

/**
 * Attribution for an event that IS an audit-log entry (primary source, spec 05.2).
 * - No executor, or a Gateway-only detector → UNKNOWN (never guess).
 * - Entry action type outside the detector's expected set → POSSIBLE.
 * - Full-attribution detector with executor and target → CONFIRMED; target missing or partial capability → PROBABLE.
 * Cross-checking against the matching Gateway event and the retry schedule is a later milestone (see PROGRESS.md).
 */
export function attributeFromEntry(event: SecurityEvent, descriptor: DetectorDescriptor): AttributionConfidence {
  if (!event.executorId || descriptor.attribution === 'NONE') return 'UNKNOWN';
  if (!descriptor.auditActions.includes(event.actionType)) return 'POSSIBLE';
  if (descriptor.attribution === 'PARTIAL') return 'PROBABLE';
  return event.targetId ? 'CONFIRMED' : 'PROBABLE';
}
