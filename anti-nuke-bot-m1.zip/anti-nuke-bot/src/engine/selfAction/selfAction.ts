import { SELF_ACTION_PREFIX } from '../../config/defaults.js';
import type { SecurityEvent } from '../../types.js';

/** Audit-log reason (max 512 chars) for every write this bot performs, so its own changes are recognizable. */
export function buildAuditReason(operationId: string, text: string): string {
  return `${SELF_ACTION_PREFIX}${operationId}] ${text}`.slice(0, 512);
}

export type SelfActionClass = 'NONE' | 'SELF_ACTION' | 'SELF_UNEXPECTED';

/**
 * Spec 06.5: an entry executed by this bot with our reason prefix is a SELF_ACTION (kept for audit, never counted).
 * An entry executed by this bot WITHOUT the prefix is unexpected (possible token abuse) and is surfaced separately.
 */
export function classifySelfAction(event: SecurityEvent, botUserId: string): SelfActionClass {
  if (event.executorId !== botUserId) return 'NONE';
  return event.reason?.startsWith(SELF_ACTION_PREFIX) ? 'SELF_ACTION' : 'SELF_UNEXPECTED';
}
