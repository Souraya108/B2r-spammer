import { TRUST_REDUCTION } from '../../config/defaults.js';
import type { AllowlistEntry, AllowlistRepo } from '../../db/repositories/allowlistRepo.js';
import type { SecurityOwnerRepo } from '../../db/repositories/securityOwnerRepo.js';
import type { DetectorDescriptor } from '../../detectors/types.js';

export interface ExemptionResult {
  exempt: boolean;
  reason?: string;
}

function scopeCovers(entry: AllowlistEntry, descriptor: DetectorDescriptor): boolean {
  switch (entry.scope.kind) {
    case 'ALL':
      return true;
    case 'CATEGORIES':
      return entry.scope.ids.includes(descriptor.category);
    case 'DETECTORS':
      return entry.scope.ids.includes(descriptor.id);
  }
}

export class TrustService {
  constructor(
    private readonly allowlist: AllowlistRepo,
    private readonly owners: SecurityOwnerRepo,
    private readonly now: () => number = Date.now,
  ) {}

  isSecurityOwner(guildId: string, userId: string): boolean {
    return this.owners.has(guildId, userId);
  }

  /**
   * Is the actor exempt for this detector (spec 11.2)? Exempt events are still recorded as evidence but never count,
   * add heat or cause Enforcement. Role entries are only resolved when the guild has any (avoids needless REST calls).
   */
  async evaluate(
    guildId: string,
    actorId: string,
    descriptor: DetectorDescriptor,
    getRoleIds: () => Promise<string[]>,
  ): Promise<ExemptionResult> {
    const now = this.now();
    const subjectIds = [actorId];
    if (this.allowlist.hasRoleEntries(guildId, now)) subjectIds.push(...(await getRoleIds()));
    const hit = this.allowlist.forSubject(guildId, subjectIds, now).find((e) => scopeCovers(e, descriptor));
    return hit ? { exempt: true, reason: `allowlist#${hit.id} (${hit.subjectType})` } : { exempt: false };
  }

  /** R component (spec 10.1): Trust Reduction. Never derived from Attribution Confidence. */
  trustReduction(guildId: string, actorId: string): number {
    if (this.owners.has(guildId, actorId)) return TRUST_REDUCTION.SECURITY_OWNER;
    if (this.allowlist.forSubject(guildId, [actorId], this.now()).length > 0) return TRUST_REDUCTION.TRUSTED;
    return TRUST_REDUCTION.NORMAL;
  }
}
