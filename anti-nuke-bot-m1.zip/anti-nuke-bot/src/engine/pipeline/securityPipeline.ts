import { IMPLEMENTED_ACTIONS } from '../../actions/actionCatalog.js';
import type { ActionExecutor, ActionResult, ExecutionContext } from '../../actions/executor.js';
import { HEAT_PER_CLASS, HEAT_PROFILES, LIMIT_RANGES, TIMING } from '../../config/defaults.js';
import type { GuildConfigService } from '../../config/guildConfig.js';
import { errorMessage, type Logger } from '../../core/logger.js';
import type { EpisodeRepo, Episode } from '../../db/repositories/episodeRepo.js';
import type { IncidentRepo } from '../../db/repositories/incidentRepo.js';
import type { SecurityEventRepo } from '../../db/repositories/securityEventRepo.js';
import { detectorsForAuditAction, DETECTORS } from '../../detectors/registry.js';
import type { DetectionSignal, DetectorModule } from '../../detectors/types.js';
import type { ActorKind, EscalationTier, SecurityEvent } from '../../types.js';
import { attributeFromEntry } from '../attribution/attribution.js';
import { HeatTracker } from '../heat/heatTracker.js';
import { evaluateLimit } from '../limit/limitEvaluator.js';
import { SlidingWindowCounter } from '../limit/slidingWindow.js';
import { resolveActions, selectTier, tierRank, type SkippedAction } from '../policy/actionResolver.js';
import { bumpRisk, scoreRisk, type RiskResult } from '../risk/riskScoring.js';
import { classifySelfAction } from '../selfAction/selfAction.js';
import type { TrustService } from '../trust/trustService.js';

export type OutcomeStatus =
  | 'SELF_ACTION'
  | 'SELF_UNEXPECTED'
  | 'DISABLED'
  | 'DUPLICATE'
  | 'EXEMPT'
  | 'COUNTED'
  | 'VIOLATION'
  | 'VIOLATION_SUPPRESSED'
  | 'ERROR';

export interface DetectorOutcome {
  detectorId: string;
  status: OutcomeStatus;
  incidentId?: string;
  risk?: RiskResult;
  tier?: EscalationTier;
  actions?: ActionResult[];
  skipped?: SkippedAction[];
}

export interface GuildInfo {
  ownerId: string | null;
  /** True when the actor holds the Administrator permission (relevant to TIMEOUT validity). */
  isAdministrator: (userId: string) => Promise<boolean>;
}

export interface PipelineDeps {
  botUserId: () => string;
  config: GuildConfigService;
  trust: TrustService;
  securityEvents: SecurityEventRepo;
  episodes: EpisodeRepo;
  incidents: IncidentRepo;
  executor: ActionExecutor;
  guildInfo: (guildId: string) => GuildInfo;
  roleIdsOf: (guildId: string, userId: string) => Promise<string[]>;
  log: Logger;
}

const RETENTION_MS = LIMIT_RANGES.windowSeconds[1] * 1000;

/**
 * The single processing pipeline (spec 06.2), covering Deduplication → Trust → Detection → Risk → Policy → Validation →
 * Enforcement → Incident persistence for events that arrive as audit-log entries. One instance serves all guilds; callers
 * must serialize calls per guild (see GuildMailbox).
 */
export class SecurityPipeline {
  private readonly counter = new SlidingWindowCounter(RETENTION_MS);
  private readonly heat = new HeatTracker();

  constructor(private readonly deps: PipelineDeps) {}

  /** Rebuilds counters and heat from stored events after a restart (spec 23). Returns events replayed. */
  rehydrate(guildId: string, nowTs: number): number {
    const cfg = this.deps.config.get(guildId);
    let windowSec = 3600;
    for (const d of DETECTORS) {
      for (const r of this.deps.config.resolveFrom(cfg, d.descriptor).rules) windowSec = Math.max(windowSec, r.windowSeconds);
    }
    let replayed = 0;
    for (const e of this.deps.securityEvents.since(guildId, nowTs - windowSec * 1000)) {
      if (e.flags.includes('EXEMPT')) continue;
      const detector = DETECTORS.find((d) => d.descriptor.id === e.detectorId);
      if (!detector) continue;
      const actorKey = e.actorId ?? 'UNKNOWN';
      this.counter.add(this.counterKey(guildId, e.detectorId, actorKey), { id: e.entryId, ts: e.ts, units: e.units });
      this.heat.add(this.heatKey(guildId, actorKey), e.ts, HEAT_PER_CLASS[detector.descriptor.class]);
      replayed++;
    }
    return replayed;
  }

  sweep(nowTs: number): void {
    this.counter.sweep(nowTs);
  }

  async process(event: SecurityEvent): Promise<DetectorOutcome[]> {
    const cfg = this.deps.config.get(event.guildId);
    if (!cfg.enabled) return [];

    const self = classifySelfAction(event, this.deps.botUserId());
    if (self === 'SELF_ACTION') return [{ detectorId: '*', status: 'SELF_ACTION' }];
    if (self === 'SELF_UNEXPECTED') {
      // The bot itself changed something without our reason prefix: possible token abuse. Surface, do not count.
      this.deps.log.warn('self_action_unexpected', { guildId: event.guildId, entryId: event.entryId, actionType: event.actionType });
      return [{ detectorId: '*', status: 'SELF_UNEXPECTED' }];
    }

    const outcomes: DetectorOutcome[] = [];
    for (const detector of detectorsForAuditAction(event.actionType)) {
      const signal = detector.classify(event);
      if (!signal) continue;
      try {
        outcomes.push(await this.handle(event, detector, signal));
      } catch (err) {
        this.deps.log.error('detector_failed', { detectorId: detector.descriptor.id, guildId: event.guildId, error: errorMessage(err) });
        outcomes.push({ detectorId: detector.descriptor.id, status: 'ERROR' });
      }
    }
    return outcomes;
  }

  private async handle(event: SecurityEvent, detector: DetectorModule, signal: DetectionSignal): Promise<DetectorOutcome> {
    const d = detector.descriptor;
    const cfg = this.deps.config.get(event.guildId);
    const settings = this.deps.config.resolveFrom(cfg, d);
    if (!settings.enabled) return { detectorId: d.id, status: 'DISABLED' };

    const actorKey = event.executorId ?? 'UNKNOWN';
    const info = this.deps.guildInfo(event.guildId);
    const actorIsOwner = event.executorId !== null && event.executorId === info.ownerId;
    const base = {
      guildId: event.guildId,
      entryId: event.entryId,
      detectorId: d.id,
      ts: event.ts,
      actorId: event.executorId,
      actorKind: event.executorKind,
      targetId: signal.targetId,
      units: signal.units,
      summary: signal.summary,
    };

    if (event.executorId) {
      const exemption = await this.deps.trust.evaluate(event.guildId, event.executorId, d, () =>
        this.deps.roleIdsOf(event.guildId, event.executorId!),
      );
      if (exemption.exempt) {
        this.deps.securityEvents.record({ ...base, flags: ['EXEMPT'] });
        return { detectorId: d.id, status: 'EXEMPT' };
      }
    }

    const key = this.counterKey(event.guildId, d.id, actorKey);
    const evaluation = evaluateLimit(
      this.counter,
      key,
      { id: event.entryId, ts: event.ts, units: signal.units },
      settings.rules,
      settings.instant,
    );
    if (evaluation.duplicate) return { detectorId: d.id, status: 'DUPLICATE' };

    this.heat.add(this.heatKey(event.guildId, actorKey), event.ts, HEAT_PER_CLASS[d.class]);
    this.deps.securityEvents.record({ ...base, flags: evaluation.violated ? ['COUNTED', 'VIOLATION'] : ['COUNTED'] });
    if (!evaluation.violated) return { detectorId: d.id, status: 'COUNTED' };

    // ---- Violation ----
    const episodeInfo = this.openOrContinueEpisode(event, d.id, actorKey, settings.cooldownSeconds, evaluation.rule?.windowSeconds ?? 0);
    const heatProfile = event.executorKind === 'BOT' ? HEAT_PROFILES.bot : HEAT_PROFILES.actor;
    let risk = scoreRisk({
      severity: d.severity,
      riskWeight: d.riskWeight,
      instant: evaluation.instant,
      count: evaluation.count,
      maxActions: evaluation.rule?.maxActions ?? 0,
      targetImportance: signal.targetImportance,
      permissionContext: signal.permissionContext,
      actorHeat: this.heat.value(this.heatKey(event.guildId, actorKey), event.ts, heatProfile.halfLifeSeconds),
      heatActionThreshold: heatProfile.action,
      correlation: 0, // sequence / multi-actor correlation arrives with the Behavioral milestone
      trustReduction: event.executorId ? this.deps.trust.trustReduction(event.guildId, event.executorId) : 0,
    });
    if (settings.strictMode && d.strictAffected) risk = bumpRisk(risk);

    const attribution = attributeFromEntry(event, d);
    const tier = selectTier(risk.level, episodeInfo.repeated);
    const isAdministrator = event.executorId ? await info.isAdministrator(event.executorId) : false;
    const resolved = resolveActions({
      policy: settings.policy[tier],
      compatible: d.compatibleActions,
      attribution,
      actorKind: event.executorKind as ActorKind,
      actorIsOwner,
      actorIsAdministrator: isAdministrator,
      riskLevel: risk.level,
      implemented: IMPLEMENTED_ACTIONS,
    });

    const incident = this.deps.incidents.recordViolation({
      guildId: event.guildId,
      actorKey,
      detectorId: d.id,
      eventId: event.entryId,
      targetId: signal.targetId,
      severity: risk.level,
      riskScore: risk.score,
      attribution,
      riskJson: JSON.stringify({ ...risk.components, score: risk.score, explanation: risk.explanation }),
      ts: event.ts,
    });

    // Cooldown (spec 09.5): never repeat the same escalation tier inside the cooldown, but a HIGHER tier runs at once.
    const ep = episodeInfo.episode;
    const suppressed =
      !episodeInfo.isNew &&
      ep.lastTier !== null &&
      ep.lastExecAt !== null &&
      tierRank(tier) <= tierRank(ep.lastTier) &&
      event.ts - ep.lastExecAt < settings.cooldownSeconds * 1000;
    if (suppressed) {
      return { detectorId: d.id, status: 'VIOLATION_SUPPRESSED', incidentId: incident.id, risk, tier, skipped: resolved.skipped };
    }

    const ctx: ExecutionContext = {
      guildId: event.guildId,
      incidentId: incident.id,
      descriptor: d,
      signal,
      event,
      actor: { id: event.executorId, kind: event.executorKind, isOwner: actorIsOwner },
      attribution,
      risk,
      tier,
      repeated: episodeInfo.repeated,
      actions: resolved.actions,
      skipped: resolved.skipped,
      limit: { count: evaluation.count, rule: evaluation.rule, instant: evaluation.instant },
      alertChannelId: cfg.alertChannelId,
    };

    let results: ActionResult[];
    try {
      results = await this.deps.executor.run(ctx);
    } catch (err) {
      results = resolved.actions.map((action) => ({ action, status: 'FAILED' as const, detail: errorMessage(err).slice(0, 120) }));
      this.deps.log.error('execution_failed', { incidentId: incident.id, error: errorMessage(err) });
    }

    this.deps.incidents.appendActions(
      incident.id,
      [
        ...results.map((r) => ({ action: r.action, status: r.status, detail: r.detail, at: event.ts })),
        ...resolved.skipped.map((s) => ({ action: s.action, status: 'SKIPPED' as const, detail: s.reason, at: event.ts })),
      ],
    );
    this.deps.episodes.markExecuted(ep.id, tier, event.ts, incident.id);

    return {
      detectorId: d.id,
      status: 'VIOLATION',
      incidentId: incident.id,
      risk,
      tier,
      actions: results,
      skipped: resolved.skipped,
    };
  }

  /**
   * Episode (spec 09.5): consecutive violations of one (guild, actor, detector). Because counters are sliding windows,
   * an Episode is considered closed once the gap since the last violation exceeds both the cooldown and the triggering
   * window (by then every older event has left the window, so count <= N).
   */
  private openOrContinueEpisode(
    event: SecurityEvent,
    detectorId: string,
    actorKey: string,
    cooldownSeconds: number,
    windowSeconds: number,
  ): { episode: Episode; isNew: boolean; repeated: boolean } {
    const latest = this.deps.episodes.latest(event.guildId, actorKey, detectorId);
    const closeAfterMs = Math.max(cooldownSeconds, windowSeconds) * 1000;
    const continuing = latest !== null && event.ts - latest.lastViolationAt < closeAfterMs;
    let episode: Episode;
    if (continuing && latest) {
      this.deps.episodes.touch(latest.id, event.ts);
      episode = latest;
    } else {
      episode = this.deps.episodes.open(event.guildId, actorKey, detectorId, event.ts);
    }
    const memoryMs = TIMING.escalationMemoryHours * 3_600_000;
    const repeated = this.deps.episodes.countSince(event.guildId, actorKey, detectorId, event.ts - memoryMs) >= 2;
    return { episode, isNew: !continuing, repeated };
  }

  private counterKey(guildId: string, detectorId: string, actorKey: string): string {
    return `${guildId}|${detectorId}|${actorKey}`;
  }

  private heatKey(guildId: string, actorKey: string): string {
    return `${guildId}|${actorKey}`;
  }
}
