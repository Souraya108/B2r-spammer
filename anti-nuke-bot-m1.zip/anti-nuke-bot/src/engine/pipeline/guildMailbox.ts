import { QUEUE } from '../../config/defaults.js';

type Task = () => Promise<void>;

/**
 * Serializes work per guild (spec 06.6) so counters, heat and episodes of one guild never race, while different guilds
 * run in parallel. Each queue is bounded; when full the task is REJECTED and counted (never silently lost).
 */
export class GuildMailbox {
  private readonly queues = new Map<string, { tasks: Task[]; running: boolean }>();
  private rejected = 0;
  private accepting = true;
  private idleWaiters: Array<() => void> = [];

  constructor(
    private readonly onError: (guildId: string, err: unknown) => void,
    private readonly maxPerGuild: number = QUEUE.maxPerGuild,
  ) {}

  enqueue(guildId: string, task: Task): boolean {
    if (!this.accepting) return false;
    let q = this.queues.get(guildId);
    if (!q) {
      q = { tasks: [], running: false };
      this.queues.set(guildId, q);
    }
    if (q.tasks.length >= this.maxPerGuild) {
      this.rejected++;
      return false;
    }
    q.tasks.push(task);
    if (!q.running) void this.run(guildId, q);
    return true;
  }

  private async run(guildId: string, q: { tasks: Task[]; running: boolean }): Promise<void> {
    q.running = true;
    while (q.tasks.length > 0) {
      const task = q.tasks.shift()!;
      try {
        await task();
      } catch (err) {
        this.onError(guildId, err);
      }
    }
    q.running = false;
    this.queues.delete(guildId);
    if (this.queues.size === 0) {
      for (const w of this.idleWaiters.splice(0)) w();
    }
  }

  stats(): { guildsBusy: number; queued: number; rejected: number } {
    let queued = 0;
    for (const q of this.queues.values()) queued += q.tasks.length;
    return { guildsBusy: this.queues.size, queued, rejected: this.rejected };
  }

  /** Graceful shutdown (spec 23): stop accepting, wait for in-flight work up to `timeoutMs`. Returns true if drained. */
  async drain(timeoutMs: number): Promise<boolean> {
    this.accepting = false;
    if (this.queues.size === 0) return true;
    return new Promise<boolean>((resolve) => {
      const timer = setTimeout(() => resolve(false), timeoutMs);
      this.idleWaiters.push(() => {
        clearTimeout(timer);
        resolve(true);
      });
    });
  }
}
