import {
  ACTOR_PUNISHMENTS,
  RESOURCE_CONTAINMENT,
  type ActionName,
} from '../../actions/actionCatalog.js';
import {
  ESCALATION_ORDER,
  type ActorKind,
  type AttributionConfidence,
  type EscalationTier,
  type RiskLevel,
} from '../../types.js';

export type SkipReason =
  | 'INCOMPATIBLE'
  | 'NOT_IMPLEMENTED'
  | 'ATTRIBUTION_INSUFFICIENT'
  | 'ACTOR_NOT_APPLICABLE'
  | 'TARGET_PROTECTED'
  | 'RISK_TOO_LOW';

export interface SkippedAction {
  action: ActionName;
  reason: SkipReason;
}

export interface ResolveInput {
  policy: readonly ActionName[];
  compatible: readonly ActionName[];
  attribution: AttributionConfidence;
  actorKind: ActorKind;
  actorIsOwner: boolean;
  actorIsAdministrator: boolean;
  riskLevel: RiskLevel;
  implemented: ReadonlySet<ActionName>;
}

export interface ResolvedActions {
  actions: ActionName[];
  skipped: SkippedAction[];
}

const RISK_RANK: Record<RiskLevel, number> = { INFORMATIONAL: 0, LOW: 1, MEDIUM: 2, HIGH: 3, CRITICAL: 4 };
const atLeastHigh = (level: RiskLevel): boolean => RISK_RANK[level] >= RISK_RANK.HIGH;

/** Spec 13.6: Risk CRITICAL → Critical; HIGH → High; otherwise repeated Episode → Repeated; else First. */
export function selectTier(level: RiskLevel, repeated: boolean): EscalationTier {
  if (level === 'CRITICAL') return 'CRITICAL';
  if (level === 'HIGH') return 'HIGH';
  return repeated ? 'REPEATED' : 'FIRST';
}

export function tierRank(tier: EscalationTier): number {
  return ESCALATION_ORDER.indexOf(tier);
}

/** Returns null when the action is valid, otherwise the reason it must be refused (spec 13.2 + Appendix C). */
export function validateAction(action: ActionName, input: ResolveInput): SkipReason | null {
  switch (action) {
    case 'LOG_ONLY':
    case 'ALERT':
    case 'REQUEST_OWNER_CONFIRMATION':
      return null;
    case 'WARN':
      if (input.actorKind !== 'USER' || input.actorIsOwner) return 'ACTOR_NOT_APPLICABLE';
      return input.attribution === 'CONFIRMED' ? null : 'ATTRIBUTION_INSUFFICIENT';
    case 'TIMEOUT':
      if (input.actorKind !== 'USER' || input.actorIsAdministrator) return 'ACTOR_NOT_APPLICABLE';
      if (input.actorIsOwner) return 'TARGET_PROTECTED';
      return input.attribution === 'CONFIRMED' ? null : 'ATTRIBUTION_INSUFFICIENT';
    case 'KICK':
    case 'BAN':
    case 'QUARANTINE':
    case 'REMOVE_MANAGEABLE_DANGEROUS_ROLES':
      if (input.actorKind === 'UNKNOWN') return 'ACTOR_NOT_APPLICABLE';
      if (input.actorIsOwner) return 'TARGET_PROTECTED';
      return input.attribution === 'CONFIRMED' ? null : 'ATTRIBUTION_INSUFFICIENT';
    default:
      // Resource / guild containment: allowed with CONFIRMED attribution, otherwise only at Risk >= HIGH.
      if (input.attribution === 'CONFIRMED' || atLeastHigh(input.riskLevel)) return null;
      return 'RISK_TOO_LOW';
  }
}

const PRIORITY: Record<string, number> = {
  containment: 0,
  punishment: 1,
  recovery: 2,
  notify: 3,
};

function bucket(action: ActionName): number {
  if (ACTOR_PUNISHMENTS.has(action)) return PRIORITY.punishment!;
  if (action === 'RECOVERY' || action === 'ROLLBACK_CHANGE') return PRIORITY.recovery!;
  if (RESOURCE_CONTAINMENT.has(action) || action === 'PANIC_MODE') return PRIORITY.containment!;
  return PRIORITY.notify!;
}

const HARD_PUNISHMENT_RANK: Partial<Record<ActionName, number>> = { TIMEOUT: 1, KICK: 2, BAN: 3 };

/**
 * Filters a policy tier down to the actions that may really run. Never fails silently: every dropped action is
 * returned with a reason code, and ALERT is always present when anything was dropped (spec 13.5).
 */
export function resolveActions(input: ResolveInput): ResolvedActions {
  const actions: ActionName[] = [];
  const skipped: SkippedAction[] = [];

  for (const action of new Set(input.policy)) {
    if (!input.compatible.includes(action)) {
      skipped.push({ action, reason: 'INCOMPATIBLE' });
      continue;
    }
    const refusal = validateAction(action, input);
    if (refusal) {
      skipped.push({ action, reason: refusal });
      continue;
    }
    if (!input.implemented.has(action)) {
      skipped.push({ action, reason: 'NOT_IMPLEMENTED' });
      continue;
    }
    actions.push(action);
  }

  // One hard punishment per actor per incident: keep the heaviest of TIMEOUT / KICK / BAN (spec 13.4).
  const hard = actions.filter((a) => HARD_PUNISHMENT_RANK[a] !== undefined);
  if (hard.length > 1) {
    hard.sort((a, b) => HARD_PUNISHMENT_RANK[b]! - HARD_PUNISHMENT_RANK[a]!);
    for (const lighter of hard.slice(1)) actions.splice(actions.indexOf(lighter), 1);
  }

  if (skipped.length > 0 && !actions.includes('ALERT')) actions.push('ALERT');
  if (!actions.includes('LOG_ONLY')) actions.push('LOG_ONLY');

  actions.sort((a, b) => bucket(a) - bucket(b));
  return { actions, skipped };
}
