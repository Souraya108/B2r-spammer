type Level = 'debug' | 'info' | 'warn' | 'error';
const ORDER: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

// Bot tokens and webhook URLs must never reach logs (spec 24).
const REDACTIONS: Array<[RegExp, string]> = [
  [/[A-Za-z0-9_-]{23,28}\.[A-Za-z0-9_-]{6,7}\.[A-Za-z0-9_-]{27,}/g, '[REDACTED_TOKEN]'],
  [/discord(?:app)?\.com\/api\/webhooks\/\d+\/[\w-]+/gi, 'discord.com/api/webhooks/[REDACTED]'],
];

export function redact(text: string): string {
  return REDACTIONS.reduce((acc, [re, to]) => acc.replace(re, to), text);
}

export function errorMessage(err: unknown): string {
  if (err instanceof Error) return redact(`${err.name}: ${err.message}`);
  return redact(String(err));
}

export interface Logger {
  debug(msg: string, ctx?: Record<string, unknown>): void;
  info(msg: string, ctx?: Record<string, unknown>): void;
  warn(msg: string, ctx?: Record<string, unknown>): void;
  error(msg: string, ctx?: Record<string, unknown>): void;
}

export function createLogger(minLevel: Level = 'info'): Logger {
  const write = (level: Level, msg: string, ctx?: Record<string, unknown>): void => {
    if (ORDER[level] < ORDER[minLevel]) return;
    const line = redact(JSON.stringify({ t: new Date().toISOString(), level, msg, ...ctx }));
    (level === 'error' || level === 'warn' ? console.error : console.log)(line);
  };
  return {
    debug: (m, c) => write('debug', m, c),
    info: (m, c) => write('info', m, c),
    warn: (m, c) => write('warn', m, c),
    error: (m, c) => write('error', m, c),
  };
}

export const silentLogger: Logger = { debug() {}, info() {}, warn() {}, error() {} };
