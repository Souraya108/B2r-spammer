export interface Migration {
  version: number;
  name: string;
  sql: string;
}

/** Append-only list. Never edit a migration that has shipped — add a new one. */
export const MIGRATIONS: readonly Migration[] = [
  {
    version: 1,
    name: 'initial_schema',
    sql: `
CREATE TABLE guild_config (
  guild_id TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 0,
  profile TEXT NOT NULL DEFAULT 'BALANCED',
  strict_mode INTEGER NOT NULL DEFAULT 0,
  alert_channel_id TEXT,
  config_version INTEGER NOT NULL DEFAULT 1,
  updated_at INTEGER NOT NULL,
  updated_by TEXT
);

CREATE TABLE category_state (
  guild_id TEXT NOT NULL,
  category TEXT NOT NULL,
  enabled INTEGER NOT NULL,
  PRIMARY KEY (guild_id, category)
);

CREATE TABLE detector_config (
  guild_id TEXT NOT NULL,
  detector_id TEXT NOT NULL,
  enabled INTEGER NOT NULL,
  PRIMARY KEY (guild_id, detector_id)
);

CREATE TABLE security_owners (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  added_by TEXT NOT NULL,
  added_at INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE allowlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  subject_type TEXT NOT NULL,
  subject_id TEXT NOT NULL,
  scope TEXT NOT NULL,
  expires_at INTEGER,
  created_by TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  reason TEXT NOT NULL
);
CREATE INDEX idx_allowlist_guild_subject ON allowlist (guild_id, subject_id);

CREATE TABLE security_events (
  guild_id TEXT NOT NULL,
  entry_id TEXT NOT NULL,
  detector_id TEXT NOT NULL,
  ts INTEGER NOT NULL,
  actor_id TEXT,
  actor_kind TEXT NOT NULL,
  target_id TEXT,
  units INTEGER NOT NULL,
  flags TEXT NOT NULL,
  summary TEXT NOT NULL,
  PRIMARY KEY (guild_id, entry_id, detector_id)
);
CREATE INDEX idx_security_events_guild_ts ON security_events (guild_id, ts);

CREATE TABLE episodes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  actor_key TEXT NOT NULL,
  detector_id TEXT NOT NULL,
  opened_at INTEGER NOT NULL,
  last_violation_at INTEGER NOT NULL,
  last_tier TEXT,
  last_exec_at INTEGER,
  incident_id TEXT
);
CREATE INDEX idx_episodes_key ON episodes (guild_id, actor_key, detector_id, opened_at);

CREATE TABLE incidents (
  id TEXT PRIMARY KEY,
  guild_id TEXT NOT NULL,
  actor_key TEXT NOT NULL,
  status TEXT NOT NULL,
  severity TEXT NOT NULL,
  risk_score INTEGER NOT NULL,
  attribution TEXT NOT NULL,
  detectors TEXT NOT NULL,
  event_ids TEXT NOT NULL,
  targets TEXT NOT NULL,
  risk_json TEXT NOT NULL,
  actions_json TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  closed_at INTEGER
);
CREATE INDEX idx_incidents_guild ON incidents (guild_id, actor_key, updated_at);

CREATE TABLE configuration_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  ts INTEGER NOT NULL,
  changed_by TEXT NOT NULL,
  source TEXT NOT NULL,
  key TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT,
  version INTEGER NOT NULL
);
CREATE INDEX idx_config_history_guild ON configuration_history (guild_id, ts);

CREATE TABLE ui_sessions (
  id TEXT PRIMARY KEY,
  guild_id TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  state TEXT NOT NULL,
  config_version INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
`,
  },
];
