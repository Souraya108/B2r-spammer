import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import BetterSqlite3 from 'better-sqlite3';
import { MIGRATIONS } from './migrations.js';

export type Db = BetterSqlite3.Database;

/** Opens SQLite (WAL, FK on) and applies pending migrations inside transactions. */
export function openDatabase(path: string): Db {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new BetterSqlite3(path);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  runMigrations(db);
  return db;
}

export function runMigrations(db: Db): number {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
  const applied = new Set(
    (db.prepare('SELECT version FROM schema_migrations').all() as Array<{ version: number }>).map((r) => r.version),
  );
  let count = 0;
  for (const m of MIGRATIONS) {
    if (applied.has(m.version)) continue;
    db.transaction(() => {
      db.exec(m.sql);
      db.prepare('INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)').run(m.version, Date.now());
    })();
    count++;
  }
  return count;
}

/** Real read+write probe used by Diagnostics (spec 23: health checks must not be static flags). */
export function probeDatabase(db: Db): { ok: boolean; latencyMs: number; error?: string } {
  const start = performance.now();
  try {
    db.prepare('SELECT 1').get();
    db.exec('CREATE TEMP TABLE IF NOT EXISTS health_probe (v INTEGER)');
    db.prepare('INSERT INTO health_probe (v) VALUES (1)').run();
    db.exec('DELETE FROM health_probe');
    return { ok: true, latencyMs: Math.round((performance.now() - start) * 100) / 100 };
  } catch (err) {
    return { ok: false, latencyMs: Math.round(performance.now() - start), error: err instanceof Error ? err.message : String(err) };
  }
}
