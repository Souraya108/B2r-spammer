import { randomBytes } from 'node:crypto';
import type { Db } from '../database.js';

export type PanelView =
  | { view: 'OVERVIEW' }
  | { view: 'CATEGORY'; category: string; page: number }
  | { view: 'CONFIRM_DISABLE'; until: number };

export interface UiSession {
  id: string;
  guildId: string;
  ownerId: string;
  state: PanelView;
  configVersion: number;
  expiresAt: number;
}

export class UiSessionRepo {
  constructor(private readonly db: Db) {}

  create(guildId: string, ownerId: string, state: PanelView, configVersion: number, expiresAt: number): UiSession {
    const id = randomBytes(6).toString('hex'); // 12 chars, fits custom_id (<= 100)
    this.db
      .prepare('INSERT INTO ui_sessions (id, guild_id, owner_id, state, config_version, expires_at) VALUES (?, ?, ?, ?, ?, ?)')
      .run(id, guildId, ownerId, JSON.stringify(state), configVersion, expiresAt);
    return { id, guildId, ownerId, state, configVersion, expiresAt };
  }

  get(id: string): UiSession | null {
    const r = this.db.prepare('SELECT * FROM ui_sessions WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    if (!r) return null;
    return {
      id: r.id as string,
      guildId: r.guild_id as string,
      ownerId: r.owner_id as string,
      state: JSON.parse(r.state as string) as PanelView,
      configVersion: r.config_version as number,
      expiresAt: r.expires_at as number,
    };
  }

  update(id: string, state: PanelView, configVersion: number, expiresAt: number): void {
    this.db
      .prepare('UPDATE ui_sessions SET state = ?, config_version = ?, expires_at = ? WHERE id = ?')
      .run(JSON.stringify(state), configVersion, expiresAt, id);
  }

  purgeExpired(now: number): number {
    return this.db.prepare('DELETE FROM ui_sessions WHERE expires_at < ?').run(now).changes;
  }
}
