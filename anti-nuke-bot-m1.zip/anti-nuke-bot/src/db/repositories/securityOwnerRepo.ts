import type { Db } from '../database.js';

export class SecurityOwnerRepo {
  constructor(private readonly db: Db) {}

  add(guildId: string, userId: string, addedBy: string, now: number): boolean {
    return (
      this.db
        .prepare('INSERT OR IGNORE INTO security_owners (guild_id, user_id, added_by, added_at) VALUES (?, ?, ?, ?)')
        .run(guildId, userId, addedBy, now).changes > 0
    );
  }

  remove(guildId: string, userId: string): boolean {
    return this.db.prepare('DELETE FROM security_owners WHERE guild_id = ? AND user_id = ?').run(guildId, userId).changes > 0;
  }

  has(guildId: string, userId: string): boolean {
    return this.db.prepare('SELECT 1 AS x FROM security_owners WHERE guild_id = ? AND user_id = ?').get(guildId, userId) !== undefined;
  }

  list(guildId: string): string[] {
    return (this.db.prepare('SELECT user_id FROM security_owners WHERE guild_id = ? ORDER BY added_at ASC').all(guildId) as Array<{
      user_id: string;
    }>).map((r) => r.user_id);
  }
}
