import type { Db } from '../database.js';

/** Configuration History rows for changes that do not bump the config version (allowlist, security owners). */
export class HistoryRepo {
  constructor(
    private readonly db: Db,
    private readonly now: () => number = Date.now,
  ) {}

  log(guildId: string, changedBy: string, source: string, key: string, oldValue: string | null, newValue: string | null): void {
    const row = this.db.prepare('SELECT config_version FROM guild_config WHERE guild_id = ?').get(guildId) as
      | { config_version: number }
      | undefined;
    this.db
      .prepare(
        `INSERT INTO configuration_history (guild_id, ts, changed_by, source, key, old_value, new_value, version)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(guildId, this.now(), changedBy, source, key, oldValue, newValue, row?.config_version ?? 0);
  }
}
