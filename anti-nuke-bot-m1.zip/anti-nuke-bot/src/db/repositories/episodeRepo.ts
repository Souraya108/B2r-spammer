import type { Db } from '../database.js';
import type { EscalationTier } from '../../types.js';

export interface Episode {
  id: number;
  guildId: string;
  actorKey: string;
  detectorId: string;
  openedAt: number;
  lastViolationAt: number;
  lastTier: EscalationTier | null;
  lastExecAt: number | null;
  incidentId: string | null;
}

function mapRow(r: Record<string, unknown>): Episode {
  return {
    id: r.id as number,
    guildId: r.guild_id as string,
    actorKey: r.actor_key as string,
    detectorId: r.detector_id as string,
    openedAt: r.opened_at as number,
    lastViolationAt: r.last_violation_at as number,
    lastTier: (r.last_tier as EscalationTier | null) ?? null,
    lastExecAt: (r.last_exec_at as number | null) ?? null,
    incidentId: (r.incident_id as string | null) ?? null,
  };
}

export class EpisodeRepo {
  constructor(private readonly db: Db) {}

  latest(guildId: string, actorKey: string, detectorId: string): Episode | null {
    const row = this.db
      .prepare(
        `SELECT * FROM episodes WHERE guild_id = ? AND actor_key = ? AND detector_id = ?
         ORDER BY opened_at DESC, id DESC LIMIT 1`,
      )
      .get(guildId, actorKey, detectorId) as Record<string, unknown> | undefined;
    return row ? mapRow(row) : null;
  }

  /** Number of Episodes opened since `sinceTs` (Escalation Memory, spec 09.5). */
  countSince(guildId: string, actorKey: string, detectorId: string, sinceTs: number): number {
    const row = this.db
      .prepare('SELECT COUNT(*) AS n FROM episodes WHERE guild_id = ? AND actor_key = ? AND detector_id = ? AND opened_at >= ?')
      .get(guildId, actorKey, detectorId, sinceTs) as { n: number };
    return row.n;
  }

  open(guildId: string, actorKey: string, detectorId: string, ts: number): Episode {
    const info = this.db
      .prepare('INSERT INTO episodes (guild_id, actor_key, detector_id, opened_at, last_violation_at) VALUES (?, ?, ?, ?, ?)')
      .run(guildId, actorKey, detectorId, ts, ts);
    return {
      id: Number(info.lastInsertRowid),
      guildId,
      actorKey,
      detectorId,
      openedAt: ts,
      lastViolationAt: ts,
      lastTier: null,
      lastExecAt: null,
      incidentId: null,
    };
  }

  touch(id: number, ts: number): void {
    this.db.prepare('UPDATE episodes SET last_violation_at = MAX(last_violation_at, ?) WHERE id = ?').run(ts, id);
  }

  markExecuted(id: number, tier: EscalationTier, ts: number, incidentId: string): void {
    this.db.prepare('UPDATE episodes SET last_tier = ?, last_exec_at = ?, incident_id = ? WHERE id = ?').run(tier, ts, incidentId, id);
  }
}
