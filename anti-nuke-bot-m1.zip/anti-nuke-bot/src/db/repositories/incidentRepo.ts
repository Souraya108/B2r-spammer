import { randomBytes } from 'node:crypto';
import type { Db } from '../database.js';
import { TIMING } from '../../config/defaults.js';
import type { AttributionConfidence, RiskLevel } from '../../types.js';

export interface ActionRecord {
  action: string;
  status: 'OK' | 'FAILED' | 'SKIPPED';
  detail: string;
  at: number;
}

export interface IncidentRecord {
  id: string;
  guildId: string;
  actorKey: string;
  status: string;
  severity: RiskLevel;
  riskScore: number;
  attribution: AttributionConfidence;
  detectors: string[];
  eventIds: string[];
  targets: string[];
  riskJson: string;
  actions: ActionRecord[];
  createdAt: number;
  updatedAt: number;
  closedAt: number | null;
}

export interface ViolationInput {
  guildId: string;
  actorKey: string;
  detectorId: string;
  eventId: string;
  targetId: string | null;
  severity: RiskLevel;
  riskScore: number;
  attribution: AttributionConfidence;
  riskJson: string;
  ts: number;
}

const RANK: Record<RiskLevel, number> = { INFORMATIONAL: 0, LOW: 1, MEDIUM: 2, HIGH: 3, CRITICAL: 4 };

function mapRow(r: Record<string, unknown>): IncidentRecord {
  return {
    id: r.id as string,
    guildId: r.guild_id as string,
    actorKey: r.actor_key as string,
    status: r.status as string,
    severity: r.severity as RiskLevel,
    riskScore: r.risk_score as number,
    attribution: r.attribution as AttributionConfidence,
    detectors: JSON.parse(r.detectors as string) as string[],
    eventIds: JSON.parse(r.event_ids as string) as string[],
    targets: JSON.parse(r.targets as string) as string[],
    riskJson: r.risk_json as string,
    actions: JSON.parse(r.actions_json as string) as ActionRecord[],
    createdAt: r.created_at as number,
    updatedAt: r.updated_at as number,
    closedAt: (r.closed_at as number | null) ?? null,
  };
}

export function newIncidentId(ts: number): string {
  return `INC-${ts.toString(36).toUpperCase()}-${randomBytes(2).toString('hex').toUpperCase()}`;
}

export class IncidentRepo {
  constructor(private readonly db: Db) {}

  get(id: string): IncidentRecord | null {
    const row = this.db.prepare('SELECT * FROM incidents WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    return row ? mapRow(row) : null;
  }

  /**
   * Groups violations of the same guild + actor within the grouping window into one Incident (spec 17).
   * Returns the incident (new or updated). Incidents are never deleted automatically.
   */
  recordViolation(v: ViolationInput): IncidentRecord {
    const windowMs = TIMING.incidentGroupingMinutes * 60_000;
    const open = this.db
      .prepare(
        `SELECT * FROM incidents WHERE guild_id = ? AND actor_key = ? AND closed_at IS NULL AND updated_at >= ?
         ORDER BY updated_at DESC LIMIT 1`,
      )
      .get(v.guildId, v.actorKey, v.ts - windowMs) as Record<string, unknown> | undefined;

    if (!open) {
      const id = newIncidentId(v.ts);
      this.db
        .prepare(
          `INSERT INTO incidents (id, guild_id, actor_key, status, severity, risk_score, attribution, detectors, event_ids,
             targets, risk_json, actions_json, created_at, updated_at)
           VALUES (?, ?, ?, 'DETECTED', ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?)`,
        )
        .run(
          id, v.guildId, v.actorKey, v.severity, v.riskScore, v.attribution,
          JSON.stringify([v.detectorId]), JSON.stringify([v.eventId]),
          JSON.stringify(v.targetId ? [v.targetId] : []), v.riskJson, v.ts, v.ts,
        );
      return this.get(id)!;
    }

    const cur = mapRow(open);
    const detectors = cur.detectors.includes(v.detectorId) ? cur.detectors : [...cur.detectors, v.detectorId];
    const eventIds = cur.eventIds.includes(v.eventId) ? cur.eventIds : [...cur.eventIds, v.eventId];
    const targets = v.targetId && !cur.targets.includes(v.targetId) ? [...cur.targets, v.targetId] : cur.targets;
    const higher = v.riskScore > cur.riskScore;
    this.db
      .prepare(
        `UPDATE incidents SET detectors = ?, event_ids = ?, targets = ?, updated_at = ?,
           severity = ?, risk_score = ?, risk_json = ?, attribution = ? WHERE id = ?`,
      )
      .run(
        JSON.stringify(detectors), JSON.stringify(eventIds), JSON.stringify(targets), Math.max(cur.updatedAt, v.ts),
        higher && RANK[v.severity] >= RANK[cur.severity] ? v.severity : cur.severity,
        higher ? v.riskScore : cur.riskScore,
        higher ? v.riskJson : cur.riskJson,
        v.attribution,
        cur.id,
      );
    return this.get(cur.id)!;
  }

  appendActions(id: string, records: ActionRecord[]): void {
    const cur = this.get(id);
    if (!cur) return;
    this.db
      .prepare('UPDATE incidents SET actions_json = ? WHERE id = ?')
      .run(JSON.stringify([...cur.actions, ...records]), id);
  }
}
