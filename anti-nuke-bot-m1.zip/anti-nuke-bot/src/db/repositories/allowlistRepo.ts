import type { Db } from '../database.js';

export type SubjectType = 'USER' | 'ROLE' | 'BOT';
export type AllowlistScope =
  | { kind: 'ALL' }
  | { kind: 'CATEGORIES'; ids: string[] }
  | { kind: 'DETECTORS'; ids: string[] };

export interface AllowlistEntry {
  id: number;
  guildId: string;
  subjectType: SubjectType;
  subjectId: string;
  scope: AllowlistScope;
  expiresAt: number | null;
  createdBy: string;
  createdAt: number;
  reason: string;
}

function mapRow(r: Record<string, unknown>): AllowlistEntry {
  return {
    id: r.id as number,
    guildId: r.guild_id as string,
    subjectType: r.subject_type as SubjectType,
    subjectId: r.subject_id as string,
    scope: JSON.parse(r.scope as string) as AllowlistScope,
    expiresAt: (r.expires_at as number | null) ?? null,
    createdBy: r.created_by as string,
    createdAt: r.created_at as number,
    reason: r.reason as string,
  };
}

export class AllowlistRepo {
  constructor(private readonly db: Db) {}

  add(e: Omit<AllowlistEntry, 'id'>): AllowlistEntry {
    const info = this.db
      .prepare(
        `INSERT INTO allowlist (guild_id, subject_type, subject_id, scope, expires_at, created_by, created_at, reason)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(e.guildId, e.subjectType, e.subjectId, JSON.stringify(e.scope), e.expiresAt, e.createdBy, e.createdAt, e.reason);
    return { ...e, id: Number(info.lastInsertRowid) };
  }

  remove(guildId: string, id: number): boolean {
    return this.db.prepare('DELETE FROM allowlist WHERE guild_id = ? AND id = ?').run(guildId, id).changes > 0;
  }

  /** Active (non-expired) entries only; expired ones are ignored without deleting history. */
  listActive(guildId: string, now: number): AllowlistEntry[] {
    const rows = this.db
      .prepare('SELECT * FROM allowlist WHERE guild_id = ? AND (expires_at IS NULL OR expires_at > ?) ORDER BY id ASC')
      .all(guildId, now) as Array<Record<string, unknown>>;
    return rows.map(mapRow);
  }

  forSubject(guildId: string, subjectIds: string[], now: number): AllowlistEntry[] {
    if (subjectIds.length === 0) return [];
    const marks = subjectIds.map(() => '?').join(',');
    const rows = this.db
      .prepare(
        `SELECT * FROM allowlist WHERE guild_id = ? AND subject_id IN (${marks}) AND (expires_at IS NULL OR expires_at > ?)`,
      )
      .all(guildId, ...subjectIds, now) as Array<Record<string, unknown>>;
    return rows.map(mapRow);
  }

  hasRoleEntries(guildId: string, now: number): boolean {
    const row = this.db
      .prepare(
        "SELECT 1 AS x FROM allowlist WHERE guild_id = ? AND subject_type = 'ROLE' AND (expires_at IS NULL OR expires_at > ?) LIMIT 1",
      )
      .get(guildId, now);
    return row !== undefined;
  }
}
