import type { Db } from '../database.js';
import type { ActorKind } from '../../types.js';

export interface StoredSecurityEvent {
  guildId: string;
  entryId: string;
  detectorId: string;
  ts: number;
  actorId: string | null;
  actorKind: ActorKind;
  targetId: string | null;
  units: number;
  flags: string[];
  summary: string;
}

export class SecurityEventRepo {
  constructor(private readonly db: Db) {}

  /** Idempotent: a duplicate (guild, entry, detector) is ignored. */
  record(e: StoredSecurityEvent): void {
    this.db
      .prepare(
        `INSERT OR IGNORE INTO security_events
         (guild_id, entry_id, detector_id, ts, actor_id, actor_kind, target_id, units, flags, summary)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(e.guildId, e.entryId, e.detectorId, e.ts, e.actorId, e.actorKind, e.targetId, e.units, e.flags.join(','), e.summary);
  }

  /** Events used to rebuild counters and heat after a restart (spec 23). */
  since(guildId: string, sinceTs: number): StoredSecurityEvent[] {
    const rows = this.db
      .prepare(
        `SELECT guild_id, entry_id, detector_id, ts, actor_id, actor_kind, target_id, units, flags, summary
         FROM security_events WHERE guild_id = ? AND ts > ? ORDER BY ts ASC`,
      )
      .all(guildId, sinceTs) as Array<Record<string, unknown>>;
    return rows.map((r) => ({
      guildId: r.guild_id as string,
      entryId: r.entry_id as string,
      detectorId: r.detector_id as string,
      ts: r.ts as number,
      actorId: (r.actor_id as string | null) ?? null,
      actorKind: r.actor_kind as ActorKind,
      targetId: (r.target_id as string | null) ?? null,
      units: r.units as number,
      flags: (r.flags as string) ? (r.flags as string).split(',') : [],
      summary: r.summary as string,
    }));
  }

  purgeOlderThan(ts: number): number {
    return this.db.prepare('DELETE FROM security_events WHERE ts < ?').run(ts).changes;
  }
}
