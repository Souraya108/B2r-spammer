import { Client, Events, GatewayIntentBits, type Guild } from 'discord.js';
import { QUEUE, RETENTION } from './config/defaults.js';
import { loadEnv } from './config/env.js';
import { GuildConfigService } from './config/guildConfig.js';
import type { CommandContext } from './commands/context.js';
import { createLogger, errorMessage } from './core/logger.js';
import { DiscordActionExecutor } from './actions/discordExecutor.js';
import { openDatabase } from './db/database.js';
import { AllowlistRepo } from './db/repositories/allowlistRepo.js';
import { EpisodeRepo } from './db/repositories/episodeRepo.js';
import { HistoryRepo } from './db/repositories/historyRepo.js';
import { IncidentRepo } from './db/repositories/incidentRepo.js';
import { SecurityEventRepo } from './db/repositories/securityEventRepo.js';
import { SecurityOwnerRepo } from './db/repositories/securityOwnerRepo.js';
import { UiSessionRepo } from './db/repositories/uiSessionRepo.js';
import { GuildMailbox } from './engine/pipeline/guildMailbox.js';
import { SecurityPipeline } from './engine/pipeline/securityPipeline.js';
import { TrustService } from './engine/trust/trustService.js';
import { registerEvents } from './events/registerEvents.js';
import { SettingsPanel } from './ui/settings/panel.js';

let env: ReturnType<typeof loadEnv>;
try {
  env = loadEnv();
} catch (err) {
  console.error(errorMessage(err));
  process.exit(1);
}
const log = createLogger(env.logLevel);
const db = openDatabase(env.databasePath);

// Least privilege (spec 05.3): only the intents the current detectors need. GuildMembers (privileged) is NOT requested yet.
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildModeration] });

const config = new GuildConfigService(db);
const owners = new SecurityOwnerRepo(db);
const allowlist = new AllowlistRepo(db);
const securityEvents = new SecurityEventRepo(db);
const sessions = new UiSessionRepo(db);
const mailbox = new GuildMailbox((guildId, err) => log.error('task_failed', { guildId, error: errorMessage(err) }));

const fetchGuild = (guildId: string): Guild | undefined => client.guilds.cache.get(guildId);

const pipeline = new SecurityPipeline({
  botUserId: () => client.user!.id,
  config,
  trust: new TrustService(allowlist, owners),
  securityEvents,
  episodes: new EpisodeRepo(db),
  incidents: new IncidentRepo(db),
  executor: new DiscordActionExecutor(client, log),
  guildInfo: (guildId) => ({
    ownerId: fetchGuild(guildId)?.ownerId ?? null,
    isAdministrator: async (userId) => {
      try {
        return (await fetchGuild(guildId)?.members.fetch(userId))?.permissions.has('Administrator') ?? false;
      } catch {
        return false;
      }
    },
  }),
  roleIdsOf: async (guildId, userId) => {
    try {
      const member = await fetchGuild(guildId)?.members.fetch(userId);
      return member ? [...member.roles.cache.keys()] : [];
    } catch {
      return [];
    }
  },
  log,
});

const ctx: CommandContext = {
  client,
  db,
  config,
  owners,
  allowlist,
  history: new HistoryRepo(db),
  log,
  mailboxStats: () => mailbox.stats(),
};
const panel = new SettingsPanel(ctx);
registerEvents({ client, ctx, pipeline, mailbox, panel });

let maintenance: NodeJS.Timeout | undefined;

client.once(Events.ClientReady, (ready) => {
  log.info('ready', { user: ready.user.tag, guilds: ready.guilds.cache.size });
  // Restart recovery (spec 23): rebuild counters and heat from stored events.
  for (const guildId of ready.guilds.cache.keys()) {
    const replayed = pipeline.rehydrate(guildId, Date.now());
    if (replayed > 0) log.info('rehydrated', { guildId, events: replayed });
  }
  maintenance = setInterval(() => {
    const now = Date.now();
    pipeline.sweep(now);
    securityEvents.purgeOlderThan(now - RETENTION.securityEventsDays * 86_400_000);
    sessions.purgeExpired(now - RETENTION.uiSessionsHours * 3_600_000);
  }, 10 * 60_000);
  maintenance.unref();
});

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  log.info('shutdown_start', { signal });
  if (maintenance) clearInterval(maintenance);
  const drained = await mailbox.drain(QUEUE.shutdownDrainMs);
  if (!drained) log.warn('shutdown_drain_timeout', { pending: mailbox.stats().queued });
  await client.destroy();
  db.close();
  log.info('shutdown_done');
  process.exit(0);
}
process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('unhandledRejection', (reason) => log.error('unhandled_rejection', { error: errorMessage(reason) }));

await client.login(env.token);
