import type { DetectionSignal, DetectorDescriptor } from '../detectors/types.js';
import type { RiskResult } from '../engine/risk/riskScoring.js';
import type { SkippedAction } from '../engine/policy/actionResolver.js';
import type {
  ActorKind,
  AttributionConfidence,
  EscalationTier,
  LimitRule,
  SecurityEvent,
} from '../types.js';
import type { ActionName } from './actionCatalog.js';

export interface ExecutionContext {
  guildId: string;
  incidentId: string;
  descriptor: DetectorDescriptor;
  signal: DetectionSignal;
  event: SecurityEvent;
  actor: { id: string | null; kind: ActorKind; isOwner: boolean };
  attribution: AttributionConfidence;
  risk: RiskResult;
  tier: EscalationTier;
  repeated: boolean;
  actions: ActionName[];
  skipped: SkippedAction[];
  limit: { count: number; rule: LimitRule | null; instant: boolean };
  alertChannelId: string | null;
}

export interface ActionResult {
  action: ActionName;
  status: 'OK' | 'FAILED' | 'SKIPPED';
  detail: string;
}

/** Enforcement boundary: detectors never call this (spec 03.4); only the pipeline does, after validation. */
export interface ActionExecutor {
  run(ctx: ExecutionContext): Promise<ActionResult[]>;
}
