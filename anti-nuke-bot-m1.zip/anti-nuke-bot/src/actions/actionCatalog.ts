export const ACTION_NAMES = [
  'LOG_ONLY',
  'ALERT',
  'WARN',
  'TIMEOUT',
  'KICK',
  'BAN',
  'QUARANTINE',
  'REMOVE_MANAGEABLE_DANGEROUS_ROLES',
  'RESTRICT_MANAGEABLE_PERMISSIONS',
  'REMOVE_UNAUTHORIZED_BOT',
  'REMOVE_UNAUTHORIZED_WEBHOOK',
  'CHANNEL_LOCKDOWN',
  'CATEGORY_LOCKDOWN',
  'GLOBAL_LOCKDOWN',
  'PANIC_MODE',
  'RECOVERY',
  'ROLLBACK_CHANGE',
  'REQUEST_OWNER_CONFIRMATION',
] as const;

export type ActionName = (typeof ACTION_NAMES)[number];

export const ACTION_LABELS_VI: Record<ActionName, string> = {
  LOG_ONLY: 'Chỉ ghi log',
  ALERT: 'Cảnh báo',
  WARN: 'Cảnh cáo',
  TIMEOUT: 'Timeout',
  KICK: 'Kick',
  BAN: 'Ban',
  QUARANTINE: 'Cách ly',
  REMOVE_MANAGEABLE_DANGEROUS_ROLES: 'Gỡ role nguy hiểm gỡ được',
  RESTRICT_MANAGEABLE_PERMISSIONS: 'Hạn chế quyền role quản lý được',
  REMOVE_UNAUTHORIZED_BOT: 'Gỡ bot trái phép',
  REMOVE_UNAUTHORIZED_WEBHOOK: 'Xóa webhook trái phép',
  CHANNEL_LOCKDOWN: 'Khóa channel',
  CATEGORY_LOCKDOWN: 'Khóa category',
  GLOBAL_LOCKDOWN: 'Khóa toàn server',
  PANIC_MODE: 'Panic Mode',
  RECOVERY: 'Khôi phục',
  ROLLBACK_CHANGE: 'Hoàn tác thay đổi',
  REQUEST_OWNER_CONFIRMATION: 'Yêu cầu chủ server xác nhận',
};

/**
 * Actions that have a real executor in the current milestone. The resolver reports every other action as
 * `NOT_IMPLEMENTED` instead of silently dropping it (spec 13.5). Extend this set only together with the executor.
 */
export const IMPLEMENTED_ACTIONS: ReadonlySet<ActionName> = new Set<ActionName>(['LOG_ONLY', 'ALERT']);

/** Actions that target the actor (Punishment, spec 03.11). */
export const ACTOR_PUNISHMENTS: ReadonlySet<ActionName> = new Set<ActionName>([
  'WARN',
  'TIMEOUT',
  'KICK',
  'BAN',
  'QUARANTINE',
  'REMOVE_MANAGEABLE_DANGEROUS_ROLES',
]);

/** Actions that target resources / the guild, not the actor. */
export const RESOURCE_CONTAINMENT: ReadonlySet<ActionName> = new Set<ActionName>([
  'RESTRICT_MANAGEABLE_PERMISSIONS',
  'REMOVE_UNAUTHORIZED_BOT',
  'REMOVE_UNAUTHORIZED_WEBHOOK',
  'CHANNEL_LOCKDOWN',
  'CATEGORY_LOCKDOWN',
  'GLOBAL_LOCKDOWN',
  'PANIC_MODE',
  'RECOVERY',
  'ROLLBACK_CHANGE',
]);

/** Action set valid for detectors whose Actor is a member or bot (Appendix C). */
export const ACTOR_DETECTOR_ACTIONS: readonly ActionName[] = [
  'LOG_ONLY',
  'ALERT',
  'WARN',
  'TIMEOUT',
  'KICK',
  'BAN',
  'QUARANTINE',
  'REMOVE_MANAGEABLE_DANGEROUS_ROLES',
  'CHANNEL_LOCKDOWN',
  'CATEGORY_LOCKDOWN',
  'GLOBAL_LOCKDOWN',
  'PANIC_MODE',
  'RECOVERY',
  'ROLLBACK_CHANGE',
  'REQUEST_OWNER_CONFIRMATION',
];
