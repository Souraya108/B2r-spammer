import type { Client, Guild } from 'discord.js';
import { errorMessage, type Logger } from '../core/logger.js';
import { buildAlertEmbed } from '../ui/alerts/alertEmbed.js';
import { IMPLEMENTED_ACTIONS } from './actionCatalog.js';
import type { ActionExecutor, ActionResult, ExecutionContext } from './executor.js';

/**
 * Executes the actions implemented in this milestone: LOG_ONLY and ALERT. Every other action is reported as SKIPPED
 * with a reason — never faked (spec 00.6). Quarantine, Panic, Lockdown and Recovery arrive in later milestones.
 */
export class DiscordActionExecutor implements ActionExecutor {
  constructor(
    private readonly client: Client,
    private readonly log: Logger,
  ) {}

  async run(ctx: ExecutionContext): Promise<ActionResult[]> {
    const results: ActionResult[] = [];
    for (const action of ctx.actions) {
      if (action === 'LOG_ONLY') {
        results.push({ action, status: 'OK', detail: 'Đã ghi sự kiện và Incident vào database' });
      } else if (action === 'ALERT') {
        // ALERT runs last (notify bucket) so the embed can list what the other actions did.
        results.push({ action, status: 'SKIPPED', detail: '' });
      } else if (!IMPLEMENTED_ACTIONS.has(action)) {
        results.push({ action, status: 'SKIPPED', detail: 'Chưa triển khai' });
      }
    }
    const alertIndex = results.findIndex((r) => r.action === 'ALERT');
    if (alertIndex !== -1) {
      results[alertIndex] = await this.sendAlert(ctx, results);
    }
    return results;
  }

  private async sendAlert(ctx: ExecutionContext, prior: readonly ActionResult[]): Promise<ActionResult> {
    const guild = this.client.guilds.cache.get(ctx.guildId);
    if (!guild) return { action: 'ALERT', status: 'FAILED', detail: 'Bot không còn trong server' };
    const embed = buildAlertEmbed(ctx, prior.filter((r) => r.action !== 'ALERT'));
    const payload = { embeds: [embed], allowedMentions: { parse: [] as never[] } };

    const channelResult = await this.sendToChannel(guild, ctx.alertChannelId, payload);
    if (channelResult.ok) return { action: 'ALERT', status: 'OK', detail: `Đã gửi tới ${channelResult.where}` };

    // Fallback chain (spec 13.1): alert channel → DM Server Owner → record the failure with a reason code.
    try {
      const owner = await guild.fetchOwner();
      await owner.send(payload);
      return { action: 'ALERT', status: 'OK', detail: `Kênh cảnh báo không dùng được (${channelResult.reason}); đã DM chủ server` };
    } catch (err) {
      this.log.warn('alert_delivery_failed', { guildId: ctx.guildId, channel: channelResult.reason, dm: errorMessage(err) });
      return {
        action: 'ALERT',
        status: 'FAILED',
        detail: `Không gửi được cảnh báo (${channelResult.reason}; DM chủ server thất bại)`,
      };
    }
  }

  private async sendToChannel(
    guild: Guild,
    channelId: string | null,
    payload: { embeds: unknown[]; allowedMentions: { parse: never[] } },
  ): Promise<{ ok: true; where: string } | { ok: false; reason: string }> {
    if (!channelId) return { ok: false, reason: 'CHUA_CAU_HINH_KENH' };
    try {
      const channel = guild.channels.cache.get(channelId) ?? (await guild.channels.fetch(channelId));
      if (!channel || !channel.isTextBased()) return { ok: false, reason: 'KENH_KHONG_HOP_LE' };
      const me = guild.members.me;
      const perms = me ? channel.permissionsFor(me) : null;
      if (!perms?.has(['ViewChannel', 'SendMessages', 'EmbedLinks'])) return { ok: false, reason: 'THIEU_QUYEN_GUI' };
      await channel.send(payload as Parameters<typeof channel.send>[0]);
      return { ok: true, where: `<#${channel.id}>` };
    } catch (err) {
      return { ok: false, reason: errorMessage(err).slice(0, 80) };
    }
  }
}
