export const RISK_LEVELS = ['INFORMATIONAL', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const;
export type RiskLevel = (typeof RISK_LEVELS)[number];

export type DetectorClass = 'DES' | 'MEM' | 'CRE' | 'MOD' | 'PRM' | 'CFG' | 'EXT' | 'IMM';
export type CategoryId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H';
export type PageId = 'P2' | 'P3' | 'P4' | 'P5' | 'P6' | 'P7' | 'P8';
export type ProfileId = 'BALANCED' | 'STRICT';
export type AttributionConfidence = 'CONFIRMED' | 'PROBABLE' | 'POSSIBLE' | 'UNKNOWN';
export type ActorKind = 'USER' | 'BOT' | 'UNKNOWN';
export type EscalationTier = 'FIRST' | 'REPEATED' | 'HIGH' | 'CRITICAL';
export const ESCALATION_ORDER: readonly EscalationTier[] = ['FIRST', 'REPEATED', 'HIGH', 'CRITICAL'];

export type SupportLevel = 'SUPPORTED' | 'PARTIAL' | 'UNSUPPORTED';
export type AttributionCapability = 'FULL' | 'PARTIAL' | 'NONE';

export type OperationalStatus =
  | 'ACTIVE'
  | 'PAUSED'
  | 'DISABLED'
  | 'DEGRADED'
  | 'PERMISSION_BLOCKED'
  | 'UNSUPPORTED'
  | 'FAILED';

export type HealthStatus =
  | 'HEALTHY'
  | 'DEGRADED'
  | 'FAILED'
  | 'DISABLED'
  | 'UNSUPPORTED'
  | 'PERMISSION_BLOCKED';

/** "At most `maxActions` units within a rolling window of `windowSeconds`" (spec 09). */
export interface LimitRule {
  maxActions: number;
  windowSeconds: number;
}

export interface AuditChange {
  key: string;
  old?: unknown;
  new?: unknown;
}

/** Normalized event (spec 03.1). `ts` is always the audit entry timestamp (snowflake time). */
export interface SecurityEvent {
  guildId: string;
  entryId: string;
  actionType: number;
  ts: number;
  executorId: string | null;
  executorKind: ActorKind;
  targetId: string | null;
  changes: AuditChange[];
  reason: string | null;
  source: 'AUDIT' | 'CATCH_UP';
}
