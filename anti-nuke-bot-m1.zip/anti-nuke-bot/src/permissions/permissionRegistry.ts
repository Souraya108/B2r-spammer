import { PermissionFlagsBits } from 'discord.js';

export type PermissionLevel = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'CONTEXT_DEPENDENT' | 'LOW';

export interface DangerousPermission {
  flag: bigint;
  name: string;
  label: string;
  level: PermissionLevel;
}

/** Default classification (spec 08.1). Data only: guild-level overrides arrive with the Limit/Action pages. */
export const DANGEROUS_PERMISSIONS: readonly DangerousPermission[] = [
  { flag: PermissionFlagsBits.Administrator, name: 'Administrator', label: 'Quản trị viên (Administrator)', level: 'CRITICAL' },
  { flag: PermissionFlagsBits.ManageGuild, name: 'ManageGuild', label: 'Quản lý máy chủ', level: 'HIGH' },
  { flag: PermissionFlagsBits.ManageRoles, name: 'ManageRoles', label: 'Quản lý role', level: 'HIGH' },
  { flag: PermissionFlagsBits.ManageChannels, name: 'ManageChannels', label: 'Quản lý channel', level: 'HIGH' },
  { flag: PermissionFlagsBits.ManageWebhooks, name: 'ManageWebhooks', label: 'Quản lý webhook', level: 'HIGH' },
  { flag: PermissionFlagsBits.BanMembers, name: 'BanMembers', label: 'Ban thành viên', level: 'HIGH' },
  { flag: PermissionFlagsBits.KickMembers, name: 'KickMembers', label: 'Kick thành viên', level: 'HIGH' },
  { flag: PermissionFlagsBits.MentionEveryone, name: 'MentionEveryone', label: 'Mention @everyone', level: 'HIGH' },
  { flag: PermissionFlagsBits.ViewAuditLog, name: 'ViewAuditLog', label: 'Xem nhật ký kiểm toán', level: 'MEDIUM' },
  { flag: PermissionFlagsBits.ModerateMembers, name: 'ModerateMembers', label: 'Timeout thành viên', level: 'MEDIUM' },
  { flag: PermissionFlagsBits.ManageThreads, name: 'ManageThreads', label: 'Quản lý thread', level: 'MEDIUM' },
  { flag: PermissionFlagsBits.ManageEvents, name: 'ManageEvents', label: 'Quản lý sự kiện', level: 'MEDIUM' },
  { flag: PermissionFlagsBits.ManageGuildExpressions, name: 'ManageGuildExpressions', label: 'Quản lý emoji/sticker', level: 'MEDIUM' },
  { flag: PermissionFlagsBits.ManageMessages, name: 'ManageMessages', label: 'Quản lý tin nhắn', level: 'CONTEXT_DEPENDENT' },
  { flag: PermissionFlagsBits.ManageNicknames, name: 'ManageNicknames', label: 'Quản lý biệt danh', level: 'CONTEXT_DEPENDENT' },
];

const LEVEL_RANK: Record<PermissionLevel, number> = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, CONTEXT_DEPENDENT: 1, LOW: 0 };

export function toBigInt(value: unknown): bigint {
  if (typeof value === 'bigint') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return BigInt(Math.trunc(value));
  if (typeof value === 'string' && /^\d+$/.test(value)) return BigInt(value);
  return 0n;
}

export interface PermissionDiff {
  added: DangerousPermission[];
  removed: DangerousPermission[];
  highestAdded: PermissionLevel | null;
}

/** Spec 08.2: which classified permissions were added / removed between two permission bitfields. */
export function diffPermissions(oldBits: bigint, newBits: bigint): PermissionDiff {
  const added = DANGEROUS_PERMISSIONS.filter((p) => (newBits & p.flag) === p.flag && (oldBits & p.flag) !== p.flag);
  const removed = DANGEROUS_PERMISSIONS.filter((p) => (oldBits & p.flag) === p.flag && (newBits & p.flag) !== p.flag);
  let highestAdded: PermissionLevel | null = null;
  for (const p of added) {
    if (highestAdded === null || LEVEL_RANK[p.level] > LEVEL_RANK[highestAdded]) highestAdded = p.level;
  }
  return { added, removed, highestAdded };
}

/** P component of the Risk Score (spec 10.1). */
export function permissionContextScore(level: PermissionLevel | null): number {
  switch (level) {
    case 'CRITICAL':
      return 15;
    case 'HIGH':
      return 10;
    case 'MEDIUM':
      return 5;
    default:
      return 0;
  }
}
