import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { ACTOR_DETECTOR_ACTIONS } from '../../actions/actionCatalog.js';
import { diffPermissions, permissionContextScore, toBigInt } from '../../permissions/permissionRegistry.js';
import type { DetectorModule } from '../types.js';

/**
 * B05.1 Dangerous Permission Grant — Administrator. Critical Rule: the first grant is a violation.
 * Role create events are included because a role can be created with Administrator already set.
 */
export const B05_1: DetectorModule = {
  descriptor: {
    id: 'B05.1',
    name: 'Cấp quyền Administrator cho role',
    description: 'Phát hiện role được thêm quyền Administrator (tạo mới hoặc chỉnh sửa).',
    category: 'B',
    page: 'P5',
    class: 'IMM',
    limitMode: 'COUNTED',
    instantDefault: true,
    support: 'SUPPORTED',
    auditActions: [AuditLogEvent.RoleCreate, AuditLogEvent.RoleUpdate],
    requiredPermissions: [PermissionFlagsBits.ViewAuditLog],
    requiredIntents: ['Guilds', 'GuildModeration'],
    attribution: 'FULL',
    compatibleActions: ACTOR_DETECTOR_ACTIONS,
    recovery: false,
    severity: 'CRITICAL',
    riskWeight: 1,
    strictAffected: true,
    limitations: 'Chưa tính số thành viên bị ảnh hưởng; chưa có Rollback quyền role (Phase 10/12).',
  },
  classify(event) {
    const change = event.changes.find((c) => c.key === 'permissions');
    if (!change) return null;
    const diff = diffPermissions(toBigInt(change.old), toBigInt(change.new));
    if (!diff.added.some((p) => p.flag === PermissionFlagsBits.Administrator)) return null;
    const isEveryone = event.targetId === event.guildId;
    return {
      units: 1,
      targetId: event.targetId,
      targetImportance: isEveryone ? 10 : 3,
      permissionContext: permissionContextScore('CRITICAL'),
      tags: isEveryone ? ['EVERYONE_ROLE'] : [],
      summary: `Role ${event.targetId ? `<@&${event.targetId}>` : 'không rõ'} được cấp quyền **Administrator**${isEveryone ? ' (role @everyone)' : ''}`,
    };
  },
};
