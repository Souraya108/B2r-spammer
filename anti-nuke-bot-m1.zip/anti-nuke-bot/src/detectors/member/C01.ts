import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { ACTOR_DETECTOR_ACTIONS } from '../../actions/actionCatalog.js';
import type { DetectorModule } from '../types.js';

/** C01 Anti-Mass Ban. Each ban entry counts as one unit. */
export const C01: DetectorModule = {
  descriptor: {
    id: 'C01',
    name: 'Chống ban hàng loạt',
    description: 'Phát hiện ban nhiều thành viên trong thời gian ngắn (có thêm giới hạn theo giờ).',
    category: 'C',
    page: 'P4',
    class: 'MEM',
    limitMode: 'COUNTED',
    instantDefault: false,
    support: 'SUPPORTED',
    auditActions: [AuditLogEvent.MemberBanAdd],
    requiredPermissions: [PermissionFlagsBits.ViewAuditLog],
    requiredIntents: ['Guilds', 'GuildModeration'],
    attribution: 'FULL',
    compatibleActions: ACTOR_DETECTOR_ACTIONS,
    recovery: false,
    severity: 'HIGH',
    riskWeight: 1,
    strictAffected: false,
    limitations: 'Chưa phân biệt Protected User (C07) nên tầm quan trọng đối tượng dùng mức mặc định. Unban hàng loạt thuộc C03 (chưa làm).',
  },
  classify(event) {
    return {
      units: 1,
      targetId: event.targetId,
      targetImportance: 3,
      permissionContext: 0,
      tags: [],
      summary: `Ban thành viên ${event.targetId ? `<@${event.targetId}>` : 'không rõ'}`,
    };
  },
};
