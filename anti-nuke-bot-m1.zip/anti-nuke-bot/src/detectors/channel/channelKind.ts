import { ChannelType } from 'discord.js';
import type { AuditChange } from '../../types.js';

export type ChannelKind = 'TEXT' | 'VOICE' | 'CATEGORY' | 'UNKNOWN';

/**
 * Classifies a deleted channel from the audit-log `type` change (old value). Ownership (spec 07.0.5):
 * text/announcement/forum/media → TEXT, voice/stage → VOICE, category → CATEGORY.
 */
export function channelKindFromChanges(changes: readonly AuditChange[]): ChannelKind {
  const change = changes.find((c) => c.key === 'type');
  const raw = change?.old ?? change?.new;
  const type = typeof raw === 'string' ? Number(raw) : raw;
  if (typeof type !== 'number' || Number.isNaN(type)) return 'UNKNOWN';
  if (type === ChannelType.GuildCategory) return 'CATEGORY';
  if (type === ChannelType.GuildVoice || type === ChannelType.GuildStageVoice) return 'VOICE';
  return 'TEXT';
}

export function channelNameFromChanges(changes: readonly AuditChange[]): string | null {
  const change = changes.find((c) => c.key === 'name');
  const value = change?.old ?? change?.new;
  return typeof value === 'string' ? value : null;
}
