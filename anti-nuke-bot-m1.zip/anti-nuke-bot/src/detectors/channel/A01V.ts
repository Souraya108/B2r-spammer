import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { ACTOR_DETECTOR_ACTIONS } from '../../actions/actionCatalog.js';
import type { DetectorModule } from '../types.js';
import { channelKindFromChanges, channelNameFromChanges } from './channelKind.js';

/** A01-V Anti-Channel Delete (voice, stage). Own limit and page so Voice has independent configuration. */
export const A01V: DetectorModule = {
  descriptor: {
    id: 'A01-V',
    name: 'Chống xóa channel (thoại)',
    description: 'Phát hiện xóa channel voice và stage hàng loạt.',
    category: 'A',
    page: 'P3',
    class: 'DES',
    limitMode: 'COUNTED',
    instantDefault: false,
    support: 'SUPPORTED',
    auditActions: [AuditLogEvent.ChannelDelete],
    requiredPermissions: [PermissionFlagsBits.ViewAuditLog],
    requiredIntents: ['Guilds', 'GuildModeration'],
    attribution: 'FULL',
    compatibleActions: ACTOR_DETECTOR_ACTIONS,
    recovery: false,
    severity: 'HIGH',
    riskWeight: 1,
    strictAffected: false,
    limitations: 'Chưa có Recovery (Phase 12).',
  },
  classify(event) {
    if (channelKindFromChanges(event.changes) !== 'VOICE') return null;
    const name = channelNameFromChanges(event.changes);
    return {
      units: 1,
      targetId: event.targetId,
      targetImportance: 3,
      permissionContext: 0,
      tags: [],
      summary: `Xóa channel thoại ${name ? `**${name}**` : `\`${event.targetId ?? 'không rõ'}\``}`,
    };
  },
};
