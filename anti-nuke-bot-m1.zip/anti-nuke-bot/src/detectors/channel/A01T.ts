import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { ACTOR_DETECTOR_ACTIONS } from '../../actions/actionCatalog.js';
import type { DetectorModule } from '../types.js';
import { channelKindFromChanges, channelNameFromChanges } from './channelKind.js';

/**
 * A01-T Anti-Channel Delete (text, announcement, forum, media).
 * Signals: single / repeated / mass are all derived from the Limit Engine counts, not from this class.
 */
export const A01T: DetectorModule = {
  descriptor: {
    id: 'A01-T',
    name: 'Chống xóa channel (văn bản)',
    description: 'Phát hiện xóa channel text, announcement, forum, media hàng loạt.',
    category: 'A',
    page: 'P4',
    class: 'DES',
    limitMode: 'COUNTED',
    instantDefault: false,
    support: 'SUPPORTED',
    auditActions: [AuditLogEvent.ChannelDelete],
    requiredPermissions: [PermissionFlagsBits.ViewAuditLog],
    requiredIntents: ['Guilds', 'GuildModeration'],
    attribution: 'FULL',
    compatibleActions: ACTOR_DETECTOR_ACTIONS,
    recovery: false,
    severity: 'HIGH',
    riskWeight: 1,
    strictAffected: false,
    limitations:
      'Chưa phân biệt channel Critical (A11) nên tầm quan trọng đối tượng dùng mức mặc định. Chưa có Recovery (Phase 12).',
  },
  classify(event) {
    const kind = channelKindFromChanges(event.changes);
    if (kind === 'VOICE' || kind === 'CATEGORY') return null;
    const name = channelNameFromChanges(event.changes);
    return {
      units: 1,
      targetId: event.targetId,
      targetImportance: 3,
      permissionContext: 0,
      tags: kind === 'UNKNOWN' ? ['CHANNEL_TYPE_UNKNOWN'] : [],
      summary: `Xóa channel ${name ? `**#${name}**` : `\`${event.targetId ?? 'không rõ'}\``}`,
    };
  },
};
