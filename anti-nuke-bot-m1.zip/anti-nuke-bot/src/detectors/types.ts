import type { ActionName } from '../actions/actionCatalog.js';
import type {
  AttributionCapability,
  CategoryId,
  DetectorClass,
  PageId,
  RiskLevel,
  SecurityEvent,
  SupportLevel,
} from '../types.js';

export type IntentName = 'Guilds' | 'GuildModeration' | 'GuildMembers' | 'GuildWebhooks' | 'GuildInvites';

/** Registry entry — the single source of truth for UI, diagnostics and reports (spec 06.4). */
export interface DetectorDescriptor {
  id: string;
  name: string;
  description: string;
  category: CategoryId;
  page: PageId;
  class: DetectorClass;
  limitMode: 'COUNTED' | 'INSTANT_ONLY';
  /** Critical Rule (spec 09.4): the first countable event is already a violation. */
  instantDefault: boolean;
  support: SupportLevel;
  auditActions: readonly number[];
  requiredPermissions: readonly bigint[];
  requiredIntents: readonly IntentName[];
  attribution: AttributionCapability;
  compatibleActions: readonly ActionName[];
  recovery: boolean;
  severity: RiskLevel;
  riskWeight: number;
  /** Detectors affected by Strict Mode (spec 09.2). */
  strictAffected: boolean;
  limitations: string;
}

/** What a Detector reports for one event. It never executes anything (spec 03.4). */
export interface DetectionSignal {
  /** Units added to the counter (usually 1). */
  units: number;
  targetId: string | null;
  /** T component, 0-15. */
  targetImportance: number;
  /** P component, 0-15. */
  permissionContext: number;
  tags: string[];
  /** Vietnamese one-line summary used in alerts and incidents. */
  summary: string;
}

export interface DetectorModule {
  descriptor: DetectorDescriptor;
  /** Returns null when the event is not relevant to this detector. Must be pure. */
  classify(event: SecurityEvent): DetectionSignal | null;
}
