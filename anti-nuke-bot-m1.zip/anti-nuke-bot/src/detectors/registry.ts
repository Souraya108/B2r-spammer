import type { CategoryId } from '../types.js';
import { A01T } from './channel/A01T.js';
import { A01V } from './channel/A01V.js';
import { B05_1 } from './role/B05_1.js';
import { C01 } from './member/C01.js';
import type { DetectorModule } from './types.js';

/** Single registry: UI, diagnostics and reports are generated from this list (spec 06.4). */
export const DETECTORS: readonly DetectorModule[] = [A01T, A01V, B05_1, C01];

export const CATEGORY_LABELS: Record<CategoryId, string> = {
  A: 'Bảo vệ channel',
  B: 'Bảo vệ role',
  C: 'Bảo vệ thành viên',
  D: 'Bot & tích hợp',
  E: 'Webhook & invite',
  F: 'Cấu hình server',
  G: 'Tài nguyên server',
  H: 'Tự bảo vệ',
};

const byId = new Map(DETECTORS.map((d) => [d.descriptor.id, d]));
const byAction = new Map<number, DetectorModule[]>();
for (const detector of DETECTORS) {
  for (const action of detector.descriptor.auditActions) {
    byAction.set(action, [...(byAction.get(action) ?? []), detector]);
  }
}

if (byId.size !== DETECTORS.length) throw new Error('Detector Registry có ID trùng lặp.');

export function getDetector(id: string): DetectorModule | undefined {
  return byId.get(id);
}

export function detectorsForAuditAction(actionType: number): readonly DetectorModule[] {
  return byAction.get(actionType) ?? [];
}

export function detectorsInCategory(category: CategoryId): DetectorModule[] {
  return DETECTORS.filter((d) => d.descriptor.category === category);
}

/** Categories that currently own at least one detector (UI never shows an empty category). */
export function activeCategories(): CategoryId[] {
  return [...new Set(DETECTORS.map((d) => d.descriptor.category))].sort();
}
