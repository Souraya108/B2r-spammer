import { REST, Routes } from 'discord.js';
import { antinukeDefinition, protectionDefinition } from '../src/commands/definitions.js';
import { loadEnv } from '../src/config/env.js';

const env = loadEnv();
if (!env.clientId) throw new Error('Thiếu DISCORD_CLIENT_ID trong .env');

const body = [antinukeDefinition.toJSON(), protectionDefinition.toJSON()];
const rest = new REST({ version: '10' }).setToken(env.token);
const route = env.devGuildId
  ? Routes.applicationGuildCommands(env.clientId, env.devGuildId)
  : Routes.applicationCommands(env.clientId);

const result = (await rest.put(route, { body })) as unknown[];
console.log(`Đã đăng ký ${result.length} lệnh ${env.devGuildId ? `cho guild ${env.devGuildId}` : '(toàn cục)'}.`);
