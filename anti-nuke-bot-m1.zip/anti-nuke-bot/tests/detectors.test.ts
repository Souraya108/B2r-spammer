import { AuditLogEvent, ChannelType, PermissionFlagsBits } from 'discord.js';
import { describe, expect, it } from 'vitest';
import { A01T } from '../src/detectors/channel/A01T.js';
import { A01V } from '../src/detectors/channel/A01V.js';
import { B05_1 } from '../src/detectors/role/B05_1.js';
import { C01 } from '../src/detectors/member/C01.js';
import { DETECTORS, detectorsForAuditAction } from '../src/detectors/registry.js';
import { attributeFromEntry } from '../src/engine/attribution/attribution.js';
import { channelDelete, ev, memberBan, roleUpdateAdmin, GUILD } from './helpers.js';

describe('Detector Registry', () => {
  it('has unique ids and every detector is routable by its audit actions', () => {
    expect(new Set(DETECTORS.map((d) => d.descriptor.id)).size).toBe(DETECTORS.length);
    for (const d of DETECTORS) for (const a of d.descriptor.auditActions) expect(detectorsForAuditAction(a)).toContain(d);
  });
  it('ChannelDelete routes to both A01-T and A01-V, but only the matching one classifies', () => {
    const text = channelDelete({}, ChannelType.GuildText);
    const voice = channelDelete({}, ChannelType.GuildVoice);
    const stage = channelDelete({}, ChannelType.GuildStageVoice);
    const category = channelDelete({}, ChannelType.GuildCategory);
    for (const forum of [ChannelType.GuildForum, ChannelType.GuildMedia, ChannelType.GuildAnnouncement]) {
      expect(A01T.classify(channelDelete({}, forum))).not.toBeNull();
      expect(A01V.classify(channelDelete({}, forum))).toBeNull();
    }
    expect(A01T.classify(text)).not.toBeNull();
    expect(A01V.classify(text)).toBeNull();
    expect(A01T.classify(voice)).toBeNull();
    expect(A01V.classify(voice)).not.toBeNull();
    expect(A01V.classify(stage)).not.toBeNull();
    // categories belong to A04 (not implemented yet): neither detector counts them
    expect(A01T.classify(category)).toBeNull();
    expect(A01V.classify(category)).toBeNull();
  });
  it('counts exclusively: one event never feeds two detectors of the same ownership', () => {
    const e = channelDelete({}, ChannelType.GuildText);
    expect(DETECTORS.filter((d) => d.descriptor.auditActions.includes(e.actionType)).map((d) => d.classify(e)).filter(Boolean)).toHaveLength(1);
  });
  it('flags an unknown channel type as text with a tag', () => {
    const e = ev({ actionType: AuditLogEvent.ChannelDelete, changes: [] });
    expect(A01T.classify(e)?.tags).toContain('CHANNEL_TYPE_UNKNOWN');
  });
});

describe('B05.1 Administrator grant', () => {
  it('detects Administrator added to an existing role', () => {
    const s = B05_1.classify(roleUpdateAdmin());
    expect(s?.permissionContext).toBe(15);
  });
  it('detects Administrator on role creation', () => {
    const e = ev({ actionType: AuditLogEvent.RoleCreate, changes: [{ key: 'permissions', new: PermissionFlagsBits.Administrator.toString() }] });
    expect(B05_1.classify(e)).not.toBeNull();
  });
  it('ignores roles that already had Administrator, other permissions, and name-only edits', () => {
    const admin = PermissionFlagsBits.Administrator.toString();
    expect(B05_1.classify(ev({ actionType: AuditLogEvent.RoleUpdate, changes: [{ key: 'permissions', old: admin, new: admin }] }))).toBeNull();
    expect(B05_1.classify(ev({ actionType: AuditLogEvent.RoleUpdate, changes: [{ key: 'permissions', old: '0', new: PermissionFlagsBits.BanMembers.toString() }] }))).toBeNull();
    expect(B05_1.classify(ev({ actionType: AuditLogEvent.RoleUpdate, changes: [{ key: 'name', old: 'a', new: 'b' }] }))).toBeNull();
  });
  it('marks the @everyone role as more important', () => {
    const s = B05_1.classify(roleUpdateAdmin({ targetId: GUILD }));
    expect(s?.targetImportance).toBe(10);
    expect(s?.tags).toContain('EVERYONE_ROLE');
  });
  it('removing Administrator is not a grant', () => {
    const admin = PermissionFlagsBits.Administrator.toString();
    expect(B05_1.classify(ev({ actionType: AuditLogEvent.RoleUpdate, changes: [{ key: 'permissions', old: admin, new: '0' }] }))).toBeNull();
  });
});

describe('C01 and attribution', () => {
  it('each ban counts one unit', () => expect(C01.classify(memberBan())?.units).toBe(1));
  it('attribution follows the confidence table', () => {
    const d = C01.descriptor;
    expect(attributeFromEntry(memberBan(), d)).toBe('CONFIRMED');
    expect(attributeFromEntry(memberBan({ targetId: null }), d)).toBe('PROBABLE');
    expect(attributeFromEntry(memberBan({ executorId: null, executorKind: 'UNKNOWN' }), d)).toBe('UNKNOWN');
    expect(attributeFromEntry(memberBan({ actionType: AuditLogEvent.MemberKick }), d)).toBe('POSSIBLE');
    expect(attributeFromEntry(memberBan(), { ...d, attribution: 'PARTIAL' })).toBe('PROBABLE');
    expect(attributeFromEntry(memberBan(), { ...d, attribution: 'NONE' })).toBe('UNKNOWN');
  });
});
