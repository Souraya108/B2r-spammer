import { beforeEach, describe, expect, it } from 'vitest';
import { openDatabase } from '../src/db/database.js';
import { buildAuditReason } from '../src/engine/selfAction/selfAction.js';
import { BOT_ID, channelDelete, createHarness, GUILD, memberBan, OWNER_ID, roleUpdateAdmin, T0, type Harness } from './helpers.js';

const deleteAt = (h: Harness, sec: number, over = {}) => h.pipeline.process(channelDelete({ ts: T0 + sec * 1000, ...over }));

describe('Pipeline — detection to enforcement (integration)', () => {
  let h: Harness;
  beforeEach(() => {
    h = createHarness();
  });

  it('3 channel deletes are counted, the 4th violates and raises exactly one alert', async () => {
    for (const s of [0, 1, 2]) expect((await deleteAt(h, s))[0]!.status).toBe('COUNTED');
    const [fourth] = await deleteAt(h, 3);
    expect(fourth!.status).toBe('VIOLATION');
    expect(fourth!.tier).toBe('FIRST');
    expect(fourth!.risk!.level).toBe('MEDIUM');
    expect(h.executor.calls).toHaveLength(1);
    const ctx = h.executor.calls[0]!;
    expect(ctx.actions).toEqual(expect.arrayContaining(['LOG_ONLY', 'ALERT']));
    expect(ctx.skipped).toContainEqual({ action: 'QUARANTINE', reason: 'NOT_IMPLEMENTED' });
    expect(ctx.attribution).toBe('CONFIRMED');
    expect(h.incidents.get(fourth!.incidentId!)!.actions.length).toBeGreaterThan(0);
  });

  it('applies the cooldown to the same tier but executes a higher tier immediately', async () => {
    const outcomes = [];
    for (let s = 0; s < 10; s++) outcomes.push((await deleteAt(h, s))[0]!);
    const statuses = outcomes.map((o) => o.status);
    expect(statuses[3]).toBe('VIOLATION');
    expect(statuses[4]).toBe('VIOLATION_SUPPRESSED');
    const tiers = h.executor.calls.map((c) => c.tier);
    expect(tiers[0]).toBe('FIRST');
    expect(tiers).toContain('HIGH');
    // every event inside one episode lands in a single Incident
    expect(new Set(outcomes.filter((o) => o.incidentId).map((o) => o.incidentId)).size).toBe(1);
  });

  it('a second burst after the episode closed is "repeated" and escalates to the REPEATED tier', async () => {
    for (const s of [0, 1, 2, 3]) await deleteAt(h, s);
    const outcomes = [];
    for (const s of [200, 201, 202, 203]) outcomes.push((await deleteAt(h, s))[0]!);
    expect(outcomes[3]!.status).toBe('VIOLATION');
    expect(outcomes[3]!.tier).toBe('REPEATED');
    expect(h.executor.calls[1]!.repeated).toBe(true);
  });

  it('B05.1 is a Critical Rule: the first Administrator grant violates at once', async () => {
    const [o] = await h.pipeline.process(roleUpdateAdmin({ ts: T0 }));
    expect(o!.status).toBe('VIOLATION');
    expect(o!.risk!.components).toMatchObject({ S: 40, F: 15, P: 15 });
    expect(o!.tier).toBe('HIGH');
  });

  it('@everyone gets Administrator → CRITICAL tier', async () => {
    const [o] = await h.pipeline.process(roleUpdateAdmin({ ts: T0, targetId: GUILD }));
    expect(o!.risk!.level).toBe('CRITICAL');
    expect(o!.tier).toBe('CRITICAL');
  });

  it('Strict Mode raises B05.1 by one band', async () => {
    h.config.commit(GUILD, h.config.get(GUILD).configVersion, [{ type: 'STRICT_MODE', value: true }], { changedBy: 't', source: 't' });
    const [o] = await h.pipeline.process(roleUpdateAdmin({ ts: T0 }));
    expect(o!.risk!.level).toBe('CRITICAL');
  });

  it('never punishes the Server Owner and records why', async () => {
    for (const s of [0, 1, 2, 3]) await h.pipeline.process(memberBan({ ts: T0 + s * 1000, executorId: OWNER_ID }));
    const ctx = h.executor.calls[0]!;
    expect(ctx.actor.isOwner).toBe(true);
    expect(ctx.skipped).toContainEqual({ action: 'QUARANTINE', reason: 'TARGET_PROTECTED' });
  });

  it('Unknown actor: counted in its own bucket, only containment/alerts, no actor punishment', async () => {
    for (const s of [0, 1, 2, 3]) await h.pipeline.process(memberBan({ ts: T0 + s * 1000, executorId: null, executorKind: 'UNKNOWN' }));
    const ctx = h.executor.calls[0]!;
    expect(ctx.attribution).toBe('UNKNOWN');
    expect(ctx.skipped).toContainEqual({ action: 'QUARANTINE', reason: 'ACTOR_NOT_APPLICABLE' });
  });

  it('an exempt actor is recorded as evidence but never counted, heated or enforced', async () => {
    h.allowlist.add({ guildId: GUILD, subjectType: 'USER', subjectId: 'u1', scope: { kind: 'ALL' }, expiresAt: null, createdBy: 'o', createdAt: T0, reason: 'test' });
    for (let s = 0; s < 10; s++) expect((await deleteAt(h, s))[0]!.status).toBe('EXEMPT');
    expect(h.executor.calls).toHaveLength(0);
    expect(h.securityEvents.since(GUILD, 0).every((e) => e.flags.includes('EXEMPT'))).toBe(true);
    expect(h.securityEvents.since(GUILD, 0)).toHaveLength(10);
  });

  it('allowlist scope: a category-C exemption covers C01 but not A01-T', async () => {
    h.allowlist.add({ guildId: GUILD, subjectType: 'USER', subjectId: 'u1', scope: { kind: 'CATEGORIES', ids: ['C'] }, expiresAt: null, createdBy: 'o', createdAt: T0, reason: 'mods' });
    expect((await h.pipeline.process(memberBan({ ts: T0 })))[0]!.status).toBe('EXEMPT');
    expect((await deleteAt(h, 0))[0]!.status).toBe('COUNTED');
  });

  it('role allowlist applies through the actor\'s roles while the entry is active', async () => {
    h.roleIds.value = ['role-mod'];
    h.allowlist.add({ guildId: GUILD, subjectType: 'ROLE', subjectId: 'role-mod', scope: { kind: 'ALL' }, expiresAt: Date.now() + 3_600_000, createdBy: 'o', createdAt: Date.now(), reason: 'window' });
    expect((await h.pipeline.process(memberBan({ ts: T0 })))[0]!.status).toBe('EXEMPT');
  });

  it('expired allowlist entries (user or role) no longer exempt anyone', async () => {
    h.roleIds.value = ['role-mod'];
    h.allowlist.add({ guildId: GUILD, subjectType: 'ROLE', subjectId: 'role-mod', scope: { kind: 'ALL' }, expiresAt: Date.now() - 1000, createdBy: 'o', createdAt: 0, reason: 'old' });
    h.allowlist.add({ guildId: GUILD, subjectType: 'USER', subjectId: 'u9', scope: { kind: 'ALL' }, expiresAt: Date.now() - 1000, createdBy: 'o', createdAt: 0, reason: 'old' });
    expect((await h.pipeline.process(memberBan({ ts: T0 })))[0]!.status).toBe('COUNTED');
    expect((await h.pipeline.process(memberBan({ ts: T0, executorId: 'u9' })))[0]!.status).toBe('COUNTED');
  });

  it('ignores duplicate deliveries of the same entry', async () => {
    const e = channelDelete({ ts: T0 });
    expect((await h.pipeline.process(e))[0]!.status).toBe('COUNTED');
    expect((await h.pipeline.process(e))[0]!.status).toBe('DUPLICATE');
    for (const s of [1, 2]) await deleteAt(h, s);
    expect((await deleteAt(h, 3))[0]!.status).toBe('VIOLATION'); // 4 distinct events, not 5
  });

  it('bot self-actions never count; unexpected self-actions are surfaced separately', async () => {
    const own = await h.pipeline.process(channelDelete({ executorId: BOT_ID, reason: buildAuditReason('op1', 'lockdown') }));
    expect(own).toEqual([{ detectorId: '*', status: 'SELF_ACTION' }]);
    for (let i = 0; i < 6; i++) await h.pipeline.process(channelDelete({ executorId: BOT_ID, reason: buildAuditReason('op1', 'x'), ts: T0 + i }));
    expect(h.executor.calls).toHaveLength(0);
    const unexpected = await h.pipeline.process(channelDelete({ executorId: BOT_ID, reason: null }));
    expect(unexpected[0]!.status).toBe('SELF_UNEXPECTED');
  });

  it('does nothing while Anti-Nuke is OFF, and respects per-detector and per-category switches', async () => {
    const off = createHarness({ enable: false });
    expect(await off.pipeline.process(channelDelete())).toEqual([]);

    h.config.commit(GUILD, h.config.get(GUILD).configVersion, [{ type: 'DETECTOR_ENABLED', detectorId: 'A01-T', value: false }], { changedBy: 't', source: 't' });
    expect((await deleteAt(h, 0))[0]!.status).toBe('DISABLED');
    h.config.commit(GUILD, h.config.get(GUILD).configVersion, [{ type: 'CATEGORY_ENABLED', category: 'C', value: false }], { changedBy: 't', source: 't' });
    expect((await h.pipeline.process(memberBan()))[0]!.status).toBe('DISABLED');
  });

  it('isolates guilds from each other', async () => {
    const other = '200';
    h.config.commit(other, h.config.get(other).configVersion, [{ type: 'GLOBAL_ENABLED', value: true }], { changedBy: 't', source: 't' });
    for (const s of [0, 1, 2]) await deleteAt(h, s);
    const [b] = await h.pipeline.process(channelDelete({ guildId: other, ts: T0 + 3000 }));
    expect(b!.status).toBe('COUNTED');
    expect(h.securityEvents.since(other, 0)).toHaveLength(1);
  });

  it('rebuilds counters from the database after a restart', async () => {
    for (const s of [0, 1, 2]) await deleteAt(h, s);
    const restarted = h.makePipeline();
    expect(restarted.rehydrate(GUILD, T0 + 3000)).toBe(3);
    const [o] = await restarted.process(channelDelete({ ts: T0 + 3000 }));
    expect(o!.status).toBe('VIOLATION');
  });

  it('a throwing executor never crashes the pipeline and the failure is recorded', async () => {
    h.executor.run = async () => {
      throw new Error('boom');
    };
    for (const s of [0, 1, 2]) await deleteAt(h, s);
    const [o] = await deleteAt(h, 3);
    expect(o!.status).toBe('VIOLATION');
    expect(h.incidents.get(o!.incidentId!)!.actions.some((a) => a.status === 'FAILED')).toBe(true);
  });

  it('persists the whole schema through a real file database (migrations + WAL)', async () => {
    const file = `/tmp/antinuke-test-${Date.now()}.sqlite`;
    const db = openDatabase(file);
    const hh = createHarness({ db });
    await hh.pipeline.process(roleUpdateAdmin({ ts: T0 }));
    db.close();
    const reopened = openDatabase(file);
    expect((reopened.prepare('SELECT COUNT(*) AS n FROM incidents').get() as { n: number }).n).toBe(1);
    reopened.close();
  });
});
