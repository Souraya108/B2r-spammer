import { AuditLogEvent, ChannelType, PermissionFlagsBits } from 'discord.js';
import type { ActionExecutor, ActionResult, ExecutionContext } from '../src/actions/executor.js';
import { GuildConfigService } from '../src/config/guildConfig.js';
import { silentLogger } from '../src/core/logger.js';
import { openDatabase, type Db } from '../src/db/database.js';
import { AllowlistRepo } from '../src/db/repositories/allowlistRepo.js';
import { EpisodeRepo } from '../src/db/repositories/episodeRepo.js';
import { IncidentRepo } from '../src/db/repositories/incidentRepo.js';
import { SecurityEventRepo } from '../src/db/repositories/securityEventRepo.js';
import { SecurityOwnerRepo } from '../src/db/repositories/securityOwnerRepo.js';
import { SecurityPipeline } from '../src/engine/pipeline/securityPipeline.js';
import { TrustService } from '../src/engine/trust/trustService.js';
import type { SecurityEvent } from '../src/types.js';

export const GUILD = '100';
export const BOT_ID = '999';
export const OWNER_ID = '1';
export const T0 = 1_700_000_000_000;

let counter = 0;
export function ev(partial: Partial<SecurityEvent> & Pick<SecurityEvent, 'actionType'>): SecurityEvent {
  counter++;
  return {
    guildId: GUILD,
    entryId: `e${counter}`,
    ts: T0,
    executorId: 'u1',
    executorKind: 'USER',
    targetId: 't1',
    changes: [],
    reason: null,
    source: 'AUDIT',
    ...partial,
  };
}

export const channelDelete = (over: Partial<SecurityEvent> = {}, type: number = ChannelType.GuildText): SecurityEvent =>
  ev({ actionType: AuditLogEvent.ChannelDelete, changes: [{ key: 'type', old: type }, { key: 'name', old: 'general' }], ...over });

export const memberBan = (over: Partial<SecurityEvent> = {}): SecurityEvent => ev({ actionType: AuditLogEvent.MemberBanAdd, ...over });

export const roleUpdateAdmin = (over: Partial<SecurityEvent> = {}): SecurityEvent =>
  ev({
    actionType: AuditLogEvent.RoleUpdate,
    changes: [{ key: 'permissions', old: '0', new: PermissionFlagsBits.Administrator.toString() }],
    ...over,
  });

export class FakeExecutor implements ActionExecutor {
  readonly calls: ExecutionContext[] = [];
  async run(ctx: ExecutionContext): Promise<ActionResult[]> {
    this.calls.push(ctx);
    return ctx.actions.map((action) => ({ action, status: 'OK' as const, detail: 'fake' }));
  }
}

export interface Harness {
  db: Db;
  config: GuildConfigService;
  allowlist: AllowlistRepo;
  owners: SecurityOwnerRepo;
  incidents: IncidentRepo;
  securityEvents: SecurityEventRepo;
  executor: FakeExecutor;
  pipeline: SecurityPipeline;
  makePipeline: () => SecurityPipeline;
  roleIds: { value: string[] };
}

export function createHarness(opts: { db?: Db; enable?: boolean; ownerId?: string } = {}): Harness {
  const db = opts.db ?? openDatabase(':memory:');
  const config = new GuildConfigService(db);
  const allowlist = new AllowlistRepo(db);
  const owners = new SecurityOwnerRepo(db);
  const securityEvents = new SecurityEventRepo(db);
  const incidents = new IncidentRepo(db);
  const executor = new FakeExecutor();
  const roleIds = { value: [] as string[] };
  const make = (): SecurityPipeline =>
    new SecurityPipeline({
      botUserId: () => BOT_ID,
      config,
      trust: new TrustService(allowlist, owners),
      securityEvents,
      episodes: new EpisodeRepo(db),
      incidents,
      executor,
      guildInfo: () => ({ ownerId: opts.ownerId ?? OWNER_ID, isAdministrator: async () => false }),
      roleIdsOf: async () => roleIds.value,
      log: silentLogger,
    });
  if (opts.enable !== false) {
    config.commit(GUILD, config.get(GUILD).configVersion, [{ type: 'GLOBAL_ENABLED', value: true }], { changedBy: 'test', source: 'test' });
  }
  return { db, config, allowlist, owners, incidents, securityEvents, executor, pipeline: make(), makePipeline: make, roleIds };
}
