import { PermissionFlagsBits } from 'discord.js';
import { beforeEach, describe, expect, it } from 'vitest';
import { GuildConfigService } from '../src/config/guildConfig.js';
import { silentLogger } from '../src/core/logger.js';
import { openDatabase } from '../src/db/database.js';
import { SecurityOwnerRepo } from '../src/db/repositories/securityOwnerRepo.js';
import { UiSessionRepo } from '../src/db/repositories/uiSessionRepo.js';
import { buildCustomId } from '../src/ui/settings/customId.js';
import { SettingsPanel } from '../src/ui/settings/panel.js';

const GUILD = '100';
const OWNER = '1';
const ADMIN = '2';
const SEC_OWNER = '3';
const NOBODY = '4';

interface Sent { editReply: unknown[]; followUp: string[]; deferred: number }

function setup(botPermissions: bigint = PermissionFlagsBits.ViewAuditLog) {
  const db = openDatabase(':memory:');
  const config = new GuildConfigService(db);
  const owners = new SecurityOwnerRepo(db);
  owners.add(GUILD, SEC_OWNER, OWNER, Date.now());
  const admins = new Set([ADMIN]);
  const guild = {
    id: GUILD,
    ownerId: OWNER,
    members: {
      me: { permissions: { bitfield: botPermissions } },
      fetch: async ({ user }: { user: string }) => ({ permissions: { has: () => admins.has(user) } }),
    },
    channels: { cache: new Map() },
  };
  const client = { isReady: () => true, ws: { ping: 42 }, options: { intents: { has: () => true } } };
  const panel = new SettingsPanel({
    client: client as never, db, config, owners, log: silentLogger, mailboxStats: () => ({ queued: 0, rejected: 0 }),
  });
  const sessions = new UiSessionRepo(db);
  let n = 0;

  const open = async (userId: string) => {
    const sent: Sent = { editReply: [], followUp: [], deferred: 0 };
    await panel.open({
      guild, user: { id: userId },
      deferReply: async () => { sent.deferred++; },
      reply: async (p: unknown) => { sent.editReply.push(p); },
      editReply: async (p: unknown) => { sent.editReply.push(p); },
    } as never);
    return sent;
  };

  const click = async (userId: string, sessionId: string, action: string, ...args: string[]) => {
    const sent: Sent = { editReply: [], followUp: [], deferred: 0 };
    const interaction = {
      id: `i${++n}`, customId: buildCustomId(sessionId, action, ...args), guild, user: { id: userId },
      inGuild: () => true, isStringSelectMenu: () => false, isChannelSelectMenu: () => false,
      deferUpdate: async () => { sent.deferred++; },
      editReply: async (p: unknown) => { sent.editReply.push(p); },
      followUp: async (p: { content: string }) => { sent.followUp.push(p.content); },
    };
    await panel.handle(interaction as never);
    return { sent, interaction };
  };

  const newSession = (userId: string, expiresAt = Date.now() + 60_000) =>
    sessions.create(GUILD, userId, { view: 'OVERVIEW' }, config.get(GUILD).configVersion, expiresAt);

  const clickSelect = async (userId: string, sessionId: string, action: string, value: string, kind: 'string' | 'channel' = 'string') => {
    const sent: Sent = { editReply: [], followUp: [], deferred: 0 };
    const interaction = {
      id: `i${++n}`, customId: buildCustomId(sessionId, action), guild, user: { id: userId },
      inGuild: () => true, values: [value],
      isStringSelectMenu: () => kind === 'string', isChannelSelectMenu: () => kind === 'channel',
      deferUpdate: async () => { sent.deferred++; },
      editReply: async (p: unknown) => { sent.editReply.push(p); },
      followUp: async (p: { content: string }) => { sent.followUp.push(p.content); },
    };
    await panel.handle(interaction as never);
    return { sent };
  };

  return { db, config, owners, panel, sessions, admins, open, click, clickSelect, newSession };
}

const textOf = (payload: unknown): string => JSON.stringify(payload);

describe('Settings panel — security of every interaction (spec 19.21)', () => {
  let t: ReturnType<typeof setup>;
  beforeEach(() => {
    t = setup();
  });

  it('refuses to open for a member without Administrator and creates no session', async () => {
    const sent = await t.open(NOBODY);
    expect(textOf(sent.editReply)).toContain('không có quyền');
    expect((t.db.prepare('SELECT COUNT(*) AS n FROM ui_sessions').get() as { n: number }).n).toBe(0);
  });

  it('opens a Components V2 panel for an Administrator and stores the session', async () => {
    const sent = await t.open(ADMIN);
    const payload = sent.editReply[0] as { components: unknown[]; flags: number };
    expect(payload.components).toHaveLength(1);
    expect(payload.flags & (1 << 15)).toBeTruthy(); // IsComponentsV2
    expect((t.db.prepare('SELECT owner_id FROM ui_sessions').get() as { owner_id: string }).owner_id).toBe(ADMIN);
  });

  it('rejects a forged / unknown session id', async () => {
    const { sent } = await t.click(ADMIN, 'doesnotexist', 'ref');
    expect(sent.followUp.join()).toContain('Phiên không hợp lệ');
    expect(sent.editReply).toHaveLength(0);
  });

  it("rejects someone else's panel even if they know the session id", async () => {
    const s = t.newSession(ADMIN);
    const { sent } = await t.click(SEC_OWNER, s.id, 'ref');
    expect(sent.followUp.join()).toContain('thuộc về người đã mở');
  });

  it('rejects an expired session', async () => {
    const s = t.newSession(ADMIN, Date.now() - 1);
    const { sent } = await t.click(ADMIN, s.id, 'ref');
    expect(sent.followUp.join()).toContain('hết hạn');
  });

  it('ignores a duplicate delivery of the same interaction', async () => {
    const s = t.newSession(ADMIN);
    const first = await t.click(ADMIN, s.id, 'ref');
    const again = { ...first.interaction };
    let deferred = 0;
    again.deferUpdate = async () => { deferred++; };
    await t.panel.handle(again as never);
    expect(deferred).toBe(0);
  });

  it('re-checks authority on every click: an admin demoted mid-session loses access immediately', async () => {
    const s = t.newSession(ADMIN);
    const before = await t.click(ADMIN, s.id, 'cattog', 'C');
    expect(before.sent.followUp).toEqual([]);
    expect(t.config.reload(GUILD).categoryEnabled.C).toBe(false);

    t.admins.delete(ADMIN); // Administrator permission removed while the panel is still open
    const after = await t.click(ADMIN, s.id, 'cattog', 'C');
    expect(after.sent.followUp.join()).toContain('không có quyền');
    expect(t.config.reload(GUILD).categoryEnabled.C).toBe(false); // unchanged by the denied click
  });

  it('Enable All as admin turns Anti-Nuke on but the panel never shows ON while detectors are not ACTIVE', async () => {
    const s = t.newSession(ADMIN);
    const { sent } = await t.click(ADMIN, s.id, 'ena');
    expect(t.config.reload(GUILD).enabled).toBe(true);
    expect(sent.followUp.join()).toContain('Đã bật Anti-Nuke');
    expect(sent.followUp.join()).toContain('ALERT_CHANNEL_UNAVAILABLE'); // reason code, not hidden
    const rendered = textOf(sent.editReply);
    expect(rendered).toContain('SUY GIẢM');
    expect(rendered).not.toContain('— 🟢 BẬT');
  });

  it('Enable All reports PERMISSION_BLOCKED detectors when the bot lacks View Audit Log', async () => {
    const blocked = setup(0n);
    const s = blocked.newSession(ADMIN);
    const { sent } = await blocked.click(ADMIN, s.id, 'ena');
    expect(sent.followUp.join()).toContain('MISSING_PERMISSION');
    expect(sent.followUp.join()).toContain('ViewAuditLog');
  });

  it('an Administrator cannot disable all, change the preset, or toggle Strict Mode', async () => {
    const s = t.newSession(ADMIN);
    for (const [action, args] of [['dis', []], ['disc', []], ['str', []], ['pre', []]] as const) {
      const { sent } = await t.click(ADMIN, s.id, action, ...args);
      expect(sent.followUp.join()).toContain('Cần tối thiểu');
    }
    expect(t.config.reload(GUILD)).toMatchObject({ strictMode: false, profile: 'BALANCED', configVersion: 0 });
  });

  it('Security Owner must confirm Disable All; confirming without the prompt does nothing', async () => {
    t.config.commit(GUILD, 0, [{ type: 'GLOBAL_ENABLED', value: true }], { changedBy: 'x', source: 't' });
    const s = t.sessions.create(GUILD, SEC_OWNER, { view: 'OVERVIEW' }, 1, Date.now() + 60_000);
    const skipped = await t.click(SEC_OWNER, s.id, 'disc');
    expect(skipped.sent.followUp.join()).toContain('hết hạn');
    expect(t.config.reload(GUILD).enabled).toBe(true);

    await t.click(SEC_OWNER, s.id, 'dis');
    expect(t.sessions.get(s.id)!.state.view).toBe('CONFIRM_DISABLE');
    const done = await t.click(SEC_OWNER, s.id, 'disc');
    expect(done.sent.followUp.join()).toContain('Đã tắt toàn bộ');
    expect(t.config.reload(GUILD).enabled).toBe(false);
  });

  it('an expired confirmation prompt does not disable anything', async () => {
    t.config.commit(GUILD, 0, [{ type: 'GLOBAL_ENABLED', value: true }], { changedBy: 'x', source: 't' });
    const s = t.sessions.create(GUILD, SEC_OWNER, { view: 'CONFIRM_DISABLE', until: Date.now() - 1 }, 1, Date.now() + 60_000);
    await t.click(SEC_OWNER, s.id, 'disc');
    expect(t.config.reload(GUILD).enabled).toBe(true);
  });

  it('preset: an Administrator is denied, a Security Owner can switch (STRICT also enables Strict Mode)', async () => {
    const adminSession = t.newSession(ADMIN);
    const denied = await t.clickSelect(ADMIN, adminSession.id, 'pre', 'STRICT');
    expect(denied.sent.followUp.join()).toContain('Cần tối thiểu');
    expect(t.config.reload(GUILD).profile).toBe('BALANCED');

    const s = t.newSession(SEC_OWNER);
    const ok = await t.clickSelect(SEC_OWNER, s.id, 'pre', 'STRICT');
    expect(ok.sent.followUp.join()).toContain('STRICT');
    expect(t.config.reload(GUILD)).toMatchObject({ profile: 'STRICT', strictMode: true });

    const bad = await t.clickSelect(SEC_OWNER, t.sessions.get(s.id)!.id, 'pre', 'EVIL');
    expect(bad.sent.followUp.join()).toContain('không hợp lệ');
    expect(t.config.reload(GUILD).profile).toBe('STRICT');
  });

  it('Security Owner can toggle Strict Mode and detectors, and toggling twice restores the original state', async () => {
    const s = t.newSession(SEC_OWNER);
    await t.click(SEC_OWNER, s.id, 'str');
    expect(t.config.reload(GUILD).strictMode).toBe(true);
    await t.click(SEC_OWNER, s.id, 'dt', 'A01-T');
    expect(t.config.reload(GUILD).detectorEnabled['A01-T']).toBe(false);
    await t.click(SEC_OWNER, s.id, 'dt', 'A01-T');
    expect(t.config.reload(GUILD).detectorEnabled['A01-T']).toBe(true);
  });

  it('alert channel select: an unusable channel is refused and nothing is saved', async () => {
    const s = t.newSession(ADMIN);
    const res = await t.clickSelect(ADMIN, s.id, 'ch', '999', 'channel');
    expect(res.sent.followUp.join()).toContain('không gửi được');
    expect(t.config.reload(GUILD).alertChannelId).toBeNull();
  });

  it('concurrent edits: a stale panel is rejected instead of overwriting the newer configuration', async () => {
    const s = t.newSession(SEC_OWNER);
    t.config.commit(GUILD, 0, [{ type: 'ALERT_CHANNEL', value: '555' }], { changedBy: 'other', source: 't' }); // version 1 behind the panel's back
    const { sent } = await t.click(SEC_OWNER, s.id, 'str');
    expect(sent.followUp.join()).toContain('vừa được người khác thay đổi');
    expect(t.config.reload(GUILD).strictMode).toBe(false);
  });

  it('Refresh resyncs the panel with the latest version so the next change succeeds', async () => {
    const s = t.newSession(SEC_OWNER);
    t.config.commit(GUILD, 0, [{ type: 'ALERT_CHANNEL', value: '555' }], { changedBy: 'other', source: 't' });
    await t.click(SEC_OWNER, s.id, 'ref');
    await t.click(SEC_OWNER, s.id, 'str');
    expect(t.config.reload(GUILD).strictMode).toBe(true);
  });

  it('rate-limits a user who clicks too fast', async () => {
    const s = t.newSession(ADMIN);
    let last = { sent: { followUp: [] as string[] } };
    for (let i = 0; i < 12; i++) last = (await t.click(ADMIN, s.id, 'ref')) as never;
    expect(last.sent.followUp.join()).toContain('quá nhanh');
  });

  it('rejects an unknown action and an unknown detector id', async () => {
    const s = t.newSession(ADMIN);
    expect((await t.click(ADMIN, s.id, 'nuke')).sent.followUp.join()).toContain('không hợp lệ');
    expect((await t.click(ADMIN, s.id, 'dt', 'ZZZ')).sent.followUp.join()).toContain('không hợp lệ');
    expect((await t.click(ADMIN, s.id, 'cattog', 'Z')).sent.followUp.join()).toContain('không hợp lệ');
  });

  it('category and detector toggles are written to Configuration History with the user id', async () => {
    const s = t.newSession(ADMIN);
    await t.click(ADMIN, s.id, 'cattog', 'C');
    const row = t.db.prepare("SELECT changed_by, key, new_value FROM configuration_history WHERE key LIKE 'category.%'").get();
    expect(row).toEqual({ changed_by: ADMIN, key: 'category.C.enabled', new_value: 'false' });
  });
});
