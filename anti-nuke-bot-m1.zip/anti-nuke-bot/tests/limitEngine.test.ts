import { describe, expect, it } from 'vitest';
import { evaluateLimit } from '../src/engine/limit/limitEvaluator.js';
import { SlidingWindowCounter } from '../src/engine/limit/slidingWindow.js';

const rule = (maxActions: number, windowSeconds: number) => ({ maxActions, windowSeconds });
const run = (counter: SlidingWindowCounter, id: string, tSec: number, rules = [rule(3, 10)], instant = false) =>
  evaluateLimit(counter, 'k', { id, ts: tSec * 1000, units: 1 }, rules, instant);

describe('Limit Engine — boundary semantics (spec 09.1)', () => {
  it('allows N actions and violates on the N+1-th', () => {
    const c = new SlidingWindowCounter(86_400_000);
    expect([0, 1, 2].map((t) => run(c, `a${t}`, t).violated)).toEqual([false, false, false]);
    const fourth = run(c, 'a3', 3);
    expect(fourth.violated).toBe(true);
    expect(fourth.count).toBe(4);
  });

  it('event exactly at T-W is outside the window (half-open interval)', () => {
    const c = new SlidingWindowCounter(86_400_000);
    run(c, 'a0', 0);
    run(c, 'a1', 1);
    run(c, 'a2', 2);
    const r = run(c, 'a3', 10); // window (0, 10] -> t=0 excluded
    expect(r.violated).toBe(false);
    expect(r.count).toBe(3);
  });

  it('event just inside the window (t = 9.9s) counts as the 4th', () => {
    const c = new SlidingWindowCounter(86_400_000);
    run(c, 'a0', 0);
    run(c, 'a1', 1);
    run(c, 'a2', 2);
    const r = evaluateLimit(c, 'k', { id: 'a3', ts: 9_900, units: 1 }, [rule(3, 10)], false);
    expect(r.violated).toBe(true);
    expect(r.count).toBe(4);
  });

  it('never double-counts a duplicate entry id', () => {
    const c = new SlidingWindowCounter(86_400_000);
    for (const t of [0, 1, 2]) run(c, `a${t}`, t);
    const dup = run(c, 'a2', 2);
    expect(dup.duplicate).toBe(true);
    expect(dup.violated).toBe(false);
    expect(run(c, 'a3', 3).count).toBe(4); // still exactly 4 distinct events
  });

  it('is independent of arrival order (out-of-order events)', () => {
    const c = new SlidingWindowCounter(86_400_000);
    run(c, 'a3', 3);
    run(c, 'a1', 1);
    run(c, 'a2', 2);
    const r = run(c, 'a0', 0);
    expect(r.count).toBe(1); // count(T=0) only sees events with ts <= 0
    expect(c.count('k', 3_000, 10)).toBe(4);
  });

  it('instant rule: the first event is already a violation', () => {
    const c = new SlidingWindowCounter(86_400_000);
    const r = run(c, 'x', 0, [], true);
    expect(r.violated).toBe(true);
    expect(r.instant).toBe(true);
    expect(r.rule).toEqual({ maxActions: 0, windowSeconds: 0 });
  });

  it('evaluates multiple rules independently and reports the one that fired', () => {
    const c = new SlidingWindowCounter(86_400_000);
    const rules = [rule(3, 10), rule(10, 3600)];
    // 10 bans spaced 20 s apart never break 3/10s but the 11th breaks 10/3600
    let last = run(c, 'b0', 0, rules);
    for (let i = 1; i <= 10; i++) last = run(c, `b${i}`, i * 20, rules);
    expect(last.violated).toBe(true);
    expect(last.rule).toEqual(rule(10, 3600));
    expect(last.count).toBe(11);
  });

  it('counts by units, not by entries, when units > 1', () => {
    const c = new SlidingWindowCounter(86_400_000);
    const r = evaluateLimit(c, 'k', { id: 'p', ts: 0, units: 5 }, [rule(3, 10)], false);
    expect(r.violated).toBe(true);
    expect(r.count).toBe(5);
  });

  it('sweep drops stale keys', () => {
    const c = new SlidingWindowCounter(1000);
    run(c, 'old', 0);
    c.sweep(10_000);
    expect(c.size).toBe(0);
  });
});
