import { describe, expect, it } from 'vitest';
import { ConfigConflictError, GuildConfigService } from '../src/config/guildConfig.js';
import { openDatabase } from '../src/db/database.js';
import { A01T } from '../src/detectors/channel/A01T.js';
import { B05_1 } from '../src/detectors/role/B05_1.js';
import { C01 } from '../src/detectors/member/C01.js';
import { computeDetectorStatus, computeOverallStatus, type BotCapabilities } from '../src/diagnostics/operationalStatus.js';
import { PermissionFlagsBits } from 'discord.js';
import { can, requiredLevel } from '../src/ops/authority.js';

const meta = { changedBy: 'u', source: 't' };
const make = () => new GuildConfigService(openDatabase(':memory:'));

describe('Guild configuration', () => {
  it('starts OFF with version 0 and defaults inherited', () => {
    const c = make().get('g');
    expect(c).toMatchObject({ enabled: false, profile: 'BALANCED', strictMode: false, configVersion: 0 });
  });

  it('commit bumps the version, persists, and writes Configuration History with old/new values', () => {
    const s = make();
    const next = s.commit('g', 0, [{ type: 'GLOBAL_ENABLED', value: true }, { type: 'PROFILE', value: 'STRICT' }], meta);
    expect(next).toMatchObject({ enabled: true, profile: 'STRICT', configVersion: 1 });
    const rows = (s as unknown as { db: ReturnType<typeof openDatabase> }).db
      .prepare('SELECT key, old_value, new_value, version FROM configuration_history ORDER BY id')
      .all();
    expect(rows).toEqual([
      { key: 'global.enabled', old_value: 'false', new_value: 'true', version: 1 },
      { key: 'global.profile', old_value: 'BALANCED', new_value: 'STRICT', version: 1 },
    ]);
  });

  it('optimistic locking: a stale version is rejected and nothing is written', () => {
    const s = make();
    s.commit('g', 0, [{ type: 'GLOBAL_ENABLED', value: true }], meta);
    expect(() => s.commit('g', 0, [{ type: 'STRICT_MODE', value: true }], meta)).toThrow(ConfigConflictError);
    expect(s.reload('g').strictMode).toBe(false);
  });

  it('is atomic: if one change fails, none of them is applied and the version is unchanged', () => {
    const s = make();
    s.commit('g', 0, [{ type: 'GLOBAL_ENABLED', value: false }], meta);
    expect(() => s.commit('g', 1, [{ type: 'GLOBAL_ENABLED', value: true }, { type: 'BOGUS' } as never], meta)).toThrow();
    const after = s.reload('g');
    expect(after.enabled).toBe(false);
    expect(after.configVersion).toBe(1);
  });

  it('survives a restart (new service instance over the same database)', () => {
    const db = openDatabase(':memory:');
    new GuildConfigService(db).commit('g', 0, [
      { type: 'GLOBAL_ENABLED', value: true },
      { type: 'CATEGORY_ENABLED', category: 'C', value: false },
      { type: 'DETECTOR_ENABLED', detectorId: 'A01-T', value: false },
      { type: 'ALERT_CHANNEL', value: '555' },
    ], meta);
    const fresh = new GuildConfigService(db).get('g');
    expect(fresh).toMatchObject({ enabled: true, alertChannelId: '555', categoryEnabled: { C: false }, detectorEnabled: { 'A01-T': false } });
  });

  it('isolates guilds', () => {
    const s = make();
    s.commit('a', 0, [{ type: 'GLOBAL_ENABLED', value: true }], meta);
    expect(s.get('b').enabled).toBe(false);
  });

  it('resolves limits by profile (Appendix A) and Strict Mode halves counted limits', () => {
    const s = make();
    const bal = s.resolve('g', A01T.descriptor);
    expect(bal).toMatchObject({ instant: false, rules: [{ maxActions: 3, windowSeconds: 10 }] });
    expect(s.resolve('g', C01.descriptor).rules).toEqual([{ maxActions: 3, windowSeconds: 10 }, { maxActions: 10, windowSeconds: 3600 }]);
    expect(s.resolve('g', B05_1.descriptor).instant).toBe(true);

    s.commit('g', 0, [{ type: 'PROFILE', value: 'STRICT' }, { type: 'STRICT_MODE', value: true }], meta);
    expect(s.resolve('g', A01T.descriptor).rules).toEqual([{ maxActions: 2, windowSeconds: 10 }]);
    expect(s.resolve('g', C01.descriptor).rules).toEqual([{ maxActions: 2, windowSeconds: 10 }, { maxActions: 6, windowSeconds: 3600 }]);
    const strictAffected = { ...C01.descriptor, strictAffected: true };
    expect(s.resolve('g', strictAffected).rules).toEqual([{ maxActions: 1, windowSeconds: 10 }, { maxActions: 3, windowSeconds: 3600 }]);
  });

  it('effective enabled = global AND category AND detector', () => {
    const s = make();
    s.commit('g', 0, [{ type: 'GLOBAL_ENABLED', value: true }], meta);
    expect(s.resolve('g', A01T.descriptor).enabled).toBe(true);
    s.commit('g', 1, [{ type: 'CATEGORY_ENABLED', category: 'A', value: false }], meta);
    expect(s.resolve('g', A01T.descriptor).enabled).toBe(false);
    expect(s.resolve('g', C01.descriptor).enabled).toBe(true);
  });
});

const caps = (over: Partial<BotCapabilities> = {}): BotCapabilities => ({
  permissions: PermissionFlagsBits.ViewAuditLog,
  intents: new Set(['Guilds', 'GuildModeration']),
  alertChannelUsable: true,
  ...over,
});

describe('Operational status (spec 19.19)', () => {
  it('ACTIVE only when permission, intent and alert channel are all in place', () => {
    expect(computeDetectorStatus(A01T.descriptor, true, caps()).status).toBe('ACTIVE');
  });
  it('missing View Audit Log → PERMISSION_BLOCKED with the permission named', () => {
    const s = computeDetectorStatus(A01T.descriptor, true, caps({ permissions: 0n }));
    expect(s).toMatchObject({ status: 'PERMISSION_BLOCKED', reasons: ['MISSING_PERMISSION'] });
    expect(s.detail).toContain('ViewAuditLog');
  });
  it('missing intent → PERMISSION_BLOCKED / INTENT_MISSING', () => {
    expect(computeDetectorStatus(A01T.descriptor, true, caps({ intents: new Set(['Guilds']) })).reasons).toEqual(['INTENT_MISSING']);
  });
  it('no usable alert channel → DEGRADED, disabled by config → DISABLED', () => {
    expect(computeDetectorStatus(A01T.descriptor, true, caps({ alertChannelUsable: false })).status).toBe('DEGRADED');
    expect(computeDetectorStatus(A01T.descriptor, false, caps()).status).toBe('DISABLED');
  });
  it('Administrator bypasses the permission check', () => {
    expect(computeDetectorStatus(A01T.descriptor, true, caps({ permissions: PermissionFlagsBits.Administrator })).status).toBe('ACTIVE');
  });
  it('overall: ON only when every enabled detector is ACTIVE; never ON with a blocked detector', () => {
    const active = computeDetectorStatus(A01T.descriptor, true, caps());
    const blocked = computeDetectorStatus(C01.descriptor, true, caps({ permissions: 0n }));
    const off = computeDetectorStatus(C01.descriptor, false, caps());
    expect(computeOverallStatus(true, [active], false)).toBe('ON');
    expect(computeOverallStatus(true, [active, blocked], false)).toBe('DEGRADED');
    expect(computeOverallStatus(true, [active, off], false)).toBe('ON');
    expect(computeOverallStatus(true, [blocked], false)).toBe('DEGRADED');
    expect(computeOverallStatus(false, [active], false)).toBe('OFF');
    expect(computeOverallStatus(true, [active], true)).toBe('FAILED');
  });
});

describe('Authority matrix (spec 11.4)', () => {
  it('Admin may enable and toggle; only Security Owner may disable, change preset or Strict Mode', () => {
    expect(can('ADMIN', 'ENABLE_ALL')).toBe(true);
    expect(can('ADMIN', 'DETECTOR_TOGGLE', 'A')).toBe(true);
    expect(can('ADMIN', 'DISABLE_ALL')).toBe(false);
    expect(can('ADMIN', 'PRESET')).toBe(false);
    expect(can('SECURITY_OWNER', 'DISABLE_ALL')).toBe(true);
    expect(can('NONE', 'VIEW')).toBe(false);
  });
  it('self-protection category and security owner list are restricted', () => {
    expect(can('ADMIN', 'CATEGORY_TOGGLE', 'H')).toBe(false);
    expect(can('SECURITY_OWNER', 'CATEGORY_TOGGLE', 'H')).toBe(true);
    expect(requiredLevel('MANAGE_SECURITY_OWNERS')).toBe('SERVER_OWNER');
    expect(can('SECURITY_OWNER', 'MANAGE_SECURITY_OWNERS')).toBe(false);
  });
});
