import { describe, expect, it } from 'vitest';
import { AuditLogEvent } from 'discord.js';
import { buildAlertEmbed } from '../src/ui/alerts/alertEmbed.js';
import { buildCustomId, parseCustomId } from '../src/ui/settings/customId.js';
import { buildCategoryContainer, buildConfirmDisableContainer, buildOverviewContainer } from '../src/ui/settings/views.js';
import type { CategoryModel, DetectorRow, OverviewModel } from '../src/ui/settings/viewModel.js';
import { createLogger, errorMessage, redact } from '../src/core/logger.js';
import { normalizeAuditEntry } from '../src/events/normalizeAudit.js';
import { buildAuditReason, classifySelfAction } from '../src/engine/selfAction/selfAction.js';
import { A01T } from '../src/detectors/channel/A01T.js';
import { scoreRisk } from '../src/engine/risk/riskScoring.js';
import { ev, BOT_ID } from './helpers.js';
import type { ExecutionContext } from '../src/actions/executor.js';

interface Node {
  type: number;
  content?: string;
  custom_id?: string;
  components?: Node[];
  accessory?: Node;
}

/** Counts every component (nested included) and all display text, as Discord does for Components V2. */
function measure(node: Node): { components: number; chars: number; ids: string[] } {
  let components = 1;
  let chars = node.content?.length ?? 0;
  const ids: string[] = node.custom_id ? [node.custom_id] : [];
  for (const child of [...(node.components ?? []), ...(node.accessory ? [node.accessory] : [])]) {
    const m = measure(child);
    components += m.components;
    chars += m.chars;
    ids.push(...m.ids);
  }
  return { components, chars, ids };
}

const overview: OverviewModel = {
  sessionId: 'abcdef012345',
  overall: 'DEGRADED',
  profile: 'BALANCED',
  strictMode: false,
  alertChannelId: '123456789012345678',
  modules: { total: 8, active: 3, disabled: 2 },
  detectors: { total: 150, active: 100, restricted: 20, unsupported: 10, disabled: 20 },
  health: Array.from({ length: 9 }, (_, i) => ({ name: `Thành phần ${i}`, status: 'HEALTHY' as const, detail: 'Đọc/ghi thử OK (0.12 ms)' })),
  warnings: ['Chưa có kênh cảnh báo dùng được — cảnh báo sẽ chỉ gửi qua DM chủ server.'],
  categories: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'],
};

const row = (i: number): DetectorRow => ({
  id: `X${String(i).padStart(2, '0')}-T`,
  name: 'Chống xóa channel (văn bản) với tên khá dài để kiểm tra giới hạn ký tự',
  status: { id: `X${i}`, status: 'PERMISSION_BLOCKED', reasons: ['MISSING_PERMISSION'], detail: 'Bot thiếu quyền: ViewAuditLog, ManageRoles, ManageChannels' },
  enabled: true,
  limitText: '3/10s + 10/3600s',
  firstActionText: 'Chỉ ghi log, Cảnh báo, Cách ly',
});

describe('Components V2 limits (spec 19.22: <= 40 components, <= 4000 chars)', () => {
  it('overview page', () => {
    const m = measure(buildOverviewContainer(overview).toJSON() as unknown as Node);
    expect(m.components).toBeLessThanOrEqual(40);
    expect(m.chars).toBeLessThanOrEqual(4000);
  });
  it('category page with a full 8 detectors', () => {
    const model: CategoryModel = { sessionId: 'abcdef012345', category: 'A', categoryEnabled: true, page: 0, pages: 3, rows: Array.from({ length: 8 }, (_, i) => row(i)) };
    const m = measure(buildCategoryContainer(model).toJSON() as unknown as Node);
    expect(m.components).toBeLessThanOrEqual(40);
    expect(m.chars).toBeLessThanOrEqual(4000);
  });
  it('every custom_id is within 100 chars and parseable', () => {
    const model: CategoryModel = { sessionId: 'abcdef012345', category: 'B', categoryEnabled: false, page: 1, pages: 3, rows: [row(1)] };
    const ids = [
      ...measure(buildOverviewContainer(overview).toJSON() as unknown as Node).ids,
      ...measure(buildCategoryContainer(model).toJSON() as unknown as Node).ids,
      ...measure(buildConfirmDisableContainer('abcdef012345', 60).toJSON() as unknown as Node).ids,
    ];
    expect(ids.length).toBeGreaterThan(10);
    for (const id of ids) {
      expect(id.length).toBeLessThanOrEqual(100);
      expect(parseCustomId(id)?.sessionId).toBe('abcdef012345');
    }
    expect(new Set(ids).size).toBe(ids.length); // Discord rejects duplicate custom_ids in one message
  });
  it('custom_id round trip and rejection of foreign/forged ids', () => {
    expect(parseCustomId(buildCustomId('s1', 'dt', 'B05.1'))).toEqual({ sessionId: 's1', action: 'dt', args: ['B05.1'] });
    expect(parseCustomId('other:1:s:a')).toBeNull();
    expect(parseCustomId('an:9:s:a')).toBeNull();
    expect(parseCustomId('an:1:s')).toBeNull();
    expect(() => buildCustomId('s', 'x', 'y'.repeat(100))).toThrow();
  });
});

describe('Alert embed', () => {
  const event = ev({ actionType: AuditLogEvent.ChannelDelete });
  const risk = scoreRisk({ severity: 'HIGH', riskWeight: 1, instant: false, count: 4, maxActions: 3, targetImportance: 3, permissionContext: 0, actorHeat: 0, heatActionThreshold: 60, correlation: 0, trustReduction: 0 });
  const ctx: ExecutionContext = {
    guildId: event.guildId, incidentId: 'INC-1', descriptor: A01T.descriptor,
    signal: { units: 1, targetId: 't1', targetImportance: 3, permissionContext: 0, tags: [], summary: 'Xóa channel **#general**' },
    event, actor: { id: 'u1', kind: 'USER', isOwner: false }, attribution: 'CONFIRMED', risk, tier: 'FIRST', repeated: false,
    actions: ['LOG_ONLY', 'ALERT'], skipped: [{ action: 'QUARANTINE', reason: 'NOT_IMPLEMENTED' }],
    limit: { count: 4, rule: { maxActions: 3, windowSeconds: 10 }, instant: false }, alertChannelId: null,
  };
  it('is Vietnamese, explains the risk, lists what did and did not run, and respects Discord limits', () => {
    const json = buildAlertEmbed(ctx, [{ action: 'LOG_ONLY', status: 'OK', detail: 'ok' }]).toJSON();
    expect(json.title).toContain('Chống xóa channel');
    expect(json.fields!.some((f) => f.name === 'Giải thích Risk')).toBe(true);
    expect(json.fields!.find((f) => f.name === 'Hành động chưa chạy')?.value).toContain('chưa được triển khai');
    for (const f of json.fields!) expect(f.value.length).toBeLessThanOrEqual(1024);
    expect(JSON.stringify(json).length).toBeLessThan(6000);
  });
  it('marks the Server Owner as not punishable', () => {
    const json = buildAlertEmbed({ ...ctx, actor: { id: '1', kind: 'USER', isOwner: true } }, []).toJSON();
    expect(json.fields![0]!.value).toContain('chủ server');
  });
});

describe('Security helpers', () => {
  it('redacts bot tokens and webhook URLs from anything logged', () => {
    const token = 'MTIzNDU2Nzg5MDEyMzQ1Njc4OQ.GabcDE.abcdefghijklmnopqrstuvwxyz0123456789';
    expect(redact(`login failed ${token}`)).not.toContain('GabcDE');
    expect(redact('https://discord.com/api/webhooks/123456789/AbC-dEf_ghI')).toContain('[REDACTED]');
    expect(errorMessage(new Error(`bad ${token}`))).toContain('[REDACTED_TOKEN]');
    expect(typeof createLogger('error').error).toBe('function');
  });
  it('audit reasons carry the self-action prefix and stay within 512 chars', () => {
    const reason = buildAuditReason('op-1', 'x'.repeat(1000));
    expect(reason.startsWith('[AN:op-1]')).toBe(true);
    expect(reason.length).toBe(512);
    expect(classifySelfAction(ev({ actionType: 1, executorId: BOT_ID, reason }), BOT_ID)).toBe('SELF_ACTION');
    expect(classifySelfAction(ev({ actionType: 1, executorId: 'u1', reason }), BOT_ID)).toBe('NONE');
  });
});

describe('Audit entry normalization', () => {
  const fakeGuild = (fetch: () => Promise<{ bot: boolean }>) => ({ id: '100', client: { users: { fetch } } }) as never;
  const entry = (over: Record<string, unknown> = {}) =>
    ({ id: '1', action: 12, createdTimestamp: 1_700_000_000_123, executorId: '55', executor: null, targetId: '77', changes: [{ key: 'type', old: 0 }], reason: null, ...over }) as never;

  it('uses the entry (snowflake) timestamp and resolves the executor kind', async () => {
    const e = await normalizeAuditEntry(entry({ executor: { bot: true } }), fakeGuild(async () => ({ bot: false })));
    expect(e).toMatchObject({ ts: 1_700_000_000_123, executorKind: 'BOT', executorId: '55', targetId: '77', source: 'AUDIT' });
  });
  it('falls back to a REST user fetch, and to UNKNOWN when the kind cannot be determined', async () => {
    expect((await normalizeAuditEntry(entry(), fakeGuild(async () => ({ bot: false })))).executorKind).toBe('USER');
    expect((await normalizeAuditEntry(entry(), fakeGuild(async () => { throw new Error('x'); }))).executorKind).toBe('UNKNOWN');
  });
  it('missing executor → UNKNOWN actor', async () => {
    const e = await normalizeAuditEntry(entry({ executorId: null }), fakeGuild(async () => ({ bot: false })));
    expect(e).toMatchObject({ executorId: null, executorKind: 'UNKNOWN' });
  });
});
