import { describe, expect, it } from 'vitest';
import { ACTOR_DETECTOR_ACTIONS, IMPLEMENTED_ACTIONS, type ActionName } from '../src/actions/actionCatalog.js';
import { HeatTracker } from '../src/engine/heat/heatTracker.js';
import { resolveActions, selectTier, type ResolveInput } from '../src/engine/policy/actionResolver.js';
import { bumpRisk, levelForScore, scoreRisk, type RiskInput } from '../src/engine/risk/riskScoring.js';

const baseRisk: RiskInput = {
  severity: 'HIGH', riskWeight: 1, instant: false, count: 4, maxActions: 3,
  targetImportance: 3, permissionContext: 0, actorHeat: 0, heatActionThreshold: 60, correlation: 0, trustReduction: 0,
};

describe('Risk scoring (spec 10.1)', () => {
  it('computes each component and explains it', () => {
    const r = scoreRisk(baseRisk);
    expect(r.components).toEqual({ S: 32, F: 5, T: 3, P: 0, H: 0, C: 0, R: 0 });
    expect(r.score).toBe(40);
    expect(r.level).toBe('MEDIUM');
    expect(r.explanation).toContain('S=32');
  });
  it('caps F at 15 and the total at 100', () => {
    const r = scoreRisk({ ...baseRisk, severity: 'CRITICAL', count: 100, targetImportance: 15, permissionContext: 15, actorHeat: 999, correlation: 10 });
    expect(r.components.F).toBe(15);
    expect(r.score).toBe(100);
  });
  it('Trust Reduction lowers the score but never below 0', () => {
    expect(scoreRisk({ ...baseRisk, severity: 'INFORMATIONAL', trustReduction: 20, count: 3 }).score).toBe(0);
  });
  it('instant rule gives F = 15', () => {
    expect(scoreRisk({ ...baseRisk, instant: true, maxActions: 0, count: 1 }).components.F).toBe(15);
  });
  it('band edges', () => {
    expect([19, 20, 39, 40, 59, 60, 79, 80].map(levelForScore)).toEqual(['INFORMATIONAL', 'LOW', 'LOW', 'MEDIUM', 'MEDIUM', 'HIGH', 'HIGH', 'CRITICAL']);
  });
  it('Strict Mode bumps one band and keeps the score inside the new band', () => {
    const bumped = bumpRisk(scoreRisk({ ...baseRisk, count: 4 }));
    expect(bumped.level).toBe('HIGH');
    expect(bumped.score).toBeGreaterThanOrEqual(60);
    expect(bumpRisk({ ...bumped, level: 'CRITICAL', score: 90 }).level).toBe('CRITICAL');
  });
});

describe('Heat (spec 10.2)', () => {
  it('halves after one half-life and is dropped after 5 half-lives', () => {
    const h = new HeatTracker();
    h.add('k', 0, 40);
    expect(h.value('k', 0, 120)).toBeCloseTo(40);
    expect(h.value('k', 120_000, 120)).toBeCloseTo(20);
    expect(h.value('k', 5 * 120_000 + 1, 120)).toBe(0);
  });
  it('sums independent events', () => {
    const h = new HeatTracker();
    h.add('k', 0, 10);
    h.add('k', 0, 10);
    expect(h.value('k', 0, 120)).toBeCloseTo(20);
  });
});

const input = (over: Partial<ResolveInput> = {}): ResolveInput => ({
  policy: ['LOG_ONLY', 'ALERT', 'QUARANTINE'],
  compatible: ACTOR_DETECTOR_ACTIONS,
  attribution: 'CONFIRMED',
  actorKind: 'USER',
  actorIsOwner: false,
  actorIsAdministrator: false,
  riskLevel: 'MEDIUM',
  implemented: IMPLEMENTED_ACTIONS,
  ...over,
});

describe('Action resolver (spec 13.2 – 13.6, Appendix C)', () => {
  it('tier selection', () => {
    expect(selectTier('CRITICAL', false)).toBe('CRITICAL');
    expect(selectTier('HIGH', true)).toBe('HIGH');
    expect(selectTier('MEDIUM', true)).toBe('REPEATED');
    expect(selectTier('LOW', false)).toBe('FIRST');
  });
  it('reports actions that are valid but not implemented, and keeps ALERT', () => {
    const r = resolveActions(input());
    expect(r.actions).toEqual(expect.arrayContaining(['LOG_ONLY', 'ALERT']));
    expect(r.skipped).toEqual([{ action: 'QUARANTINE', reason: 'NOT_IMPLEMENTED' }]);
  });
  it('never punishes the Server Owner', () => {
    const r = resolveActions(input({ actorIsOwner: true, implemented: new Set<ActionName>(['LOG_ONLY', 'ALERT', 'QUARANTINE']) }));
    expect(r.actions).not.toContain('QUARANTINE');
    expect(r.skipped).toContainEqual({ action: 'QUARANTINE', reason: 'TARGET_PROTECTED' });
  });
  it('PROBABLE / POSSIBLE / UNKNOWN attribution never punishes the actor', () => {
    const all = new Set<ActionName>(['LOG_ONLY', 'ALERT', 'KICK', 'BAN', 'QUARANTINE', 'TIMEOUT']);
    for (const attribution of ['PROBABLE', 'POSSIBLE', 'UNKNOWN'] as const) {
      const r = resolveActions(input({ policy: ['KICK', 'BAN', 'QUARANTINE', 'TIMEOUT'], attribution, implemented: all }));
      expect(r.actions.filter((a) => ['KICK', 'BAN', 'QUARANTINE', 'TIMEOUT'].includes(a))).toEqual([]);
    }
  });
  it('unknown actor kind blocks actor-targeted actions', () => {
    const r = resolveActions(input({ actorKind: 'UNKNOWN', attribution: 'UNKNOWN', implemented: new Set<ActionName>(['LOG_ONLY', 'ALERT', 'QUARANTINE']) }));
    expect(r.skipped).toContainEqual({ action: 'QUARANTINE', reason: 'ACTOR_NOT_APPLICABLE' });
  });
  it('TIMEOUT is not valid for bots or administrators', () => {
    const impl = new Set<ActionName>(['LOG_ONLY', 'ALERT', 'TIMEOUT']);
    expect(resolveActions(input({ policy: ['TIMEOUT'], actorKind: 'BOT', implemented: impl })).skipped[0]?.reason).toBe('ACTOR_NOT_APPLICABLE');
    expect(resolveActions(input({ policy: ['TIMEOUT'], actorIsAdministrator: true, implemented: impl })).skipped[0]?.reason).toBe('ACTOR_NOT_APPLICABLE');
  });
  it('resource containment needs CONFIRMED attribution or Risk >= HIGH', () => {
    const impl = new Set<ActionName>(['LOG_ONLY', 'ALERT', 'GLOBAL_LOCKDOWN']);
    expect(resolveActions(input({ policy: ['GLOBAL_LOCKDOWN'], attribution: 'UNKNOWN', riskLevel: 'MEDIUM', implemented: impl })).skipped[0]?.reason).toBe('RISK_TOO_LOW');
    expect(resolveActions(input({ policy: ['GLOBAL_LOCKDOWN'], attribution: 'UNKNOWN', riskLevel: 'HIGH', implemented: impl })).actions).toContain('GLOBAL_LOCKDOWN');
  });
  it('keeps only the heaviest hard punishment', () => {
    const impl = new Set<ActionName>(['LOG_ONLY', 'ALERT', 'TIMEOUT', 'KICK', 'BAN']);
    const r = resolveActions(input({ policy: ['TIMEOUT', 'KICK', 'BAN'], implemented: impl }));
    expect(r.actions.filter((a) => ['TIMEOUT', 'KICK', 'BAN'].includes(a))).toEqual(['BAN']);
  });
  it('rejects incompatible actions explicitly instead of swapping them', () => {
    const r = resolveActions(input({ policy: ['REMOVE_UNAUTHORIZED_BOT'] }));
    expect(r.skipped).toEqual([{ action: 'REMOVE_UNAUTHORIZED_BOT', reason: 'INCOMPATIBLE' }]);
  });
  it('orders containment before punishment before recovery before notification', () => {
    const impl = new Set<ActionName>(['LOG_ONLY', 'ALERT', 'QUARANTINE', 'GLOBAL_LOCKDOWN', 'ROLLBACK_CHANGE']);
    const r = resolveActions(input({ policy: ['ALERT', 'ROLLBACK_CHANGE', 'QUARANTINE', 'GLOBAL_LOCKDOWN'], implemented: impl }));
    expect(r.actions.indexOf('GLOBAL_LOCKDOWN')).toBeLessThan(r.actions.indexOf('QUARANTINE'));
    expect(r.actions.indexOf('QUARANTINE')).toBeLessThan(r.actions.indexOf('ROLLBACK_CHANGE'));
    expect(r.actions.indexOf('ROLLBACK_CHANGE')).toBeLessThan(r.actions.indexOf('ALERT'));
  });
});
