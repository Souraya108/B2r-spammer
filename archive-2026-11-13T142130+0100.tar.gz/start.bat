﻿@echo off
cd /d %~dp0
title Discord Spammer 2 (Node.js)

echo ======================================================
echo           Starting Discord Spammer 2 (Node.js)       
echo ======================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js is not installed or not in your PATH.
    echo Please install Node.js from https://nodejs.org/
    echo.
    pause
    exit /b 1
)

if not exist node_modules (
    echo [INFO] Installing required dependencies...
    call npm.cmd install
    if errorlevel 1 (
        echo [ERROR] Failed to install dependencies.
        echo.
        pause
        exit /b 1
    )
)

node index.js
if errorlevel 1 (
    echo.
    echo [!] Bot exited with an error.
)

echo.
pause
