// tokens.js - Single Token Configuration
module.exports = {
    tokens: [
        {
            token: 'MTQ1MzQyMTUxNjUxODU5MjY0Mg.GWQnJp.6ZafydrIG1yOUbe0FXB7D7glA7ohujO0T_EfPo',
            channelIds: ['1561314185533591586'],
            serverId: '1464267978437693682'
        }
    ]
};
